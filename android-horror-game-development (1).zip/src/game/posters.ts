// High quality posters: real photographs (AI generated stock) + crisp Persian typography + paper aging
import * as THREE from 'three';
import pMan from '../assets/posters/man.jpg';
import pWoman from '../assets/posters/woman.jpg';
import pYouth from '../assets/posters/youth.jpg';
import pOld from '../assets/posters/oldman.jpg';
import pDog from '../assets/posters/dog.jpg';
import pTall from '../assets/posters/tall.jpg';
import pFaceless from '../assets/posters/faceless.jpg';
import pSmile from '../assets/posters/smile.jpg';

const SRC: Record<string, string> = { man: pMan, woman: pWoman, youth: pYouth, old: pOld, dog: pDog, tall: pTall, faceless: pFaceless, smile: pSmile };
const imgs: Record<string, HTMLImageElement> = {};
const waiters: Record<string, (() => void)[]> = {};

function img(name: string): HTMLImageElement | null {
  let im = imgs[name];
  if (!im) {
    im = new Image();
    im.onload = () => { const w = waiters[name] || []; waiters[name] = []; w.forEach((f) => f()); };
    im.src = SRC[name];
    imgs[name] = im;
  }
  return im.complete && im.naturalWidth > 0 ? im : null;
}
export function preloadPosterPhotos() { Object.keys(SRC).forEach(img); }
/** run cb with the decoded photo (immediately if already loaded) */
export function withPhoto(name: string, cb: (im: HTMLImageElement) => void) {
  const im = img(name);
  if (im) cb(im); else (waiters[name] ||= []).push(() => cb(imgs[name]));
}

let seed = 1;
const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
const FONT = 'Vazirmatn, Tahoma, Arial, sans-serif';
function txt(c: CanvasRenderingContext2D, s: string, x: number, y: number, size: number, color: string, weight = 'bold', align: CanvasTextAlign = 'center', maxW?: number) {
  c.font = `${weight} ${size}px ${FONT}`; c.fillStyle = color; c.textAlign = align; c.textBaseline = 'middle';
  c.direction = /[\u0600-\u06FF]/.test(s) ? 'rtl' : 'ltr';
  c.fillText(s, x, y, maxW);
  c.direction = 'ltr';
}
function drip(c: CanvasRenderingContext2D, x: number, y: number, len: number, w: number, col: string) {
  c.fillStyle = col; c.beginPath(); c.moveTo(x - w, y); c.lineTo(x + w, y); c.lineTo(x + w * 0.45, y + len); c.arc(x, y + len, w * 0.6, 0, Math.PI); c.closePath(); c.fill();
}
/** draw an image cover-cropped into a rect with a photocopy/print look */
function photo(c: CanvasRenderingContext2D, im: HTMLImageElement | null, x: number, y: number, w: number, h: number, filter: string, focusY = 0.4) {
  c.save();
  c.beginPath(); c.rect(x, y, w, h); c.clip();
  if (im) {
    const ir = im.naturalWidth / im.naturalHeight, r = w / h;
    let sw = im.naturalWidth, sh = im.naturalHeight, sx = 0, sy = 0;
    if (ir > r) { sw = sh * r; sx = (im.naturalWidth - sw) / 2; } else { sh = sw / r; sy = (im.naturalHeight - sh) * focusY; }
    try { c.filter = filter; } catch { /* unsupported */ }
    c.drawImage(im, sx, sy, sw, sh, x, y, w, h);
    c.filter = 'none';
  } else { c.fillStyle = '#444'; c.fillRect(x, y, w, h); }
  // halftone/grain
  for (let i = 0; i < w * h / 60; i++) { c.fillStyle = rnd() < 0.5 ? `rgba(0,0,0,${rnd() * 0.18})` : `rgba(255,255,255,${rnd() * 0.08})`; c.fillRect(x + rnd() * w, y + rnd() * h, 1.5, 1.5); }
  c.restore();
}
function paper(c: CanvasRenderingContext2D, w: number, h: number, base: string, aged: number) {
  c.fillStyle = base; c.fillRect(0, 0, w, h);
  // fibers + tone variation
  for (let i = 0; i < w * h / 40; i++) { c.fillStyle = `rgba(${rnd() < 0.5 ? '120,100,60' : '255,255,255'},${rnd() * 0.05})`; c.fillRect(rnd() * w, rnd() * h, 1 + rnd() * 2, 1); }
  const g = c.createRadialGradient(w / 2, h / 2, w * 0.2, w / 2, h / 2, w * 0.85);
  g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(110,80,30,${0.18 + aged * 0.25})`);
  c.fillStyle = g; c.fillRect(0, 0, w, h);
}
function finish(c: CanvasRenderingContext2D, w: number, h: number, aged: number) {
  // fold creases
  const fold = (x0: number, y0: number, x1: number, y1: number) => {
    c.strokeStyle = 'rgba(0,0,0,0.12)'; c.lineWidth = 2; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,0.18)'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(x0 + 2, y0 + 1); c.lineTo(x1 + 2, y1 + 1); c.stroke();
  };
  fold(0, h * 0.5, w, h * 0.5 + (rnd() - 0.5) * 10); fold(w * 0.5 + (rnd() - 0.5) * 8, 0, w * 0.5, h);
  // stains
  for (let i = 0; i < 3 + aged * 6; i++) {
    const x = rnd() * w, y = rnd() * h, r = 10 + rnd() * 50;
    const g = c.createRadialGradient(x, y, r * 0.6, x, y, r);
    g.addColorStop(0, `rgba(120,90,40,${0.04 + aged * 0.08})`); g.addColorStop(0.9, `rgba(100,70,30,${0.1 + aged * 0.12})`); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
  }
  // tape
  const tape = (x: number, y: number, rot: number) => { c.save(); c.translate(x, y); c.rotate(rot); c.fillStyle = 'rgba(235,228,195,0.72)'; c.fillRect(-40, -12, 80, 24); c.fillStyle = 'rgba(255,255,255,0.15)'; c.fillRect(-40, -12, 80, 5); c.restore(); };
  tape(30, 14, -0.45); tape(w - 30, 14, 0.42);
  if (aged > 0.5) for (let i = 0; i < 5; i++) drip(c, rnd() * w, 0, 40 + rnd() * 140, 3 + rnd() * 4, 'rgba(95,0,0,0.88)');
}
function scratchEyes(c: CanvasRenderingContext2D, x: number, y: number, w: number) {
  c.strokeStyle = 'rgba(8,8,8,0.95)'; c.lineCap = 'round';
  for (let k = 0; k < 26; k++) { c.lineWidth = 2 + rnd() * 4; c.beginPath(); c.moveTo(x - w / 2 + rnd() * 10, y + (rnd() - 0.5) * 26); c.lineTo(x + w / 2 - rnd() * 10, y + (rnd() - 0.5) * 26); c.stroke(); }
  c.strokeStyle = 'rgba(140,0,0,0.85)';
  for (let k = 0; k < 6; k++) { c.lineWidth = 2; c.beginPath(); c.moveTo(x - w / 2, y + (rnd() - 0.5) * 30); c.lineTo(x + w / 2, y + (rnd() - 0.5) * 30); c.stroke(); }
}

export type PhotoPosterKind = 'missing' | 'missingMe' | 'dontlook' | 'tall' | 'dog' | 'hiring' | 'rules' | 'smile' | 'flyer';
const PEOPLE = [
  { img: 'man', name: 'محمد رضایی', info: '۴۲ ساله • قد ۱۷۵ • لباس فرم سرمه‌ای' },
  { img: 'woman', name: 'سارا کریمی', info: '۲۹ ساله • قد ۱۶۴ • مانتوی زرشکی' },
  { img: 'youth', name: 'علی نوروزی', info: '۱۹ ساله • قد ۱۷۸ • سویشرت سبز' },
  { img: 'old', name: 'حسین یزدانی', info: '۷۱ ساله • عینکی • ژاکت قهوه‌ای' },
];

const cache = new Map<string, THREE.CanvasTexture>();
const W = 420, H = 590;

export function photoPoster(kind: PhotoPosterKind, variant = 0, aged = false): THREE.CanvasTexture {
  const key = `${kind}-${variant}-${aged}`;
  const hit = cache.get(key); if (hit) return hit;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const c = cv.getContext('2d')!;
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  const need: string[] = [];
  const P = PEOPLE[variant % PEOPLE.length];
  const age = aged ? 1 : 0.25;
  const draw = () => {
    seed = 7 + variant * 131 + kind.length * 17 + (aged ? 5 : 0);
    c.clearRect(0, 0, W, H);
    if (kind === 'missing' || kind === 'missingMe' || kind === 'flyer') {
      paper(c, W, H, '#f1ecdc', age);
      c.fillStyle = '#b10e0e'; c.fillRect(0, 0, W, 112);
      txt(c, 'گمشده', W / 2, 52, 74, '#ffffff', '900');
      txt(c, 'MISSING  •  لطفاً کمک کنید', W / 2, 98, 18, '#ffd9d9', 'bold');
      const im = img(kind === 'missingMe' ? 'man' : P.img); if (!im) need.push(kind === 'missingMe' ? 'man' : P.img);
      const px = 70, py = 128, pw = 280, ph = 300;
      c.fillStyle = '#fff'; c.fillRect(px - 8, py - 8, pw + 16, ph + 16);
      photo(c, im, px, py, pw, ph, aged ? 'grayscale(1) contrast(1.5) brightness(0.9)' : 'grayscale(0.55) sepia(0.15) contrast(1.15)', 0.15);
      if (kind === 'missingMe') {
        // the face is gone
        c.fillStyle = '#050505'; c.beginPath(); c.ellipse(px + pw / 2, py + ph * 0.36, 70, 92, 0, 0, Math.PI * 2); c.fill();
        for (let i = 0; i < 40; i++) { c.strokeStyle = 'rgba(0,0,0,0.85)'; c.lineWidth = 2; c.beginPath(); c.moveTo(px + pw / 2 + (rnd() - 0.5) * 150, py + ph * 0.36 + (rnd() - 0.5) * 200); c.lineTo(px + pw / 2 + (rnd() - 0.5) * 150, py + ph * 0.36 + (rnd() - 0.5) * 200); c.stroke(); }
      } else if (aged) scratchEyes(c, px + pw / 2, py + ph * 0.34, 170);
      const name = kind === 'missingMe' ? 'کارمند جدید شیفت شب' : P.name;
      txt(c, name, W / 2, 462, 32, '#111', '900', 'center', W - 40);
      txt(c, kind === 'missingMe' ? 'بدون مشخصات • بدون چهره' : P.info, W / 2, 496, 16, '#333', 'bold', 'center', W - 40);
      txt(c, kind === 'missingMe' ? 'آخرین بار: امشب، ساعت ۳ بامداد' : 'آخرین بار: پمپ بنزین پترو ۲۴ — شیفت شب', W / 2, 522, 15, '#a00', 'bold', 'center', W - 30);
      // tear-off phone tabs
      for (let i = 0; i < 8; i++) {
        const x = 14 + i * 49;
        c.strokeStyle = 'rgba(0,0,0,0.35)'; c.setLineDash([3, 3]); c.beginPath(); c.moveTo(x, 540); c.lineTo(x, H); c.stroke(); c.setLineDash([]);
        if (i === 2 || i === 5) { c.fillStyle = '#2a2a2a'; c.fillRect(x + 1, 548, 47, H - 548); continue; } // torn off
        c.save(); c.translate(x + 26, 566); c.rotate(-Math.PI / 2); txt(c, '۰۹۱۲۰۰۰۰۰۲۴', 0, 0, 10, '#222', 'bold'); c.restore();
      }
      if (kind === 'flyer') {
        c.save(); c.translate(W / 2, 300); c.rotate(-0.18);
        txt(c, 'تو بعدی هستی', 0, 0, 52, 'rgba(150,0,0,0.92)', '900'); c.restore();
        for (let i = 0; i < 7; i++) drip(c, 90 + rnd() * 240, 322, 20 + rnd() * 60, 3, 'rgba(130,0,0,0.85)');
      }
    } else if (kind === 'dog') {
      paper(c, W, H, '#ece6d2', age);
      txt(c, 'سگ گمشده', W / 2, 52, 60, '#111', '900');
      txt(c, 'پاداش برای هر اطلاعاتی', W / 2, 102, 22, '#a00', '900');
      const im = img('dog'); if (!im) need.push('dog');
      c.fillStyle = '#fff'; c.fillRect(32, 124, W - 64, 310);
      photo(c, im, 40, 132, W - 80, 294, 'grayscale(1) contrast(1.3)', 0.4);
      txt(c, 'دوربین شکار — پشت پمپ بنزین — ۰۳:۱۲', W / 2, 452, 14, '#444', 'normal');
      txt(c, 'روی دو پا راه می‌رود', W / 2, 488, 26, '#111', '900');
      txt(c, 'اگر او را دیدید، نزدیک نشوید', W / 2, 528, 24, '#a00', '900');
      txt(c, 'به چشم‌هایش نگاه نکنید', W / 2, 562, 16, '#333', 'bold');
    } else if (kind === 'tall' || kind === 'smile' || kind === 'dontlook') {
      const name = kind === 'dontlook' ? 'faceless' : kind;
      const im = img(name); if (!im) need.push(name);
      c.fillStyle = '#000'; c.fillRect(0, 0, W, H);
      photo(c, im, 0, 0, W, H, kind === 'smile' ? 'grayscale(0.85) contrast(1.35)' : 'grayscale(0.6) contrast(1.25) brightness(0.9)', 0.3);
      const g = c.createLinearGradient(0, H * 0.55, 0, H); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.95)');
      c.fillStyle = g; c.fillRect(0, 0, W, H);
      const g2 = c.createLinearGradient(0, 0, 0, 120); g2.addColorStop(0, 'rgba(0,0,0,0.85)'); g2.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = g2; c.fillRect(0, 0, W, 120);
      if (kind === 'tall') { txt(c, 'او همیشه', W / 2, 470, 46, '#e8e8e8', '900'); txt(c, 'کنار جاده است', W / 2, 525, 40, '#c41010', '900'); txt(c, 'اگر دیدیش، توقف نکن', W / 2, 40, 20, '#bbb', 'bold'); }
      if (kind === 'smile') { txt(c, 'لبخند بزن', W / 2, 480, 54, '#f0f0f0', '900'); txt(c, 'او تماشا می‌کند', W / 2, 532, 26, '#c41010', '900'); }
      if (kind === 'dontlook') {
        txt(c, 'هشدار', W / 2, 44, 30, '#ffcc00', '900');
        txt(c, 'به صورتش', W / 2, 468, 52, '#c41010', '900'); txt(c, 'نگاه نکن', W / 2, 528, 52, '#c41010', '900');
        for (let i = 0; i < 6; i++) drip(c, 60 + rnd() * 300, 556, 10 + rnd() * 30, 3, 'rgba(160,0,0,0.9)');
      }
      // white border like a printed sheet
      c.strokeStyle = '#e8e2d0'; c.lineWidth = 12; c.strokeRect(6, 6, W - 12, H - 12);
    } else if (kind === 'hiring') {
      paper(c, W, H, '#f6f4ee', 0.1);
      c.fillStyle = '#0d3a6a'; c.fillRect(0, 0, W, 140);
      c.fillStyle = '#e11d2a'; c.fillRect(0, 140, W, 10);
      txt(c, 'استخدام فوری', W / 2, 62, 56, '#ffffff', '900');
      txt(c, 'PETRO 24  •  پترو ۲۴', W / 2, 115, 22, '#9fc8ff', 'bold');
      txt(c, 'کارمند شیفت شب', W / 2, 200, 40, '#0d3a6a', '900');
      ['حقوق عالی + پاداش', 'کار آسان و بی‌دردسر', 'بدون نیاز به سابقه', 'شروع همین امشب'].forEach((s, i) => { txt(c, s, W - 60, 268 + i * 46, 24, '#222', 'bold', 'right'); c.fillStyle = '#1f9a3a'; c.beginPath(); c.arc(W - 38, 268 + i * 46, 9, 0, Math.PI * 2); c.fill(); });
      c.strokeStyle = '#0d3a6a'; c.lineWidth = 2; c.strokeRect(30, 470, W - 60, 70);
      txt(c, 'تماس: ساعت ۲ بامداد', W / 2, 492, 22, '#0d3a6a', '900'); txt(c, 'ما با شما تماس می‌گیریم', W / 2, 522, 16, '#333', 'bold');
      txt(c, '* ترک شیفت قبل از طلوع آفتاب ممنوع است', W / 2, 566, 13, '#a00', 'normal');
    } else if (kind === 'rules') {
      paper(c, W, H, '#efe9d6', 0.6);
      for (let y = 110; y < H - 20; y += 34) { c.strokeStyle = 'rgba(60,90,160,0.25)'; c.lineWidth = 1; c.beginPath(); c.moveTo(20, y); c.lineTo(W - 20, y); c.stroke(); }
      c.strokeStyle = 'rgba(200,40,40,0.4)'; c.beginPath(); c.moveTo(W - 50, 0); c.lineTo(W - 50, H); c.stroke();
      txt(c, 'قوانین شیفت شب', W / 2, 60, 40, '#111', '900');
      const r = ['چراغ‌ها همیشه روشن بمانند', 'از مشتری سؤال اضافه نپرس', 'در را برایشان باز نکن', 'به بی‌چهره خیره نشو', 'تلفن بعد از ۴ را جواب نده', 'هرگز پایین نرو', 'تا صبح دوام بیاور'];
      r.forEach((s, i) => txt(c, `${'۱۲۳۴۵۶۷'[i]}. ${s}`, W - 64, 128 + i * 58, 23, i === 5 ? '#8a0000' : '#1a2a5a', 'bold', 'right', W - 90));
      // coffee ring
      c.strokeStyle = 'rgba(110,70,30,0.35)'; c.lineWidth = 8; c.beginPath(); c.arc(110, 470, 50, 0.3, Math.PI * 1.8); c.stroke();
    }
    finish(c, W, H, aged ? 1 : kind === 'rules' ? 0.5 : 0.2);
    t.needsUpdate = true;
  };
  draw();
  [...new Set(need)].forEach((n) => (waiters[n] ||= []).push(() => { need.length = 0; draw(); }));
  cache.set(key, t);
  return t;
}
