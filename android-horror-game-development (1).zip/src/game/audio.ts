// Procedural spatial audio engine – no external assets (everything synthesised with WebAudio)
import * as THREE from 'three';
import { settingsStore } from './store';

export interface LoopHandle { stop: (fade?: number) => void; setPos?: (p: THREE.Vector3) => void; gain: GainNode; setLevel?: (v: number) => void }

class AudioManager {
  ctx: AudioContext | null = null;
  master!: GainNode;
  sfx!: GainNode;
  amb!: GainNode;
  music!: GainNode;
  noise!: AudioBuffer;
  brown!: AudioBuffer;
  private loops = new Set<LoopHandle>();
  private breathLevel = 0;
  private nextBreath = 0;
  private heartLevel = 0;
  private nextHeart = 0;
  private chase: LoopHandle | null = null;
  private nextChasePulse = 0;
  private chaseOn = false;

  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    const ctx: AudioContext = new AC();
    this.ctx = ctx;
    this.master = ctx.createGain();
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 4;
    this.master.connect(comp); comp.connect(ctx.destination);
    this.sfx = ctx.createGain(); this.sfx.connect(this.master);
    this.amb = ctx.createGain(); this.amb.connect(this.master);
    this.music = ctx.createGain(); this.music.connect(this.master);
    const len = ctx.sampleRate * 2;
    this.noise = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noise.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.brown = ctx.createBuffer(1, len, ctx.sampleRate);
    const b = this.brown.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02; b[i] = last * 3.5; }
    this.applyVolumes();
    settingsStore.subscribe(() => this.applyVolumes());
  }

  applyVolumes() {
    if (!this.ctx) return;
    const s = settingsStore.get();
    this.master.gain.value = s.master;
    this.sfx.gain.value = s.sfx;
    this.amb.gain.value = s.sfx * 0.9;
    this.music.gain.value = s.music;
  }

  get t() { return this.ctx ? this.ctx.currentTime : 0; }

  updateListener(cam: THREE.Camera) {
    const ctx = this.ctx; if (!ctx) return;
    const l = ctx.listener;
    const p = new THREE.Vector3(); cam.getWorldPosition(p);
    const f = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.quaternion);
    if (l.positionX) {
      l.positionX.value = p.x; l.positionY.value = p.y; l.positionZ.value = p.z;
      l.forwardX.value = f.x; l.forwardY.value = f.y; l.forwardZ.value = f.z;
      l.upX.value = 0; l.upY.value = 1; l.upZ.value = 0;
    } else {
      (l as any).setPosition(p.x, p.y, p.z);
      (l as any).setOrientation(f.x, f.y, f.z, 0, 1, 0);
    }
  }

  private panner(pos?: THREE.Vector3, ref = 2, max = 60): AudioNode {
    const ctx = this.ctx!;
    if (!pos) { const g = ctx.createGain(); g.connect(this.sfx); return g; }
    const p = ctx.createPanner();
    p.panningModel = 'equalpower';
    p.distanceModel = 'inverse';
    p.refDistance = ref; p.maxDistance = max; p.rolloffFactor = 1.3;
    p.positionX.value = pos.x; p.positionY.value = pos.y; p.positionZ.value = pos.z;
    p.connect(this.sfx);
    return p;
  }

  private noiseSrc(loop = true, brown = false) {
    const s = this.ctx!.createBufferSource();
    s.buffer = brown ? this.brown : this.noise; s.loop = loop;
    s.playbackRate.value = 0.9 + Math.random() * 0.2;
    return s;
  }

  private env(g: GainNode, t: number, a: number, peak: number, d: number) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(peak, 0.0002), t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
  }

  private makeLoop(nodes: AudioScheduledSourceNode[], gain: GainNode, panner?: AudioNode, extra?: Partial<LoopHandle>): LoopHandle {
    const h: LoopHandle = {
      gain,
      stop: (fade = 0.5) => {
        if (!this.ctx) return;
        const t = this.ctx.currentTime;
        gain.gain.cancelScheduledValues(t);
        gain.gain.setValueAtTime(gain.gain.value, t);
        gain.gain.linearRampToValueAtTime(0, t + fade);
        nodes.forEach((n) => { try { n.stop(t + fade + 0.05); } catch { /* */ } });
        this.loops.delete(h);
      },
      setPos: (p) => {
        if (panner && (panner as PannerNode).positionX) {
          const pn = panner as PannerNode;
          pn.positionX.value = p.x; pn.positionY.value = p.y; pn.positionZ.value = p.z;
        }
      },
      setLevel: (v) => { if (this.ctx) gain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.2); },
      ...extra,
    };
    this.loops.add(h);
    return h;
  }

  stopAll() {
    [...this.loops].forEach((l) => l.stop(0.3));
    this.loops.clear();
    this.chase = null; this.chaseOn = false; this.breathLevel = 0; this.heartLevel = 0;
  }

  // ---------------- Ambient loops ----------------
  wind(level = 0.22): LoopHandle | null {
    const ctx = this.ctx; if (!ctx) return null;
    const src = this.noiseSrc(true, true);
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 500; f.Q.value = 1.5;
    const lfo = ctx.createOscillator(); lfo.frequency.value = 0.07;
    const lg = ctx.createGain(); lg.gain.value = 300;
    lfo.connect(lg); lg.connect(f.frequency);
    const lfo2 = ctx.createOscillator(); lfo2.frequency.value = 0.13;
    const g = ctx.createGain(); g.gain.value = 0;
    const lg2 = ctx.createGain(); lg2.gain.value = level * 0.4;
    lfo2.connect(lg2); lg2.connect(g.gain);
    src.connect(f); f.connect(g); g.connect(this.amb);
    g.gain.linearRampToValueAtTime(level, ctx.currentTime + 2);
    src.start(); lfo.start(); lfo2.start();
    return this.makeLoop([src, lfo, lfo2], g);
  }

  rain(level = 0.18): LoopHandle | null {
    const ctx = this.ctx; if (!ctx) return null;
    const src = this.noiseSrc();
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 900;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 7000;
    const g = ctx.createGain(); g.gain.value = 0;
    src.connect(hp); hp.connect(lp); lp.connect(g); g.connect(this.amb);
    const src2 = this.noiseSrc(true, true);
    const g2 = ctx.createGain(); g2.gain.value = level * 0.8;
    src2.connect(g2); g2.connect(g);
    g.gain.linearRampToValueAtTime(level, ctx.currentTime + 3);
    src.start(); src2.start();
    return this.makeLoop([src, src2], g);
  }

  hum(pos: THREE.Vector3, freq = 50, level = 0.05): LoopHandle | null {
    const ctx = this.ctx; if (!ctx) return null;
    const o1 = ctx.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = freq;
    const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = freq * 2 + 0.7;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 260;
    const g = ctx.createGain(); g.gain.value = level;
    o1.connect(lp); o2.connect(lp); lp.connect(g);
    const p = this.panner(pos, 1.5, 25); g.connect(p);
    o1.start(); o2.start();
    return this.makeLoop([o1, o2], g, p);
  }

  buzz(pos: THREE.Vector3, level = 0.012): LoopHandle | null {
    const ctx = this.ctx; if (!ctx) return null;
    const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 120;
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 2200; bp.Q.value = 3;
    const g = ctx.createGain(); g.gain.value = level;
    o.connect(bp); bp.connect(g);
    const p = this.panner(pos, 1, 18); g.connect(p);
    o.start();
    return this.makeLoop([o], g, p);
  }

  engine(level = 0.12, pos?: THREE.Vector3): LoopHandle | null {
    const ctx = this.ctx; if (!ctx) return null;
    const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 38;
    const o2 = ctx.createOscillator(); o2.type = 'square'; o2.frequency.value = 19;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 180;
    const n = this.noiseSrc(true, true); const ng = ctx.createGain(); ng.gain.value = 0.4;
    const g = ctx.createGain(); g.gain.value = 0;
    o.connect(lp); o2.connect(lp); n.connect(ng); ng.connect(lp); lp.connect(g);
    const p = this.panner(pos, 3, 120); g.connect(p);
    g.gain.linearRampToValueAtTime(level, ctx.currentTime + 0.6);
    o.start(); o2.start(); n.start();
    return this.makeLoop([o, o2, n], g, p, {
      setLevel: (v) => { o.frequency.setTargetAtTime(30 + v * 30, ctx.currentTime, 0.3); },
    });
  }

  fire(pos: THREE.Vector3, level = 0.5): LoopHandle | null {
    const ctx = this.ctx; if (!ctx) return null;
    const n = this.noiseSrc(true, true);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900;
    const n2 = this.noiseSrc();
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 3000;
    const g2 = ctx.createGain(); g2.gain.value = 0.15;
    const g = ctx.createGain(); g.gain.value = level;
    n.connect(lp); lp.connect(g); n2.connect(hp); hp.connect(g2); g2.connect(g);
    const p = this.panner(pos, 4, 80); g.connect(p);
    n.start(); n2.start();
    return this.makeLoop([n, n2], g, p);
  }

  drone(level = 0.08): LoopHandle | null {
    const ctx = this.ctx; if (!ctx) return null;
    const o1 = ctx.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = 41.2;
    const o2 = ctx.createOscillator(); o2.type = 'sawtooth'; o2.frequency.value = 43.6;
    const o3 = ctx.createOscillator(); o3.type = 'sine'; o3.frequency.value = 311;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 220;
    const g3 = ctx.createGain(); g3.gain.value = 0.08;
    const g = ctx.createGain(); g.gain.value = 0;
    o1.connect(lp); o2.connect(lp); o3.connect(g3); g3.connect(g); lp.connect(g); g.connect(this.music);
    g.gain.linearRampToValueAtTime(level, ctx.currentTime + 4);
    o1.start(); o2.start(); o3.start();
    return this.makeLoop([o1, o2, o3], g);
  }

  // ---------------- One shots ----------------
  footstep(surface: 'tile' | 'concrete' | 'wood' | 'wet' | 'metal' = 'concrete', vol = 0.35, pos?: THREE.Vector3, heavy = false) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false);
    const f = ctx.createBiquadFilter(); f.type = 'bandpass';
    const base = { tile: 1300, concrete: 700, wood: 380, wet: 2400, metal: 2600 }[surface];
    f.frequency.value = base * (0.85 + Math.random() * 0.3) * (heavy ? 0.5 : 1); f.Q.value = 1.2;
    const g = ctx.createGain();
    this.env(g, t, 0.005, vol * (0.7 + Math.random() * 0.3), surface === 'wet' ? 0.16 : 0.09);
    s.connect(f); f.connect(g); g.connect(this.panner(pos, 1.5, 30));
    s.start(t); s.stop(t + 0.3);
    // low thump
    const o = ctx.createOscillator(); o.frequency.setValueAtTime(heavy ? 70 : 110, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.08);
    const og = ctx.createGain(); this.env(og, t, 0.003, vol * (heavy ? 0.9 : 0.4), 0.08);
    o.connect(og); og.connect(this.panner(pos, 1.5, 30)); o.start(t); o.stop(t + 0.15);
  }

  door(pos: THREE.Vector3 | undefined, open: boolean, heavy = false) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    if (open || Math.random() < 0.5) {
      const o = ctx.createOscillator(); o.type = 'sawtooth';
      const st = 180 + Math.random() * 120;
      o.frequency.setValueAtTime(st, t); o.frequency.linearRampToValueAtTime(st * 0.6, t + 0.5); o.frequency.linearRampToValueAtTime(st * 0.8, t + 0.7);
      const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1200; bp.Q.value = 10;
      const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.25, t + 0.1); g.gain.linearRampToValueAtTime(0.0001, t + 0.75);
      o.connect(bp); bp.connect(g); g.connect(this.panner(pos)); o.start(t); o.stop(t + 0.8);
    }
    if (!open) {
      const o = ctx.createOscillator(); o.frequency.setValueAtTime(heavy ? 60 : 90, t + 0.05); o.frequency.exponentialRampToValueAtTime(30, t + 0.3);
      const g = ctx.createGain(); this.env(g, t + 0.05, 0.005, 0.7, 0.3);
      o.connect(g); g.connect(this.panner(pos)); o.start(t); o.stop(t + 0.5);
      const s = this.noiseSrc(false); const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 600;
      const g2 = ctx.createGain(); this.env(g2, t + 0.05, 0.003, 0.4, 0.15);
      s.connect(lp); lp.connect(g2); g2.connect(this.panner(pos)); s.start(t); s.stop(t + 0.4);
    }
  }

  bell(pos?: THREE.Vector3) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    [1318, 1760, 2637].forEach((f, i) => {
      const o = ctx.createOscillator(); o.frequency.value = f;
      const g = ctx.createGain(); this.env(g, t + i * 0.09, 0.004, 0.12, 1.4);
      o.connect(g); g.connect(this.panner(pos)); o.start(t + i * 0.09); o.stop(t + 2);
    });
  }

  beep(pos?: THREE.Vector3) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 1850;
    const g = ctx.createGain(); g.gain.setValueAtTime(0.06, t); g.gain.setValueAtTime(0, t + 0.11);
    o.connect(g); g.connect(this.panner(pos)); o.start(t); o.stop(t + 0.15);
  }

  click() {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false); const g = ctx.createGain(); this.env(g, t, 0.001, 0.25, 0.03);
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 2000;
    s.connect(hp); hp.connect(g); g.connect(this.sfx); s.start(t); s.stop(t + 0.06);
  }

  staticBurst(dur = 0.4, vol = 0.2) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false); const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 3000; bp.Q.value = 0.5;
    const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.linearRampToValueAtTime(0.0001, t + dur);
    s.connect(bp); bp.connect(g); g.connect(this.sfx); s.start(t); s.stop(t + dur + 0.05);
  }

  ring(pos: THREE.Vector3 | undefined, kind: 'phone' | 'alarm' = 'phone'): LoopHandle | null {
    const ctx = this.ctx; if (!ctx) return null;
    const g = ctx.createGain(); g.gain.value = 1;
    const p = this.panner(pos, 2, 40); g.connect(p);
    let alive = true;
    const schedule = () => {
      if (!alive || !this.ctx) return;
      const t = ctx.currentTime + 0.02;
      if (kind === 'phone') {
        for (let i = 0; i < 2; i++) {
          [440, 480].forEach((f) => {
            const o = ctx.createOscillator(); o.frequency.value = f;
            const og = ctx.createGain(); og.gain.setValueAtTime(0, t + i * 0.5); og.gain.linearRampToValueAtTime(0.08, t + i * 0.5 + 0.02); og.gain.setValueAtTime(0.08, t + i * 0.5 + 0.4); og.gain.linearRampToValueAtTime(0, t + i * 0.5 + 0.42);
            o.connect(og); og.connect(g); o.start(t + i * 0.5); o.stop(t + i * 0.5 + 0.45);
          });
        }
      } else {
        for (let i = 0; i < 4; i++) {
          const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 988;
          const og = ctx.createGain(); og.gain.setValueAtTime(0.05, t + i * 0.16); og.gain.setValueAtTime(0, t + i * 0.16 + 0.08);
          o.connect(og); og.connect(g); o.start(t + i * 0.16); o.stop(t + i * 0.16 + 0.1);
        }
      }
      timer = window.setTimeout(schedule, kind === 'phone' ? 3000 : 1100);
    };
    let timer = window.setTimeout(schedule, 10);
    const h = this.makeLoop([], g, p);
    const stop0 = h.stop;
    h.stop = (f) => { alive = false; clearTimeout(timer); stop0(f ?? 0.05); };
    return h;
  }

  breath(pos?: THREE.Vector3, vol = 0.12, inhale = true, dur = 0.9) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false);
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.setValueAtTime(inhale ? 900 : 650, t); bp.frequency.linearRampToValueAtTime(inhale ? 1400 : 500, t + dur); bp.Q.value = 1.6;
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + dur * 0.4); g.gain.linearRampToValueAtTime(0.0001, t + dur);
    s.connect(bp); bp.connect(g); g.connect(this.panner(pos, 1, 15)); s.start(t); s.stop(t + dur + 0.05);
  }

  heartbeat(vol = 0.5) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    [0, 0.22].forEach((d, i) => {
      const o = ctx.createOscillator(); o.frequency.setValueAtTime(65, t + d); o.frequency.exponentialRampToValueAtTime(35, t + d + 0.15);
      const g = ctx.createGain(); this.env(g, t + d, 0.01, vol * (i ? 0.6 : 1), 0.18);
      o.connect(g); g.connect(this.music); o.start(t + d); o.stop(t + d + 0.3);
    });
  }

  stinger(vol = 0.35) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    [220, 233, 311, 330, 466].forEach((f) => {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f * (1 + Math.random() * 0.01);
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(400, t); lp.frequency.linearRampToValueAtTime(3500, t + 0.3);
      const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol * 0.18, t + 0.08); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.4);
      o.connect(lp); lp.connect(g); g.connect(this.music); o.start(t); o.stop(t + 2.5);
    });
    const s = this.noiseSrc(false); const g = ctx.createGain(); this.env(g, t, 0.01, vol * 0.5, 0.6);
    s.connect(g); g.connect(this.music); s.start(t); s.stop(t + 0.8);
  }

  scream(pos?: THREE.Vector3, vol = 0.6) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(320, t); o.frequency.linearRampToValueAtTime(900, t + 0.25); o.frequency.linearRampToValueAtTime(500, t + 1.1);
    const fm = ctx.createOscillator(); fm.frequency.value = 37; const fg = ctx.createGain(); fg.gain.value = 140;
    fm.connect(fg); fg.connect(o.frequency);
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1500; bp.Q.value = 1.5;
    const g = ctx.createGain(); this.env(g, t, 0.02, vol, 1.1);
    const s = this.noiseSrc(false); const sg = ctx.createGain(); this.env(sg, t, 0.01, vol * 0.6, 0.9);
    o.connect(bp); s.connect(sg); sg.connect(bp); bp.connect(g); g.connect(this.panner(pos, 3, 80));
    o.start(t); fm.start(t); s.start(t); o.stop(t + 1.3); fm.stop(t + 1.3); s.stop(t + 1.3);
  }

  growl(pos?: THREE.Vector3, vol = 0.4) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 62;
    const am = ctx.createOscillator(); am.frequency.value = 23; const ag = ctx.createGain(); ag.gain.value = 0.5;
    const g = ctx.createGain(); g.gain.value = 0;
    am.connect(ag); ag.connect(g.gain);
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 500;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.3); g.gain.linearRampToValueAtTime(0.0001, t + 1.5);
    o.connect(lp); lp.connect(g); g.connect(this.panner(pos, 2, 40));
    o.start(t); am.start(t); o.stop(t + 1.6); am.stop(t + 1.6);
  }

  bark(pos?: THREE.Vector3, vol = 0.5) {
    const ctx = this.ctx; if (!ctx) return;
    const t0 = ctx.currentTime;
    const n = 2 + Math.floor(Math.random() * 2);
    for (let i = 0; i < n; i++) {
      const t = t0 + i * (0.35 + Math.random() * 0.15);
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.setValueAtTime(380, t); o.frequency.exponentialRampToValueAtTime(140, t + 0.14);
      const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 900; bp.Q.value = 2;
      const g = ctx.createGain(); this.env(g, t, 0.01, vol, 0.16);
      o.connect(bp); bp.connect(g); g.connect(this.panner(pos, 4, 120)); o.start(t); o.stop(t + 0.25);
    }
  }

  knock(pos?: THREE.Vector3, count = 3, vol = 0.6, gap = 0.32) {
    const ctx = this.ctx; if (!ctx) return;
    const t0 = ctx.currentTime;
    for (let i = 0; i < count; i++) {
      const t = t0 + i * gap * (0.9 + Math.random() * 0.2);
      const o = ctx.createOscillator(); o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(50, t + 0.12);
      const g = ctx.createGain(); this.env(g, t, 0.002, vol, 0.15);
      const s = this.noiseSrc(false); const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900;
      const sg = ctx.createGain(); this.env(sg, t, 0.001, vol * 0.5, 0.06);
      o.connect(g); s.connect(lp); lp.connect(sg);
      const p = this.panner(pos, 2, 50); g.connect(p); sg.connect(p);
      o.start(t); o.stop(t + 0.2); s.start(t); s.stop(t + 0.1);
    }
  }

  glass(pos?: THREE.Vector3, vol = 0.5) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false); const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 2500;
    const g = ctx.createGain(); this.env(g, t, 0.002, vol, 0.35);
    s.connect(hp); hp.connect(g); const p = this.panner(pos, 2, 50); g.connect(p); s.start(t); s.stop(t + 0.5);
    for (let i = 0; i < 7; i++) {
      const o = ctx.createOscillator(); o.frequency.value = 2500 + Math.random() * 4500;
      const og = ctx.createGain(); const d = Math.random() * 0.25; this.env(og, t + d, 0.001, vol * 0.12, 0.25);
      o.connect(og); og.connect(p); o.start(t + d); o.stop(t + d + 0.3);
    }
  }

  clink(pos?: THREE.Vector3) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator(); o.frequency.value = 2100 + Math.random() * 600;
    const g = ctx.createGain(); this.env(g, t, 0.001, 0.15, 0.2);
    o.connect(g); g.connect(this.panner(pos)); o.start(t); o.stop(t + 0.25);
  }

  whisper(pos?: THREE.Vector3, vol = 0.18, dur = 2.2) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false);
    const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 4;
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t);
    let tt = t;
    while (tt < t + dur) {
      const sy = 0.08 + Math.random() * 0.15;
      bp.frequency.setValueAtTime(1800 + Math.random() * 2500, tt);
      g.gain.linearRampToValueAtTime(vol * (0.4 + Math.random() * 0.6), tt + sy * 0.3);
      g.gain.linearRampToValueAtTime(0.0, tt + sy);
      tt += sy + Math.random() * 0.08;
    }
    s.connect(bp); bp.connect(g); g.connect(this.panner(pos, 1.5, 25)); s.start(t); s.stop(t + dur + 0.2);
  }

  voice(pos: THREE.Vector3 | undefined, pitch = 120, dur = 1.6, vol = 0.14, eerie = false) {
    const ctx = this.ctx; if (!ctx) return;
    const t0 = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = 'sawtooth';
    const f1 = ctx.createBiquadFilter(); f1.type = 'bandpass'; f1.Q.value = 5;
    const f2 = ctx.createBiquadFilter(); f2.type = 'bandpass'; f2.Q.value = 6;
    const g = ctx.createGain(); g.gain.value = 0;
    const out = ctx.createGain(); out.gain.value = 1;
    o.connect(f1); o.connect(f2); f1.connect(g); f2.connect(g); g.connect(out);
    out.connect(this.panner(pos, 1.5, 25));
    let t = t0;
    const formants = [[730, 1090], [270, 2290], [300, 870], [530, 1840], [660, 1720], [440, 1020]];
    while (t < t0 + dur) {
      const sy = 0.09 + Math.random() * 0.12;
      const fm = formants[Math.floor(Math.random() * formants.length)];
      f1.frequency.setValueAtTime(fm[0], t); f2.frequency.setValueAtTime(fm[1], t);
      const p = eerie ? pitch * (0.5 + Math.random()) : pitch * (0.9 + Math.random() * 0.25);
      o.frequency.setValueAtTime(p, t);
      g.gain.linearRampToValueAtTime(vol, t + sy * 0.3);
      g.gain.linearRampToValueAtTime(vol * 0.3, t + sy);
      t += sy;
      if (Math.random() < 0.15) { g.gain.linearRampToValueAtTime(0, t + 0.05); t += 0.12; }
    }
    g.gain.linearRampToValueAtTime(0, t + 0.05);
    o.start(t0); o.stop(t + 0.1);
  }

  thunder() {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false, true); const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 300;
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.9, t + 0.15); g.gain.exponentialRampToValueAtTime(0.0001, t + 3.5);
    s.connect(lp); lp.connect(g); g.connect(this.amb); s.start(t); s.stop(t + 3.6);
  }

  carPass(level = 0.3): void {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false, true); s.loop = true;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(300, t); lp.frequency.linearRampToValueAtTime(1200, t + 3); lp.frequency.linearRampToValueAtTime(250, t + 6);
    const pan = ctx.createStereoPanner(); const dir = Math.random() < 0.5 ? -1 : 1;
    pan.pan.setValueAtTime(-dir, t); pan.pan.linearRampToValueAtTime(dir, t + 6);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(level, t + 3); g.gain.linearRampToValueAtTime(0.0001, t + 6);
    s.connect(lp); lp.connect(g); g.connect(pan); pan.connect(this.amb); s.start(t); s.stop(t + 6.2);
  }

  generatorPull(pos?: THREE.Vector3, success = false) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const s = this.noiseSrc(false); const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.setValueAtTime(400, t); bp.frequency.linearRampToValueAtTime(1600, t + 0.4); bp.Q.value = 3;
    const g = ctx.createGain(); this.env(g, t, 0.05, 0.4, 0.4);
    s.connect(bp); bp.connect(g); g.connect(this.panner(pos)); s.start(t); s.stop(t + 0.6);
    const n = success ? 1 : 3;
    for (let i = 0; i < n; i++) {
      const tt = t + 0.45 + i * 0.12;
      const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 45;
      const og = ctx.createGain(); this.env(og, tt, 0.005, 0.25, 0.1);
      o.connect(og); og.connect(this.panner(pos)); o.start(tt); o.stop(tt + 0.15);
    }
  }

  // ---------------- Dynamic layers ----------------
  setChase(on: boolean) {
    const ctx = this.ctx; if (!ctx) return;
    if (on === this.chaseOn) return;
    this.chaseOn = on;
    if (on) {
      const o1 = ctx.createOscillator(); o1.type = 'sawtooth'; o1.frequency.value = 55;
      const o2 = ctx.createOscillator(); o2.type = 'sawtooth'; o2.frequency.value = 58.3;
      const o3 = ctx.createOscillator(); o3.type = 'triangle'; o3.frequency.value = 880;
      const o4 = ctx.createOscillator(); o4.type = 'triangle'; o4.frequency.value = 932;
      const trem = ctx.createOscillator(); trem.frequency.value = 7; const tg = ctx.createGain(); tg.gain.value = 0.03;
      const hg = ctx.createGain(); hg.gain.value = 0.035; trem.connect(tg); tg.connect(hg.gain);
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 400;
      const g = ctx.createGain(); g.gain.value = 0;
      o1.connect(lp); o2.connect(lp); lp.connect(g); o3.connect(hg); o4.connect(hg); hg.connect(g); g.connect(this.music);
      g.gain.linearRampToValueAtTime(0.35, ctx.currentTime + 0.8);
      [o1, o2, o3, o4, trem].forEach((o) => o.start());
      this.chase = this.makeLoop([o1, o2, o3, o4, trem], g);
      this.nextChasePulse = ctx.currentTime;
      this.stinger(0.4);
    } else if (this.chase) {
      this.chase.stop(3);
      this.chase = null;
    }
  }

  setBreath(level: number) { this.breathLevel = level; }
  setHeart(level: number) { this.heartLevel = level; }

  update() {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    if (this.breathLevel > 0.05 && t > this.nextBreath) {
      const rate = 1.6 - this.breathLevel * 0.9;
      this.breath(undefined, 0.05 + this.breathLevel * 0.12, true, rate * 0.45);
      setTimeout(() => this.breath(undefined, 0.05 + this.breathLevel * 0.1, false, rate * 0.5), rate * 450);
      this.nextBreath = t + rate;
    }
    if (this.heartLevel > 0.05 && t > this.nextHeart) {
      this.heartbeat(0.2 + this.heartLevel * 0.5);
      this.nextHeart = t + (1.1 - this.heartLevel * 0.6);
    }
    if (this.chaseOn && t > this.nextChasePulse) {
      const tt = this.nextChasePulse + 0.05;
      const o = ctx.createOscillator(); o.frequency.setValueAtTime(90, tt); o.frequency.exponentialRampToValueAtTime(35, tt + 0.2);
      const g = ctx.createGain(); this.env(g, tt, 0.005, 0.45, 0.25);
      o.connect(g); g.connect(this.music); o.start(tt); o.stop(tt + 0.3);
      this.nextChasePulse += 0.42;
      if (this.nextChasePulse < t) this.nextChasePulse = t + 0.42;
    }
  }
}

export const audio = new AudioManager();
