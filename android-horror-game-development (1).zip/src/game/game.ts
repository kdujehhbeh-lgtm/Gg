// Core engine: renderer, loop, level loading, interaction, dialogue, CCTV, hiding, death/checkpoints, chase layer, weather, traffic
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { installInteriorFog, setFogBox, clearFogBox } from './fog';
import { preloadPosterPhotos } from './posters';
installInteriorFog();
preloadPosterPhotos();
import { ui, settingsStore, writeSave, loadSave, newSave, type SaveData, type DialogueOption } from './store';
import { input, consume, installDesktopInput } from './input';
import { audio, type LoopHandle } from './audio';
import { Player, type Surface } from './player';
import { setMaterialQuality, clearMaterialCache, tex } from './textures';
import { clearGeoCache, type Interactable } from './world';
import type { Collision } from './physics';
import { buildStation, type StationLevel, type HideSpot } from './levels/station';
import { buildHouse, type HouseLevel } from './levels/house';
import { buildDrive, type DriveLevel, type DriveMode } from './levels/drive';
import { NPCManager, type Customer } from './npc';
import { MonsterManager, type Monster, ShifterMonster, FacelessMonster } from './monsters';
import { Director } from './director';
import { Story } from './story';

interface Timer { t: number; fn: () => void; gen: number }

export class Game {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  player: Player;
  canvas: HTMLCanvasElement;
  shadows = false;
  level: 'none' | 'house' | 'drive' | 'station' = 'none';
  station: StationLevel | null = null;
  house: HouseLevel | null = null;
  drive: DriveLevel | null = null;
  col: Collision | null = null;
  interactables: Interactable[] = [];
  save: SaveData = newSave();
  npcs: NPCManager;
  monsters: MonsterManager;
  director: Director;
  story: Story;
  time = 0;
  gen = 0;
  private timers: Timer[] = [];
  private frameFns: { fn: (dt: number) => boolean; gen: number }[] = [];
  private loops: LoopHandle[] = [];
  noises: { pos: THREE.Vector3; r: number; t: number }[] = [];
  hideSeenBy = new Set<Monster>();
  dialogueOpen = false;
  private dialogueCb: ((id: string) => void) | null = null;
  cctvIndex = -1;
  cctvGlitch = false;
  dying = false;
  running = false;
  item: string | null = null;
  hemi!: THREE.HemisphereLight;
  moon!: THREE.DirectionalLight;
  rain: THREE.LineSegments | null = null;
  raining = false;
  private lightningT = 20;
  private trafficT = 15;
  private cars: { g: THREE.Group; snd: LoopHandle | null; dir: number; z: number }[] = [];
  private fpsAcc = 0; private fpsN = 0;
  private uiAcc = 0;
  private chaseOn = false;
  private envTex: THREE.Texture | null = null;
  ambience: Record<string, LoopHandle | null> = {};
  driveLook = { yaw: 0, pitch: 0 };
  private raf = 0;
  private last = performance.now();

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const s = settingsStore.get();
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: s.quality !== 'low', powerPreference: 'high-performance' });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.camera = new THREE.PerspectiveCamera(s.fov, 16 / 9, 0.05, 160);
    this.camera.layers.enable(0); this.camera.layers.enable(1);
    this.scene.add(this.camera);
    this.applyQuality();
    this.player = new Player(this.camera, this.shadows);
    this.npcs = new NPCManager(this);
    this.monsters = new MonsterManager(this);
    this.director = new Director(this);
    this.story = new Story(this);
    installDesktopInput(canvas);
    settingsStore.subscribe(() => { this.camera.fov = settingsStore.get().fov; this.camera.updateProjectionMatrix(); this.applyPixelRatio(); });
    window.addEventListener('resize', this.resize);
    this.resize();
    this.loop();
  }

  // ---------------- Quality ----------------
  applyQuality() {
    const q = settingsStore.get().quality;
    setMaterialQuality(q);
    this.shadows = q === 'high';
    this.renderer.shadowMap.enabled = this.shadows;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.applyPixelRatio();
    if (q !== 'low' && !this.envTex) {
      const pm = new THREE.PMREMGenerator(this.renderer);
      this.envTex = pm.fromScene(new RoomEnvironment(), 0.04).texture;
      pm.dispose();
    }
    this.scene.environment = q !== 'low' ? this.envTex : null;
    (this.scene as any).environmentIntensity = 0.06;
  }
  applyPixelRatio() {
    const q = settingsStore.get().quality; const dpr = window.devicePixelRatio || 1;
    this.renderer.setPixelRatio(q === 'low' ? Math.min(dpr, 1) * 0.65 : q === 'medium' ? Math.min(dpr, 1.5) * 0.8 : Math.min(dpr, 2));
  }
  resize = () => {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.station?.cams.forEach((c) => { c.cam.aspect = w / h; c.cam.updateProjectionMatrix(); });
  };

  // ---------------- Async helpers (tied to level generation) ----------------
  sleep(s: number) { const gen = this.gen; return new Promise<void>((res) => this.timers.push({ t: this.time + s, fn: res, gen })); }
  after(s: number, fn: () => void) { this.timers.push({ t: this.time + s, fn, gen: this.gen }); }
  onFrame(fn: (dt: number) => boolean) { this.frameFns.push({ fn, gen: this.gen }); }
  tween(dur: number, fn: (k: number) => void) {
    return new Promise<void>((res) => { let t = 0; this.onFrame((dt) => { t += dt; const k = Math.min(1, t / dur); fn(k); if (k >= 1) { res(); return false; } return true; }); });
  }
  fadeTo(v: number, dur = 1) { const s = ui.get().fade; return this.tween(dur, (k) => ui.set({ fade: s + (v - s) * k })); }

  // ---------------- UI helpers ----------------
  private subTimer = 0;
  say(speaker: string | undefined, text: string, dur = 3) { ui.set({ subtitle: { speaker, text } }); const id = ++this.subTimer; setTimeout(() => { if (id === this.subTimer) ui.set({ subtitle: null }); }, dur * 1000); }
  private toastTimer = 0;
  toast(text: string, dur = 2.5) { ui.set({ toast: text }); const id = ++this.toastTimer; setTimeout(() => { if (id === this.toastTimer) ui.set({ toast: null }); }, dur * 1000); }
  setObjective(t: string | null) { ui.set({ objective: t, objectiveFlash: Date.now() }); }
  showNote(title: string, body: string) { ui.set({ note: { title, body } }); this.player.frozen = true; audio.click(); }
  closeNote() { ui.set({ note: null }); if (!this.dialogueOpen && this.cctvIndex < 0) this.player.frozen = false; this.story.onNoteClosed(); }
  showMessage(text: string, dur = 4) { ui.set({ message: text }); return this.sleep(dur).then(() => ui.set({ message: null })); }

  openDialogue(speaker: string, text: string, options: DialogueOption[], cb: (id: string) => void) {
    this.dialogueOpen = true; this.dialogueCb = cb; this.player.frozen = true;
    ui.set({ dialogue: { speaker, text, options } });
  }
  updateDialogue(text: string, options: DialogueOption[]) { const d = ui.get().dialogue; if (d) ui.set({ dialogue: { ...d, text, options } }); }
  closeDialogue() { this.dialogueOpen = false; this.dialogueCb = null; ui.set({ dialogue: null }); if (!ui.get().note && this.cctvIndex < 0 && !this.dying) this.player.frozen = false; }
  choose(id: string) { audio.click(); this.dialogueCb?.(id); }

  // ---------------- Flags / items / save ----------------
  get flags() { return this.save.flags; }
  setItem(id: string | null, mesh?: THREE.Object3D | null) {
    this.item = id; this.save.item = id;
    this.player.setHeld(mesh ? mesh : null);
    ui.set({ item: id });
  }
  violation(reason: string) { this.save.violations++; this.story.onViolation(reason); }
  checkpoint() {
    this.save.task = this.story.taskIndex; this.save.chapter = this.story.chapter;
    writeSave(this.save);
    ui.set({ saving: true }); setTimeout(() => ui.set({ saving: false }), 1600);
  }

  // ---------------- World queries ----------------
  isLooking(p: THREE.Vector3, dot = 0.94): boolean {
    if (this.cctvIndex >= 0) return false;
    const cp = this.camera.position;
    if (Math.abs(cp.y - p.y) > 3.5) return false; // different floor
    const d = new THREE.Vector3().subVectors(p, cp); const len = d.length();
    if (len > 45 || len < 0.01) return false;
    d.divideScalar(len);
    const f = this.player.lookDir();
    if (d.dot(f) < dot) return false;
    return !this.col || this.col.los(cp.clone(), p, Math.min(cp.y, p.y) + 0.2 > 3 ? 1.4 : (cp.y + p.y) / 2);
  }
  flashlightOn(p: THREE.Vector3) {
    if (!this.player.flashOn) return false;
    const cp = this.camera.position; const d = new THREE.Vector3().subVectors(p, cp); const len = d.length();
    if (len > 20) return false; d.divideScalar(len);
    return d.dot(this.player.lookDir()) > 0.93 && (!this.col || this.col.los(cp.clone(), p, 1.4));
  }
  emitNoise(pos: THREE.Vector3, r: number) { this.noises.push({ pos: pos.clone(), r, t: this.time + 1.5 }); }
  regionOf(p: THREE.Vector3): string {
    if (p.y < -2) return 'basement';
    if (p.x > -14 && p.x < 14 && p.z < 4 && p.z > -5) return 'sales';
    if (p.x < -2 && p.x > -14 && p.z <= -5 && p.z > -12) return 'storage';
    if (p.x >= -2 && p.x < 2 && p.z <= -5 && p.z > -12) return 'corridor';
    if (p.x >= 2 && p.x < 8 && p.z <= -5 && p.z > -8.5) return 'toilet';
    if (p.x >= 8 && p.z <= -5 && p.z > -8.5 && p.x < 14) return 'office';
    if (p.x >= 2 && p.z <= -8.5 && p.z > -12 && p.x < 14) return 'staff';
    if (p.z < -12) return 'back';
    return 'canopy';
  }
  flicker(group: string, dur: number) { this.station?.lights[group]?.flicker(dur); }
  flickerAt(p: THREE.Vector3, dur: number) { this.flicker(this.regionOf(p), dur); }
  inBuilding(p: THREE.Vector3) { return p.x > -14 && p.x < 14 && p.z < 4 && p.z > -12 && p.y > -1; }
  addInteract(i: Interactable) { this.interactables.push(i); return i; }

  // ---------------- Level management ----------------
  private unload() {
    this.gen++;
    this.timers = []; this.frameFns = [];
    this.npcs.clear(); this.monsters.clear();
    this.cars.forEach((c) => { this.scene.remove(c.g); c.snd?.stop(0.1); }); this.cars = [];
    audio.stopAll(); this.loops = []; this.ambience = {};
    this.interactables = []; this.noises = []; this.hideSeenBy.clear();
    this.player.setHeld(null); this.player.hide = null; this.player.frozen = false; this.player.setFlash(false);
    if (this.camera.parent !== this.scene) this.scene.add(this.camera);
    // dispose scene children except camera
    const keep = new Set<THREE.Object3D>([this.camera]);
    [...this.scene.children].forEach((c) => {
      if (keep.has(c)) return;
      this.scene.remove(c);
      c.traverse((o) => { const m = o as THREE.Mesh; if (m.geometry && !(m as any).isInstancedMesh) m.geometry.dispose?.(); if ((o as any).isInstancedMesh) m.geometry.dispose(); });
    });
    clearMaterialCache(); clearGeoCache();
    this.station = null; this.house = null; this.drive = null; this.col = null; this.rain = null; this.raining = false;
    this.dying = false; this.cctvIndex = -1; this.dialogueOpen = false; this.chaseOn = false;
    this.player.speedMul = 1;
    ui.set({ cctv: null, dialogue: null, note: null, prompt: null, chase: false, dead: false, jumpscare: 0, hiding: false, message: null, subtitle: null, driving: false });
    this.canvas.style.filter = '';
  }

  private baseLights(intensity = 0.35, fogDensity = 0.03, fogColor = 0x070a0f) {
    this.scene.background = new THREE.Color(fogColor);
    this.scene.fog = new THREE.FogExp2(fogColor, fogDensity);
    this.hemi = new THREE.HemisphereLight(0x2a3a55, 0x0a0a0c, intensity); this.scene.add(this.hemi);
    this.moon = new THREE.DirectionalLight(0x7a8ab8, 0.18); this.moon.position.set(-30, 50, 20); this.scene.add(this.moon);
  }

  async loading(text: string, tip: string, work: () => void | Promise<void>) {
    ui.set({ screen: 'loading', loading: { text, progress: 0.1, tip } });
    await new Promise((r) => setTimeout(r, 60));
    ui.set({ loading: { text, progress: 0.45, tip } });
    await new Promise((r) => setTimeout(r, 30));
    await work();
    // warm-up render to compile shaders
    try { this.renderer.compile(this.scene, this.camera); } catch { /* */ }
    ui.set({ loading: { text, progress: 1, tip } });
    await new Promise((r) => setTimeout(r, 350));
    ui.set({ screen: 'game', loading: null });
  }

  async startNew() {
    this.save = newSave(); writeSave(this.save);
    await this.loadChapter(1, 0);
  }
  async continueGame() {
    const s = loadSave(); if (!s) return this.startNew();
    this.save = s;
    await this.loadChapter(s.chapter, s.task);
  }

  async loadChapter(ch: number, task: number) {
    audio.init();
    this.running = true;
    const tips = ['همیشه به صداها گوش کن.', 'نور می‌تواند هم نجاتت دهد، هم لوت دهد.', 'بعضی سؤال‌ها بهتر است پرسیده نشوند.', 'هیچ مخفیگاهی کاملاً امن نیست.', 'دویدن صدا تولید می‌کند. خم شدن نه.'];
    const tip = tips[Math.floor(Math.random() * tips.length)];
    this.unload();
    applyQualityIfChanged(this);
    this.save.chapter = ch; this.save.task = task;
    if (ch === 1) {
      await this.loading('خانه', tip, () => this.setupHouse());
      this.story.start(1, task);
    } else {
      await this.loading(`فصل ${['', '۱', '۲', '۳', '۴', '۵'][ch]}`, tip, () => this.setupStation(ch));
      this.story.start(ch, task);
    }
  }

  private setupHouse() {
    this.level = 'house';
    setFogBox(-0.25, 10.25, -0.25, 6.25);
    this.baseLights(0.22, 0.025, 0x05070b);
    const h = buildHouse(this.scene, settingsStore.get().quality);
    this.house = h; this.col = h.col;
    this.player.surfaceFn = (p) => (p.x < 10 ? 'wood' : 'concrete');
    this.loops.push(audio.wind(0.12)!);
  }

  async startDrive(mode: DriveMode = 'arrive', onEvent: (id: string) => void = () => {}) {
    this.unload();
    this.level = 'drive';
    clearFogBox();
    this.baseLights(mode === 'dawn' ? 0.4 : 0.25, 0.03, 0x06080c);
    const d = buildDrive(this.scene, settingsStore.get().quality, mode);
    d.onEvent = onEvent;
    this.drive = d;
    d.seat.add(this.camera); this.camera.position.set(0, 0, 0); this.camera.rotation.set(0, 0, 0);
    this.driveLook = { yaw: 0, pitch: -0.05 };
    input.move.x = 0; input.move.y = 0;
    ui.set({ driving: true, cutscene: false, skippable: mode === 'arrive' });
    this.loops.push(audio.wind(0.08)!);
    this.onFrame((dt) => { d.update(dt); return this.level === 'drive'; });
  }

  private setupStation(ch: number) {
    this.level = 'station';
    setFogBox(-14.35, 14.35, -12.35, 4.35);
    const q = settingsStore.get().quality;
    this.baseLights(0.3, ch >= 4 ? 0.036 : 0.028, ch >= 4 ? 0x06080b : 0x080b10);
    const st = buildStation(this.scene, q);
    this.station = st; this.col = st.col;
    st.cams.forEach((c) => { c.cam.aspect = this.camera.aspect; c.cam.updateProjectionMatrix(); });
    this.player.surfaceFn = (p): Surface => {
      if (p.y < -2) return 'concrete';
      const r = this.regionOf(p);
      if (r === 'storage') return 'concrete';
      if (r === 'staff') return 'wood';
      if (r === 'sales' || r === 'corridor' || r === 'toilet' || r === 'office') return 'tile';
      return this.raining ? 'wet' : 'concrete';
    };
    this.player.hasFlash = true;
    // ambience
    this.ambience.wind = audio.wind(ch >= 4 ? 0.16 : 0.2);
    this.ambience.fridge = audio.hum(new THREE.Vector3(-13, 1, -1), 50, 0.06);
    this.ambience.buzz = audio.buzz(new THREE.Vector3(0, 3, -0.5), 0.014);
    this.ambience.buzz2 = audio.buzz(new THREE.Vector3(-8, 3, -8.5), 0.01);
    this.ambience.coffee = audio.hum(new THREE.Vector3(13, 1, 2.4), 60, 0.02);
    if (ch >= 4) { this.setRain(true); }
    this.registerStationInteracts();
  }

  setRain(on: boolean) {
    this.raining = on;
    if (on && !this.rain) {
      const N = settingsStore.get().quality === 'low' ? 500 : 1400;
      const pos = new Float32Array(N * 6);
      for (let i = 0; i < N; i++) { const x = (Math.random() - 0.5) * 36, y = Math.random() * 14, z = (Math.random() - 0.5) * 36; pos.set([x, y, z, x, y - 0.4, z], i * 6); }
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      this.rain = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: 0x8a9aaa, transparent: true, opacity: 0.35 }));
      this.rain.frustumCulled = false;
      this.scene.add(this.rain);
      this.ambience.rain = audio.rain(0.16);
    }
  }

  private registerStationInteracts() {
    const st = this.station!;
    // doors
    Object.values(st.doors).forEach((d) => {
      this.addInteract({
        id: 'door-' + d.name, pos: d.pos, range: 2.0,
        prompt: () => {
          if (this.story.doorPrompt) { const p = this.story.doorPrompt(d); if (p !== undefined) return p; }
          if (d.broken) return null;
          if (d.locked && !d.open) return 'قفل است';
          return d.open ? 'بستن در' : 'باز کردن در';
        },
        action: () => { if (this.story.doorAction?.(d)) return; d.toggle(); this.emitNoise(d.pos, 6); },
      });
    });
    // hide spots
    st.hide.forEach((h) => {
      this.addInteract({ id: 'hide-' + h.id, pos: h.pos.clone().setY(1.2), range: 1.7, prompt: () => `مخفی شدن (${h.name})`, action: () => this.enterHide(h) });
    });
  }

  enterHide(h: HideSpot) {
    // monsters that see you entering will remember
    this.hideSeenBy.clear();
    for (const m of this.monsters.list) if (m.root.visible && m.chasing && m.canSeePlayer(30)) this.hideSeenBy.add(m);
    this.player.enterHide(h);
    ui.set({ hiding: true });
  }
  exitHide() { this.player.exitHide(); ui.set({ hiding: false }); this.hideSeenBy.clear(); }

  // ---------------- CCTV ----------------
  openCCTV() {
    if (!this.station) return;
    this.cctvIndex = 0; this.player.frozen = true;
    audio.staticBurst(0.3, 0.15);
    this.canvas.style.filter = 'grayscale(1) contrast(1.35) brightness(1.25) sepia(0.15)';
    this.updateCCTVUI();
    this.story.onCCTV(0);
  }
  cctvNext(dir: number) {
    if (this.cctvIndex < 0 || !this.station) return;
    const n = this.station.cams.length;
    this.cctvIndex = (this.cctvIndex + dir + n) % n;
    audio.staticBurst(0.25, 0.12);
    this.updateCCTVUI();
    this.story.onCCTV(this.cctvIndex);
  }
  updateCCTVUI() { const c = this.station!.cams[this.cctvIndex]; ui.set({ cctv: { cam: this.cctvIndex, name: c.name, glitch: this.cctvGlitch || !this.station!.lights.sales.on } }); }
  closeCCTV() { this.cctvIndex = -1; this.player.frozen = false; this.canvas.style.filter = ''; ui.set({ cctv: null }); audio.click(); this.story.onCCTVClosed(); }

  // ---------------- Death ----------------
  killPlayer(m: Monster) {
    if (this.dying) return;
    this.dying = true;
    if (this.player.hide) this.exitHide();
    this.player.frozen = true;
    if (this.dialogueOpen) this.closeDialogue();
    const cam = this.camera.position; const f = this.player.lookDir(); f.y = 0; f.normalize();
    const headH = m.kind === 'tall' ? 2.95 : m.kind === 'dog' ? 2.0 : m.kind === 'shifter' && (m as ShifterMonster).variant === 'crawler' ? 1.0 : 1.66;
    m.root.visible = true;
    m.pos.set(cam.x + f.x * 0.75, cam.y - headH, cam.z + f.z * 0.75);
    m.yaw = Math.atan2(-f.x, -f.z); m.sync();
    m.state = 'gone';
    if (m instanceof FacelessMonster) m.h.neck.rotation.y = 0;
    this.player.shake = 1.4;
    audio.scream(undefined, 0.8); audio.stinger(0.5);
    ui.set({ jumpscare: 1, cutscene: true, chase: false });
    audio.setChase(false);
    this.save.deaths++;
    const gen = this.gen;
    setTimeout(() => { if (gen !== this.gen) return; ui.set({ fade: 1, jumpscare: 0, dead: true }); audio.stopAll(); }, 1100);
    setTimeout(() => { if (gen !== this.gen) return; ui.set({ dead: false }); const s = loadSave() ?? this.save; s.deaths = this.save.deaths; this.save = s; this.loadChapter(s.chapter, s.task); }, 4200);
  }

  /** used by watcher: something appears behind the player briefly */
  scheduleBehind() {
    this.after(8 + Math.random() * 10, () => {
      if (!this.station || this.dying) return;
      const pl = this.player; const f = pl.forward();
      const p = new THREE.Vector3(pl.pos.x - f.x * 1.6, 0, pl.pos.z - f.z * 1.6);
      if (this.col!.segmentBlocked(pl.pos.x, pl.pos.z, p.x, p.z, 1, { inflate: 0.2 })) return;
      const fm = new FacelessMonster(this); this.monsters.add(fm); fm.appear(p, Math.atan2(f.x, f.z));
      fm.state = 'approach'; fm.t = 3;
      audio.breath(p.clone().setY(1.6), 0.25, false, 1.3);
    });
  }

  /** anomalous customer has been provoked */
  anomalyReact(c: Customer) {
    if (c.removed || !this.station) return;
    if (this.dialogueOpen) this.closeDialogue();
    const r = Math.random();
    const st = this.station;
    if (r < 0.55 || this.story.chapter >= 4) {
      // transform into a creature under flickering light
      this.flicker('sales', 2.2);
      audio.staticBurst(0.6, 0.1);
      this.after(1.6, () => {
        if (c.removed) return;
        st.lights.sales.set(false);
        this.after(0.5, () => {
          st.lights.sales.set(true);
          c.removed = true;
          if (c.reflection) this.scene.remove(c.reflection.root);
          const sm = new ShifterMonster(this, c.h, c.pos.clone(), c.yaw);
          this.monsters.add(sm);
          st.doors.front.setOpen(false); st.doors.front.locked = true;
          this.after(45, () => { st.doors.front.locked = false; });
        });
      });
    } else {
      // blackout, vanish, and something behind you
      st.lights.sales.set(false); audio.whisper(this.player.pos.clone().setY(1.6), 0.25, 2);
      c.remove();
      this.after(3.5, () => { st.lights.sales.set(true); this.scheduleBehind(); });
    }
  }

  // ---------------- Bottle throw ----------------
  throwBottle() {
    const mesh = this.player.heldMesh; if (!mesh) return;
    this.setItem(null);
    const b = mesh; this.scene.add(b);
    const p = this.camera.position.clone().add(this.player.lookDir().multiplyScalar(0.4));
    b.position.copy(p);
    const v = this.player.lookDir().multiplyScalar(11); v.y += 2.5;
    this.onFrame((dt) => {
      v.y -= 9.8 * dt; b.position.addScaledVector(v, dt); b.rotation.x += dt * 10;
      const blk = this.col?.segmentBlocked(b.position.x, b.position.z, b.position.x + v.x * dt * 2, b.position.z + v.z * dt * 2, b.position.y);
      if (b.position.y <= 0.05 || blk) {
        audio.glass(b.position.clone(), 0.6); this.emitNoise(b.position, 22);
        this.scene.remove(b);
        // creatures investigate
        for (const m of this.monsters.list) if (m.root.visible && m.state !== 'gone' && m.pos.distanceTo(b.position) < 25 && m.state !== 'chase') { m.lastKnown = b.position.clone(); m.lastSeenAt = this.time; if (m.kind === 'dog' || m.kind === 'shifter') m.setState(m.kind === 'dog' ? 'investigate' : 'search', 10); }
        return false;
      }
      return true;
    });
    this.toast('بطری پرتاب شد');
  }

  // ---------------- Traffic ----------------
  spawnCar() {
    const g = new THREE.Group();
    const dir = Math.random() < 0.5 ? 1 : -1; const z = dir > 0 ? 30.2 : 33.8;
    const body = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.8, 1.8), new THREE.MeshLambertMaterial({ color: [0x333333, 0x6a1a1a, 0x1a2a4a, 0x888888][Math.floor(Math.random() * 4)] }));
    body.position.y = 0.6; g.add(body);
    const cab = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.55, 1.6), new THREE.MeshLambertMaterial({ color: 0x08090c })); cab.position.set(-0.2 * dir, 1.25, 0); g.add(cab);
    const glow = new THREE.SpriteMaterial({ map: tex.glow(), color: 0xfff2d0, blending: THREE.AdditiveBlending, depthWrite: false });
    const red = new THREE.SpriteMaterial({ map: tex.glow(), color: 0xff2010, blending: THREE.AdditiveBlending, depthWrite: false });
    for (const s of [-0.6, 0.6]) {
      const h = new THREE.Sprite(glow); h.scale.set(1.3, 1.3, 1); h.position.set(2.15 * dir, 0.7, s); g.add(h);
      const t = new THREE.Sprite(red); t.scale.set(0.6, 0.6, 1); t.position.set(-2.15 * dir, 0.75, s); g.add(t);
    }
    const beam = new THREE.Mesh(new THREE.PlaneGeometry(12, 4), new THREE.MeshBasicMaterial({ map: tex.glow(), color: 0x806a50, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
    beam.rotation.x = -Math.PI / 2; beam.position.set(8 * dir, 0.03, 0); g.add(beam);
    g.position.set(-150 * dir, 0, z);
    this.scene.add(g);
    const snd = audio.engine(0.35, g.position);
    this.cars.push({ g, snd, dir, z });
  }

  // ---------------- Main loop ----------------
  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    let dt = (now - this.last) / 1000; this.last = now;
    if (dt > 0.05) dt = 0.05;
    this.fpsAcc += dt; this.fpsN++;
    if (this.fpsAcc > 1) { ui.set({ fps: Math.round(this.fpsN / this.fpsAcc) }); this.fpsAcc = 0; this.fpsN = 0; }
    const paused = ui.get().paused || ui.get().screen !== 'game';
    if (!paused && this.running) this.update(dt);
    if (this.level !== 'none') {
      const cam = this.cctvIndex >= 0 && this.station ? this.station.cams[this.cctvIndex].cam : this.camera;
      if (this.drive && !paused) this.drive.preRender(this.renderer, this.scene);
      this.renderer.render(this.scene, cam);
    }
  };

  private update(dt: number) {
    this.time += dt;
    // timers
    if (this.timers.length) {
      const due = this.timers.filter((t) => t.t <= this.time && t.gen === this.gen);
      this.timers = this.timers.filter((t) => t.t > this.time && t.gen === this.gen);
      due.forEach((t) => t.fn());
    }
    if (this.frameFns.length) this.frameFns = this.frameFns.filter((f) => f.gen === this.gen && f.fn(dt));

    // inputs
    if (consume('flash')) this.player.setFlash(!this.player.flashOn);
    const usePressed = consume('use');
    if (usePressed) {
      if (this.item === 'bottle') this.throwBottle();
      else this.player.setFlash(!this.player.flashOn);
    }

    if (this.level === 'drive') {
      const lk = { x: input.lookDX, y: input.lookDY }; input.lookDX = 0; input.lookDY = 0;
      const sens = 0.004 * settingsStore.get().sensitivity;
      this.driveLook.yaw = Math.max(-2.7, Math.min(2.7, this.driveLook.yaw - lk.x * sens));
      if (this.drive && this.drive.mode === 'passenger' && Math.abs(this.driveLook.yaw) > 2.2 && this.drive.passenger.root.visible) this.drive.onEvent('lookback');
      this.driveLook.pitch = Math.max(-0.6, Math.min(0.4, this.driveLook.pitch - lk.y * sens));
      this.camera.rotation.set(this.driveLook.pitch, this.driveLook.yaw, 0, 'YXZ');
      audio.updateListener(this.camera); audio.update();
      consume('interact');
      return;
    }

    this.player.speedMul = this.chaseOn ? 1.15 : 1;
    this.player.update(dt, this.col);
    audio.updateListener(this.camera);

    this.house?.update(dt);
    if (this.station) {
      this.station.update(dt, this.time);
      this.npcs.update(dt);
      this.monsters.update(dt);
      this.director.update(dt);
      this.updateStationAmbience(dt);
    }
    this.story.update(dt);
    this.updateInteract();
    this.noises = this.noises.filter((n) => n.t > this.time);

    // chase layer
    const chasing = this.station ? this.monsters.anyChasing() : false;
    if (chasing !== this.chaseOn) {
      this.chaseOn = chasing; audio.setChase(chasing); ui.set({ chase: chasing });
    }
    const md = this.station ? this.monsters.nearestDist() : Infinity;
    const fear = chasing ? 1 : md < 10 ? 0.6 : 0;
    audio.setHeart(chasing ? Math.max(0.4, 1 - md / 20) : fear * 0.5);
    audio.setBreath(this.player.running && this.player.stamina < 0.5 ? 0.8 : chasing ? 0.7 : this.player.stamina < 0.3 ? 0.5 : this.player.hide ? 0.3 : 0);
    if (chasing && this.station && Math.random() < dt * 0.6) this.flickerAt(this.player.pos, 0.4);
    audio.update();

    // rain
    if (this.rain) {
      const arr = (this.rain.geometry.attributes.position as THREE.BufferAttribute).array as Float32Array;
      const cp = this.camera.position;
      for (let i = 0; i < arr.length; i += 6) {
        arr[i + 1] -= 20 * dt; arr[i + 4] -= 20 * dt;
        if (arr[i + 1] < 0 || Math.abs(arr[i] - cp.x) > 18 || Math.abs(arr[i + 2] - cp.z) > 18) {
          const x = cp.x + (Math.random() - 0.5) * 36, z = cp.z + (Math.random() - 0.5) * 36; const y = 10 + Math.random() * 6;
          const inside = x > -14.3 && x < 14.3 && z > -12.3 && z < 4.3 || (x > -11 && x < 11 && z > 10.5 && z < 19.5 && y > 4.8);
          const yy = inside ? -50 : y;
          arr[i] = x; arr[i + 1] = yy; arr[i + 2] = z; arr[i + 3] = x + 0.05; arr[i + 4] = yy - 0.45; arr[i + 5] = z;
        }
      }
      this.rain.geometry.attributes.position.needsUpdate = true;
      this.lightningT -= dt;
      if (this.lightningT <= 0) {
        this.lightningT = 25 + Math.random() * 35;
        const base = this.hemi.intensity;
        this.hemi.intensity = 3; this.after(0.08, () => { this.hemi.intensity = base; this.after(0.12, () => { this.hemi.intensity = 2; this.after(0.06, () => { this.hemi.intensity = base; }); }); });
        this.after(1 + Math.random() * 2, () => audio.thunder());
      }
    }
    // traffic
    if (this.station) {
      this.trafficT -= dt;
      if (this.trafficT <= 0) { const ch = this.story.chapter; this.trafficT = ch <= 2 ? 20 + Math.random() * 30 : ch === 3 ? 40 + Math.random() * 40 : 80 + Math.random() * 80; if (this.cars.length < 2) this.spawnCar(); }
      for (const c of this.cars) { c.g.position.x += c.dir * 19 * dt; c.snd?.setPos?.(c.g.position); }
      this.cars = this.cars.filter((c) => { if (Math.abs(c.g.position.x) > 160) { this.scene.remove(c.g); c.snd?.stop(0.2); return false; } return true; });
    }

    // throttle UI
    this.uiAcc += dt;
    if (this.uiAcc > 0.15) {
      this.uiAcc = 0;
      ui.set({ stamina: Math.round(this.player.stamina * 50) / 50, flashlight: this.player.flashOn, clock: this.story.clockText() });
    }
  }

  private updateStationAmbience(_dt: number) {
    const st = this.station!;
    const p = st.lights.sales.level;
    this.ambience.fridge?.setLevel?.(p > 0.5 ? 0.06 : 0);
    this.ambience.buzz?.setLevel?.(p > 0.5 ? 0.014 : 0);
  }

  private updateInteract() {
    if (this.dying || ui.get().cutscene) { ui.set({ prompt: null }); consume('interact'); return; }
    const pressed = consume('interact');
    if (this.player.hide) {
      ui.set({ prompt: 'خروج از مخفیگاه' });
      if (pressed) this.exitHide();
      return;
    }
    if (this.player.frozen) { ui.set({ prompt: null }); return; }
    const cp = this.camera.position; const f = this.player.lookDir();
    let best: Interactable | null = null; let bestScore = -Infinity; let bestPrompt: string | null = null;
    for (const it of this.interactables) {
      const d = cp.distanceTo(it.pos);
      if (d > (it.range ?? 1.9)) continue;
      const dir = new THREE.Vector3().subVectors(it.pos, cp).normalize();
      const dot = dir.dot(f);
      if (dot < (d < 0.9 ? 0.2 : 0.72)) continue;
      const pr = it.prompt(); if (!pr) continue;
      // mission interactions win over generic door/hide prompts at the same spot
      const score = dot * 2 - d * 0.4 + (it.id.startsWith('door-') || it.id.startsWith('hide-') ? 0 : 0.6);
      if (score > bestScore) { bestScore = score; best = it; bestPrompt = pr; }
    }
    ui.set({ prompt: bestPrompt });
    if (pressed && best) best.action();
  }

  quitToMenu() {
    this.unload(); this.level = 'none'; this.running = false;
    ui.set({ screen: 'menu', paused: false, objective: null, cutscene: false, fade: 0, ending: null, title: false, chapterCard: null });
  }
  dispose() { cancelAnimationFrame(this.raf); window.removeEventListener('resize', this.resize); this.renderer.dispose(); }
}

let lastQ = settingsStore.get().quality;
function applyQualityIfChanged(g: Game) {
  const q = settingsStore.get().quality;
  if (q !== lastQ) { lastQ = q; g.applyQuality(); g.player.flash.castShadow = q === 'high'; }
}
