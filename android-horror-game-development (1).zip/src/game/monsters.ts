// Creature AI: shared navigation/door/vision/hearing logic + unique behaviours per creature
import * as THREE from 'three';
import { type Humanoid, type ShiftVariant } from './characters';
import { buildDog, buildTallMan, buildFaceless, buildWatcher, transformHuman } from './creatures';
import { audio } from './audio';
import type { Game } from './game';
import type { Door } from './world';

const v1 = new THREE.Vector3();

export type MState = 'hidden' | 'observe' | 'stalk' | 'approach' | 'retreat' | 'chase' | 'search' | 'investigate' | 'reveal' | 'ambush' | 'cutoff' | 'checkHide' | 'bang' | 'gone' | 'hunt';

export abstract class Monster {
  root!: THREE.Object3D;
  pos = new THREE.Vector3();
  yaw = 0;
  state: MState = 'hidden';
  t = 0; // state timer
  life = 0;
  path: THREE.Vector3[] = [];
  repath = 0;
  lastKnown: THREE.Vector3 | null = null;
  lastSeenAt = -99;
  dead = false;
  catchR = 1.1;
  stepAcc = 0;
  heavy = false;
  banging: Door | null = null;
  bangT = 0;
  searchLeft = 0;
  hideTarget: string | null = null;
  abstract kind: string;
  constructor(public g: Game) {}

  get chasing() { return this.state === 'chase' || this.state === 'bang' || this.state === 'checkHide'; }
  setState(s: MState, t = 0) { this.state = s; this.t = t; this.path = []; }

  place(p: THREE.Vector3, yaw = 0) { this.pos.copy(p); this.yaw = yaw; this.sync(); }
  sync() { this.root.position.copy(this.pos); this.root.rotation.y = this.yaw; }
  show(v: boolean) { this.root.visible = v; }

  /** different floor (basement vs. ground) => unreachable, never "near" */
  sameFloor() { return Math.abs(this.g.player.pos.y - this.pos.y) < 2; }
  distToPlayer() { const p = this.g.player.pos; if (!this.sameFloor()) return Infinity; return Math.hypot(p.x - this.pos.x, p.z - this.pos.z); }
  /** where to go when hunting the player: if the player is on another floor, roam instead */
  huntTarget(): THREE.Vector3 {
    const pl = this.g.player;
    if (this.sameFloor()) return pl.hide ? pl.hide.exit : pl.pos;
    if (!this.roam || this.pos.distanceTo(this.roam) < 1) {
      const nav = this.g.station!.nav; const n = nav.nodes[Math.floor(Math.random() * nav.nodes.length)];
      this.roam = new THREE.Vector3(n.x, 0, n.z);
    }
    return this.roam;
  }
  roam: THREE.Vector3 | null = null;
  eyePos() { return v1.set(this.pos.x, this.pos.y + 1.6, this.pos.z); }

  canSeePlayer(range = 18): boolean {
    const g = this.g; const pl = g.player;
    if (pl.hide && !pl.hide.open) return false;
    const d = this.distToPlayer();
    let r = range;
    if (pl.crouching) r *= 0.6;
    if (pl.flashOn) r *= 1.4;
    if (pl.hide?.open) r *= 0.35;
    if (d > r) return false;
    if (d > 2.5) {
      const dir = Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z);
      const rel = Math.abs(Math.atan2(Math.sin(dir - this.yaw), Math.cos(dir - this.yaw)));
      if (rel > 1.15 && this.state !== 'chase') return false;
    }
    return g.col!.los(this.eyePos().clone(), pl.camera.position, this.pos.y + 1.4);
  }

  hears(): THREE.Vector3 | null {
    const g = this.g;
    const pl = g.player;
    if (pl.noise > 0 && this.distToPlayer() < pl.noise) return pl.pos.clone();
    for (const n of g.noises) if (Math.abs(n.pos.y - this.pos.y) < 2 && n.pos.distanceTo(this.pos) < n.r) return n.pos.clone();
    return null;
  }

  turnTo(ty: number, k: number) { let d = ty - this.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); this.yaw += d * Math.min(1, k); }

  computePath(target: THREE.Vector3) {
    const st = this.g.station!; const nav = st.nav;
    const from = nav.nearest(this.pos.x, this.pos.z, st.col, this.pos.y);
    const to = nav.nearest(target.x, target.z, st.col, target.y);
    const ids = nav.path(from, to);
    this.path = [...ids.map((i) => new THREE.Vector3(nav.nodes[i].x, 0, nav.nodes[i].z)), new THREE.Vector3(target.x, 0, target.z)];
  }

  /** move along path / directly. Handles doors (open or bash). returns true if arrived */
  moveTo(target: THREE.Vector3, speed: number, dt: number, direct = false): boolean {
    const col = this.g.col!;
    if (direct) this.path = [new THREE.Vector3(target.x, 0, target.z)];
    else {
      this.repath -= dt;
      if (!this.path.length || this.repath <= 0) { this.computePath(target); this.repath = 1.2; }
    }
    if (!this.path.length) return true;
    const p = this.path[0];
    const dx = p.x - this.pos.x, dz = p.z - this.pos.z; const d = Math.hypot(dx, dz);
    if (d < 0.3) { this.path.shift(); return this.path.length === 0; }
    // doors in the way
    const blk = col.segmentBlocked(this.pos.x, this.pos.z, this.pos.x + (dx / d) * 0.9, this.pos.z + (dz / d) * 0.9, 1.2);
    if (blk && blk.door) {
      const door = Object.values(this.g.station!.doors).find((x) => x.box === blk);
      if (door) {
        if (!door.locked) door.setOpen(true);
        else { this.banging = door; return false; }
      }
    }
    const mv = Math.min(d, speed * dt);
    this.pos.x += (dx / d) * mv; this.pos.z += (dz / d) * mv;
    this.turnTo(Math.atan2(dx, dz), dt * 8);
    this.stepAcc += mv;
    if (this.stepAcc > (this.heavy ? 1.1 : 0.8)) { this.stepAcc = 0; audio.footstep('concrete', this.heavy ? 0.5 : 0.3, this.pos.clone().setY(0.2), this.heavy); }
    return false;
  }

  /** shared chase logic */
  doChase(dt: number, speed: number, loseAfter = 6) {
    const g = this.g; const pl = g.player;
    if (this.banging) { this.doBang(dt); return; }
    if (pl.hide) {
      if (g.hideSeenBy.has(this)) { this.state = 'checkHide'; this.t = 0; this.hideTarget = pl.hide.id; return; }
    }
    if (this.canSeePlayer(30)) {
      this.lastKnown = pl.pos.clone(); this.lastSeenAt = g.time;
      const direct = g.col!.segmentBlocked(this.pos.x, this.pos.z, pl.pos.x, pl.pos.z, 1.2, { inflate: 0.25 }) === null;
      this.moveTo(pl.pos, speed, dt, direct);
    } else if (this.lastKnown) {
      const arrived = this.moveTo(this.lastKnown, speed * 0.9, dt);
      if (arrived || g.time - this.lastSeenAt > loseAfter) { this.setState('search', 0); this.searchLeft = 3; }
    } else this.setState('search');
    if (this.distToPlayer() < this.catchR && !pl.hide) g.killPlayer(this);
  }

  doBang(dt: number) {
    const d = this.banging!;
    this.bangT -= dt;
    this.turnTo(Math.atan2(d.pos.x - this.pos.x, d.pos.z - this.pos.z), dt * 5);
    if (this.bangT <= 0) {
      this.bangT = 0.75 + Math.random() * 0.4;
      d.bangHits++;
      audio.knock(d.pos, 1, 0.9);
      this.g.player.shake = Math.max(this.g.player.shake, this.distToPlayer() < 6 ? 0.4 : 0);
      if (d.bangHits >= 6) { d.breakOpen(); this.banging = null; }
    }
    if (!d.locked) { d.setOpen(true); this.banging = null; }
  }

  doSearch(dt: number, speed: number) {
    const g = this.g;
    if (this.canSeePlayer()) { this.setState('chase'); return; }
    const h = this.hears(); if (h) { this.lastKnown = h; }
    if (!this.path.length || this.t <= 0) {
      if (this.searchLeft <= 0) { this.giveUp(); return; }
      this.searchLeft--;
      // look into a nearby hide spot sometimes
      const st = g.station!;
      const near = st.hide.filter((hs) => hs.exit.distanceTo(this.pos) < 6);
      if (near.length && Math.random() < 0.3) { const hs = near[Math.floor(Math.random() * near.length)]; this.hideTarget = hs.id; this.setState('checkHide'); return; }
      const base = this.lastKnown ?? this.pos;
      const nav = st.nav; const ni = nav.nearest(base.x + (Math.random() - 0.5) * 10, base.z + (Math.random() - 0.5) * 10);
      const n = nav.nodes[ni]; this.computePath(new THREE.Vector3(n.x, 0, n.z)); this.t = 6;
    }
    this.t -= dt;
    if (this.moveTo(this.path[this.path.length - 1] ?? this.pos, speed, dt)) this.t = 0;
  }

  doCheckHide(dt: number) {
    const g = this.g; const st = g.station!;
    const hs = st.hide.find((h) => h.id === this.hideTarget);
    if (!hs) { this.setState('search'); return; }
    if (this.t === 0) this.path = [];
    if (this.t < 100) {
      if (this.moveTo(hs.exit, 2.6, dt)) { this.t = 100; audio.knock(hs.pos, 2, 0.7, 0.25); }
      else { this.t += dt * 0.001; return; }
    }
    this.t += dt;
    this.turnTo(Math.atan2(hs.pos.x - this.pos.x, hs.pos.z - this.pos.z), dt * 4);
    if (this.t > 101.6) {
      const playerThere = g.player.hide?.id === hs.id && this.sameFloor();
      const seen = g.hideSeenBy.has(this);
      if (playerThere && Math.random() < (seen ? 0.6 : 0.3)) { g.killPlayer(this); return; }
      g.hideSeenBy.delete(this);
      audio.breath(hs.pos.clone(), 0.1, false, 1.2);
      this.setState('search'); this.searchLeft = 2;
    }
  }

  giveUp() { this.vanish(); }
  vanish() { this.setState('gone'); this.show(false); this.g.flickerAt(this.pos, 0.8); }

  abstract update(dt: number): void;
}

// ================= Bipedal Dog =================
export class DogMonster extends Monster {
  kind = 'dog';
  parts: Record<string, THREE.Object3D>;
  aggressive = false;
  burst = 0; pause = 0; lightHesitate = 0;
  stalkPoints = [new THREE.Vector3(0, 0, -26), new THREE.Vector3(-22, 0, -24), new THREE.Vector3(24, 0, -22), new THREE.Vector3(-30, 0, 2), new THREE.Vector3(30, 0, -6), new THREE.Vector3(-16, 0, -18)];
  growlT = 4;
  constructor(g: Game) {
    super(g);
    const d = buildDog(g.shadows); this.root = d.root; this.parts = d.parts;
    g.scene.add(this.root); this.root.traverse((c) => c.layers.set(0));
    this.catchR = 1.3; this.heavy = true;
  }
  observeAt(p: THREE.Vector3) { this.place(p); this.show(true); this.setState('observe', 14 + Math.random() * 10); }
  update(dt: number) {
    const g = this.g; const pl = g.player;
    let speed = 0;
    const d = this.distToPlayer();
    const faceP = () => this.turnTo(Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z), dt * 3);
    switch (this.state) {
      case 'hidden': case 'gone': break;
      case 'observe':
        faceP(); this.t -= dt;
        if (g.flashlightOn(this.pos.clone().setY(1.5)) || d < 12) { this.setState('retreat'); audio.growl(this.pos, 0.3); if (d < 12 && this.aggressive && Math.random() < 0.6) this.setState('chase'); }
        else if (this.t <= 0) this.aggressive ? this.setState('stalk', 20) : this.setState('retreat');
        break;
      case 'retreat': {
        speed = 6;
        const far = this.stalkPoints.reduce((a, b) => (b.distanceTo(pl.pos) > a.distanceTo(pl.pos) ? b : a));
        if (this.moveTo(far, speed, dt) || this.distToPlayer() > 30) { if (this.aggressive) this.setState('stalk', 15); else this.vanish(); }
        break;
      }
      case 'stalk': {
        speed = 2.2; this.t -= dt;
        const target = this.path.length ? this.path[this.path.length - 1] : this.stalkPoints[Math.floor(Math.random() * this.stalkPoints.length)];
        if (this.moveTo(target, speed, dt)) { this.path = []; if (Math.random() < 0.4) audio.bark(this.pos.clone().setY(1.5), 0.35); }
        if (this.canSeePlayer(15)) { audio.growl(this.pos.clone().setY(1.5), 0.5); this.setState('chase'); }
        const h = this.hears(); if (h) { this.lastKnown = h; this.setState('investigate', 10); }
        if (this.t <= 0 && Math.random() < 0.01) { this.place(this.stalkPoints[Math.floor(Math.random() * this.stalkPoints.length)]); this.setState('observe', 10); }
        break;
      }
      case 'investigate':
        speed = 3.5; this.t -= dt;
        if (this.lastKnown && this.moveTo(this.lastKnown, speed, dt)) { this.setState('search'); this.searchLeft = 2; }
        if (this.canSeePlayer(18)) this.setState('chase');
        if (this.t <= 0) this.setState('stalk', 10);
        break;
      case 'chase': {
        // unpredictable: bursts, sudden pauses, light hesitation
        this.burst -= dt; this.pause -= dt; this.lightHesitate -= dt;
        if (this.burst < -3 && Math.random() < dt * 0.8) this.burst = 0.9;
        if (this.pause < -4 && Math.random() < dt * 0.25 && d > 6) { this.pause = 0.7; audio.growl(this.pos.clone().setY(1.5), 0.45); }
        if (g.flashlightOn(this.pos.clone().setY(1.5)) && this.lightHesitate < -5) { this.lightHesitate = 0.6; }
        speed = this.pause > 0 || this.lightHesitate > 0 ? 0 : this.burst > 0 ? 6.4 : 4.7;
        if (speed > 0) this.doChase(dt, speed, 7);
        else faceP();
        this.growlT -= dt; if (this.growlT <= 0) { this.growlT = 3 + Math.random() * 3; audio.growl(this.pos.clone().setY(1.5), 0.4); }
        break;
      }
      case 'bang': this.doBang(dt); break;
      case 'search': speed = 2.5; this.doSearch(dt, speed); break;
      case 'checkHide': speed = 2.6; this.doCheckHide(dt); break;
      case 'cutoff': {
        speed = 5;
        const tgt = new THREE.Vector3(-14.5, 0, 5.5); // guards the way to the car, not the door itself
        if (this.moveTo(tgt, speed, dt)) { faceP(); if (this.canSeePlayer(14)) this.setState('chase'); }
        break;
      }
    }
    if (this.state === 'chase' && this.banging) this.doBang(dt);
    // animation (digitigrade gait)
    const ph = performance.now() * 0.001 * (speed > 0 ? 3 + speed * 1.6 : 0);
    const amp = speed > 0 ? Math.min(0.7, 0.2 + speed * 0.08) : 0;
    this.parts.lLeg.rotation.x = Math.sin(ph) * amp; this.parts.rLeg.rotation.x = -Math.sin(ph) * amp;
    this.parts.lArm.rotation.x = -Math.sin(ph) * amp * 0.8 - (this.state === 'chase' ? 0.6 : 0); this.parts.rArm.rotation.x = Math.sin(ph) * amp * 0.8 - (this.state === 'chase' ? 0.6 : 0);
    this.parts.body.rotation.x = this.state === 'chase' ? 0.35 : 0.05;
    this.parts.neck.rotation.z = this.state === 'observe' ? Math.sin(performance.now() * 0.0007) * 0.25 : 0;
    (this.parts.jaw as THREE.Mesh).rotation.x = this.state === 'chase' ? 0.35 + Math.sin(performance.now() * 0.02) * 0.1 : 0.12;
    this.sync();
  }
  giveUp() { this.aggressive ? this.setState('stalk', 20) : this.vanish(); }
}

// ================= Faceless =================
export class FacelessMonster extends Monster {
  kind = 'faceless';
  h: Humanoid;
  gaze = 0;
  hunting = false;
  warned = false;
  unseenT = 0;
  constructor(g: Game) {
    super(g);
    this.h = buildFaceless(g.shadows); this.root = this.h.root;
    g.scene.add(this.root); this.root.traverse((c) => c.layers.set(0));
    this.catchR = 1.0;
  }
  appear(p: THREE.Vector3, yaw: number, hunt = false) { this.place(p, yaw); this.show(true); this.hunting = hunt; this.setState(hunt ? 'hunt' : 'observe', 40); this.gaze = 0; }
  update(dt: number) {
    const g = this.g; const pl = g.player;
    const head = this.pos.clone().setY(1.6);
    const looked = g.isLooking(head, 0.93) && this.root.visible;
    const d = this.distToPlayer();
    const pYaw = Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z);
    const rel = Math.atan2(Math.sin(pYaw - this.yaw), Math.cos(pYaw - this.yaw));
    let speed = 0;
    if (this.state === 'gone' || this.state === 'hidden') return;
    if (looked) this.gaze += dt; else this.gaze = Math.max(0, this.gaze - dt * 0.3);
    // slow, unnatural head turn towards the watcher
    const ht = this.gaze > 1.2 || this.hunting ? Math.max(-2.6, Math.min(2.6, rel)) : 0;
    this.h.neck.rotation.y += (ht - this.h.neck.rotation.y) * Math.min(1, dt * 0.4);
    if (this.state === 'observe') {
      this.t -= dt;
      if (this.gaze > 4.5 && !this.warned) { this.warned = true; g.violation('stare'); audio.whisper(head, 0.2, 2); g.flicker('sales', 0.8); }
      if (this.warned && !looked) {
        this.unseenT += dt;
        if (this.unseenT > 2) {
          // reappear right behind the player
          const f = pl.forward();
          const bp = new THREE.Vector3(pl.pos.x - f.x * 1.8, 0, pl.pos.z - f.z * 1.8);
          if (!g.col!.segmentBlocked(pl.pos.x, pl.pos.z, bp.x, bp.z, 1, { inflate: 0.2 })) {
            this.place(bp, Math.atan2(f.x, f.z)); this.warned = false; this.gaze = 0; this.unseenT = 0; this.setState('approach', 6);
            audio.breath(head, 0.2, false, 1.4);
          }
        }
      }
      if (this.t <= 0 && !looked) this.vanish();
    } else if (this.state === 'approach') {
      this.t -= dt;
      if (looked && d < 3) { this.gaze += dt * 1.5; if (this.gaze > 2.5) { g.killPlayer(this); return; } }
      if (this.t <= 0 && !looked) this.vanish();
    } else if (this.state === 'hunt') {
      // weeping-angel style: moves only when not observed
      if (!looked) { this.unseenT += dt; speed = this.sameFloor() ? 3.2 : 1.4; this.moveTo(this.huntTarget(), speed, dt); }
      else { this.unseenT = 0; }
      if (d < this.catchR + 0.2 && !pl.hide) g.killPlayer(this);
      if (pl.hide && this.sameFloor() && this.pos.distanceTo(pl.hide.exit) < 1) { this.hideTarget = pl.hide.id; this.setState('checkHide'); }
    } else if (this.state === 'checkHide') { this.doCheckHide(dt); if ((this.state as MState) === 'search') { this.setState('hunt'); } }
    else if (this.state === 'chase') this.doChase(dt, 3.4, 8);
    else if (this.state === 'search') this.doSearch(dt, 2);
    this.h.animate(dt, speed, { stiff: true });
    this.sync();
  }
  giveUp() { this.hunting ? this.setState('hunt') : this.vanish(); }
}

// ================= Tall Man =================
export class TallMonster extends Monster {
  kind = 'tall';
  h: Humanoid;
  hunting = false;
  lookT = 0;
  ambushT = 10;
  constructor(g: Game) {
    super(g);
    this.h = buildTallMan(g.shadows); this.root = this.h.root;
    g.scene.add(this.root); this.root.traverse((c) => c.layers.set(0));
    this.catchR = 1.5; this.heavy = true;
  }
  appear(p: THREE.Vector3, hunt = false, life = 25) {
    const pl = this.g.player;
    this.place(p, Math.atan2(pl.pos.x - p.x, pl.pos.z - p.z)); this.show(true); this.hunting = hunt;
    this.setState(hunt ? 'hunt' : 'observe', life); this.lookT = 0;
  }
  update(dt: number) {
    const g = this.g; const pl = g.player;
    if (this.state === 'gone' || this.state === 'hidden') return;
    const head = this.pos.clone().setY(2.8);
    const looked = g.isLooking(head, 0.95) || g.isLooking(this.pos.clone().setY(1.5), 0.95);
    const d = this.distToPlayer();
    let speed = 0;
    if (this.state === 'observe') {
      this.turnTo(Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z), dt);
      this.t -= dt;
      if (looked) this.lookT += dt;
      if (this.lookT > 3 || d < 11 || g.flashlightOn(this.pos.clone().setY(1.8)) && this.lookT > 1 || this.t <= 0) {
        if (this.lookT > 0.5 && Math.random() < 0.6) audio.staticBurst(0.25, 0.08);
        this.vanish();
      }
    } else if (this.state === 'hunt') {
      speed = 1.5;
      this.moveTo(this.huntTarget(), speed, dt);
      if (this.sameFloor()) g.flickerAt(this.pos, 0.2);
      this.ambushT -= dt;
      // ambush: relocate ahead of the player when unseen
      if (!looked && this.ambushT <= 0 && d > 10 && this.sameFloor()) {
        this.ambushT = 18 + Math.random() * 10;
        const nav = g.station!.nav; const f = pl.forward();
        const ni = nav.nearest(pl.pos.x + f.x * 9, pl.pos.z + f.z * 9);
        const n = nav.nodes[ni];
        const np = new THREE.Vector3(n.x, 0, n.z);
        if (!g.isLooking(np.clone().setY(1.5), 0.6)) { this.place(np); audio.whisper(np.clone().setY(2), 0.15, 1.5); }
      }
      if (d < this.catchR && !pl.hide) g.killPlayer(this);
      if (pl.hide && this.sameFloor() && this.pos.distanceTo(pl.hide.exit) < 1.2) { this.hideTarget = pl.hide.id; this.setState('checkHide'); }
    } else if (this.state === 'checkHide') { this.doCheckHide(dt); if ((this.state as MState) === 'search') this.setState('hunt'); }
    this.h.animate(dt, speed, { stiff: true });
    this.sync();
  }
}

// ================= Watcher behind the glass =================
export class WatcherMonster extends Monster {
  kind = 'watcher';
  h: Humanoid;
  seen = false;
  awayT = 0;
  knockT = 3;
  constructor(g: Game) {
    super(g);
    this.h = buildWatcher(g.shadows); this.root = this.h.root;
    g.scene.add(this.root);
    this.root.traverse((c) => c.layers.set(1)); // NOT visible on CCTV
  }
  appear() {
    const xs = [-11, -7.5, -3, 3, 7.5, 11];
    const x = xs[Math.floor(Math.random() * xs.length)];
    this.place(new THREE.Vector3(x, 0, 4.45), Math.PI); this.show(true); this.setState('observe', 40); this.seen = false; this.awayT = 0;
  }
  update(dt: number) {
    const g = this.g; const pl = g.player;
    if (this.state !== 'observe') return;
    const head = this.pos.clone().setY(1.7);
    const looked = g.isLooking(head, 0.9);
    if (looked) { this.seen = true; this.awayT = 0; }
    else if (this.seen) { this.awayT += dt; if (this.awayT > 1.4) { this.setState('gone'); this.show(false); return; } }
    this.t -= dt;
    const dd = Math.hypot(pl.pos.x, pl.pos.z - 4);
    if (dd < 4.2 || this.t <= 0) { this.setState('gone'); this.show(false); return; }
    if (g.station!.doors.front.open) { g.violation('opened-door'); g.scheduleBehind(); this.setState('gone'); this.show(false); return; }
    this.knockT -= dt;
    if (this.knockT <= 0) { this.knockT = 5 + Math.random() * 6; audio.knock(head, 3, 0.35, 0.22); }
    this.h.neck.rotation.y = Math.max(-1, Math.min(1, Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z) - this.yaw));
    this.sync();
  }
}

// ================= Shapeshifter =================
export class ShifterMonster extends Monster {
  kind = 'shifter';
  h: Humanoid;
  variant: ShiftVariant;
  chaseTime = 0;
  litFreeze = 0;
  constructor(g: Game, h: Humanoid, pos: THREE.Vector3, yaw: number) {
    super(g);
    this.h = h; this.root = h.root;
    this.variant = (['stretch', 'maw', 'crawler'] as ShiftVariant[])[Math.floor(Math.random() * 3)];
    transformHuman(h, this.variant);
    this.place(pos, yaw);
    this.setState('reveal', 2.6);
    this.catchR = this.variant === 'crawler' ? 1.2 : 1.1;
    audio.scream(pos.clone().setY(1.6), 0.35);
  }
  update(dt: number) {
    const g = this.g; const pl = g.player;
    const speedBase = this.variant === 'crawler' ? 4.9 : this.variant === 'stretch' ? 4.1 : 3.7;
    let speed = 0;
    if (this.state === 'gone') return;
    if (this.state === 'reveal') {
      this.t -= dt;
      this.turnTo(Math.atan2(pl.pos.x - this.pos.x, pl.pos.z - this.pos.z), dt * 2);
      if (this.t <= 0) { this.setState('chase'); this.lastKnown = pl.pos.clone(); this.lastSeenAt = g.time; }
    } else if (this.state === 'chase') {
      this.chaseTime += dt;
      this.litFreeze -= dt;
      if (this.variant === 'stretch' && g.flashlightOn(this.pos.clone().setY(1.6)) && this.litFreeze < -6) { this.litFreeze = 1.0; audio.scream(this.pos.clone().setY(1.6), 0.2); }
      speed = this.litFreeze > 0 ? 0 : speedBase;
      if (speed > 0) this.doChase(dt, speed, 9);
      if (this.chaseTime > 80) this.vanish();
    } else if (this.state === 'search') { speed = 2.4; this.doSearch(dt, speed); }
    else if (this.state === 'checkHide') { speed = 2.5; this.doCheckHide(dt); }
    this.h.animate(dt, speed, { erratic: 0.9 });
    this.sync();
  }
  giveUp() { this.vanish(); }
}

export class MonsterManager {
  list: Monster[] = [];
  constructor(private g: Game) {}
  add<T extends Monster>(m: T) { this.list.push(m); return m; }
  get<T extends Monster>(kind: string): T | undefined { return this.list.find((m) => m.kind === kind) as T | undefined; }
  ensure<T extends Monster>(kind: string, make: () => T): T { return (this.get<T>(kind) ?? this.add(make())); }
  update(dt: number) { for (const m of this.list) if (!m.dead) m.update(dt); }
  anyChasing() { return this.list.some((m) => m.root.visible && m.chasing); }
  nearestDist() { let d = Infinity; for (const m of this.list) if (m.root.visible && m.state !== 'gone') d = Math.min(d, m.distToPlayer()); return d; }
  clear() { this.list.forEach((m) => this.g.scene.remove(m.root)); this.list = []; }
}
