// Realistic store props (instanced products, food machines, tools) + detailed car model
import * as THREE from 'three';
import { mat, tex } from './textures';
import { art } from './art';
import { boxGeo } from './world';
import { ProductSet, fillRow, type Kind } from './products';
import { docs } from './docs';

/** commercial drip coffee machine with a lit COFFEE header, facing +z before rotation */
export function coffeeMachine(ctx: PropsCtx, x: number, y: number, z: number, rotY: number) {
  const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = rotY; ctx.parent.add(g);
  const steel = mat({ color: 0xc4c8cc, metal: 0.85, rough: 0.25, key: 'cm-steel' });
  const black = mat({ color: 0x141414, metal: 0.3, rough: 0.35, key: 'cm-black' });
  const add = (geo: THREE.BufferGeometry, m: THREE.Material, px: number, py: number, pz: number) => { const o = new THREE.Mesh(geo, m); o.position.set(px, py, pz); g.add(o); return o; };
  add(new THREE.BoxGeometry(0.62, 0.05, 0.44), black, 0, 0.025, 0); // base
  add(new THREE.BoxGeometry(0.62, 0.8, 0.16), steel, 0, 0.42, -0.14); // back tower
  add(new THREE.BoxGeometry(0.62, 0.14, 0.44), black, 0, 0.75, 0); // brew head
  const panelM = new THREE.MeshStandardMaterial({ map: docs.coffeePanel(), emissive: 0xffffff, emissiveMap: docs.coffeePanel(), emissiveIntensity: 0.8, roughness: 0.3 });
  ctx.reg(panelM);
  const panel = add(new THREE.PlaneGeometry(0.6, 0.235), panelM, 0, 0.94, 0.0); panel.position.z = 0.03;
  add(new THREE.BoxGeometry(0.62, 0.26, 0.06), black, 0, 0.94, -0.01);
  const btn = add(new THREE.PlaneGeometry(0.22, 0.11), new THREE.MeshBasicMaterial({ map: docs.coffeeButtons() }), 0.17, 0.75, 0.222);
  void btn;
  // two warmers + glass carafes
  [-0.15, 0.13].forEach((cx, i) => {
    add(new THREE.CylinderGeometry(0.075, 0.075, 0.015, 16), mat({ color: 0x2a2a2a, metal: 0.6, rough: 0.4, key: 'cm-warm' }), cx, 0.06, 0.06);
    const glass = add(new THREE.CylinderGeometry(0.055, 0.07, 0.16, 16, 1, true), new THREE.MeshStandardMaterial({ color: 0xdfe8ee, transparent: true, opacity: 0.25, roughness: 0.02, side: THREE.DoubleSide, depthWrite: false }), cx, 0.15, 0.06);
    void glass;
    const coffee = add(new THREE.CylinderGeometry(0.06, 0.068, i ? 0.05 : 0.11, 16), mat({ color: 0x1a0a04, rough: 0.1, key: 'cm-coffee' }), cx, i ? 0.095 : 0.125, 0.06); void coffee;
    add(new THREE.CylinderGeometry(0.058, 0.058, 0.03, 16), mat({ color: i ? 0xd08a1a : 0x111111, rough: 0.4, key: 'cm-lid' + i }), cx, 0.245, 0.06);
    const h = add(new THREE.TorusGeometry(0.035, 0.008, 6, 12, Math.PI), black, cx + 0.07, 0.16, 0.06); h.rotation.set(0, Math.PI / 2, Math.PI / 2);
  });
  // cup stack, lids, sugar
  for (let i = 0; i < 7; i++) add(new THREE.CylinderGeometry(0.04, 0.032, 0.1, 12, 1, true), mat({ color: 0xf4efe6, rough: 0.6, key: 'cm-cup' }), 0.42, 0.05 + i * 0.022, 0.05);
  add(new THREE.BoxGeometry(0.12, 0.08, 0.1), mat({ color: 0x7a4a24, rough: 0.8, key: 'cm-sugar' }), 0.42, 0.04, -0.12);
  const light = add(new THREE.PlaneGeometry(0.02, 0.02), new THREE.MeshBasicMaterial({ color: 0xff3a1a }), -0.26, 0.75, 0.222); void light;
  return g;
}

/** chest freezer + raised popsicle/cone merchandiser so ice creams sit at eye level */
export function freezerChest(ctx: PropsCtx, x: number, z: number, rotY = 0) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rotY; ctx.parent.add(g);
  const white = mat({ color: 0xf0f0f0, rough: 0.35, key: 'frzw' });
  const box = new THREE.Mesh(boxGeo(1.5, 0.85, 0.75, 1), white); box.position.y = 0.425; g.add(box);
  const inside = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.65), new THREE.MeshStandardMaterial({ color: 0xdff0ff, emissive: 0xa0c8ff, emissiveIntensity: 0.5 }));
  inside.rotation.x = -Math.PI / 2; inside.position.y = 0.851; g.add(inside); ctx.reg(inside.material as THREE.Material);
  // heaped tubs (two layers, rising above the rim)
  const tubs = new Batch(new THREE.CylinderGeometry(0.06, 0.055, 0.08, 12), mat({ rough: 0.4, key: 'tub' }));
  const lids = new Batch(new THREE.CylinderGeometry(0.062, 0.062, 0.012, 12), mat({ rough: 0.3, key: 'tublid' }));
  const cols = [0xff6fa0, 0x6a3a20, 0xfff3c0, 0x7ad0ff, 0x9ae070, 0xffb03a];
  for (let i = 0; i < 10; i++) for (let j = 0; j < 4; j++) {
    const c = cols[(i * 3 + j) % cols.length];
    const hgt = j === 0 || j === 3 ? 0.9 : 0.99;
    tubs.add(-0.62 + i * 0.137, hgt, -0.24 + j * 0.16, 0, c); lids.add(-0.62 + i * 0.137, hgt + 0.046, -0.24 + j * 0.16, 0, 0xffffff);
    if (j === 1 || j === 2) { tubs.add(-0.62 + i * 0.137, hgt - 0.085, -0.24 + j * 0.16, 0, cols[(i + j) % cols.length]); }
  }
  tubs.build(g); lids.build(g);
  const lid = new THREE.Mesh(new THREE.PlaneGeometry(1.48, 0.73), new THREE.MeshStandardMaterial({ color: 0xc8e0f0, transparent: true, opacity: 0.18, roughness: 0.02, metalness: 0.4, depthWrite: false }));
  lid.rotation.x = -Math.PI / 2; lid.position.y = 1.06; g.add(lid);
  for (const sx of [-0.75, 0.75]) { const f = new THREE.Mesh(boxGeo(0.03, 0.2, 0.75, 1), white); f.position.set(sx, 0.95, 0); g.add(f); }
  // upright merchandiser on the back edge (eye level)
  const rackM = mat({ color: 0xe8eef2, metal: 0.3, rough: 0.4, key: 'icerack' });
  const board = new THREE.Mesh(boxGeo(1.46, 0.72, 0.05, 1), rackM); board.position.set(0, 1.42, -0.36); g.add(board);
  for (const sx of [-0.7, 0.7]) { const p = new THREE.Mesh(boxGeo(0.04, 0.95, 0.04, 1), rackM); p.position.set(sx, 1.3, -0.36); g.add(p); }
  const hdrM = new THREE.MeshStandardMaterial({ map: docs.iceHeader(), emissive: 0xffffff, emissiveMap: docs.iceHeader(), emissiveIntensity: 0.7 });
  ctx.reg(hdrM);
  const hdr = new THREE.Mesh(new THREE.PlaneGeometry(1.46, 0.36), hdrM); hdr.position.set(0, 1.97, -0.33); g.add(hdr);
  // popsicles in wrappers (2 rows) + cones (1 row) on hooks
  const pop = new Batch(new THREE.CapsuleGeometry(0.03, 0.12, 3, 8).scale(1, 1, 0.45), mat({ rough: 0.25, metal: 0.3, key: 'popwrap' }));
  const stick = new Batch(new THREE.BoxGeometry(0.012, 0.05, 0.004), mat({ color: 0xe0c08a, rough: 0.8, key: 'popstick' }));
  const cone = new Batch(new THREE.ConeGeometry(0.035, 0.13, 10).rotateX(Math.PI), mat({ color: 0xd8a060, rough: 0.8, key: 'icecone' }));
  const scoop = new Batch(new THREE.SphereGeometry(0.04, 10, 8), mat({ rough: 0.6, key: 'scoop' }));
  const wrap = [0xd4141e, 0x2a8cff, 0x5a2e14, 0x2fbf56, 0xff7a10, 0xe94b8a];
  for (let i = 0; i < 12; i++) for (let r = 0; r < 2; r++) {
    const px = -0.62 + i * 0.112, py = 1.66 - r * 0.2;
    pop.add(px, py, -0.31, 0, wrap[(i + r * 2) % wrap.length]); stick.add(px, py - 0.1, -0.31, 0, 0xffffff);
  }
  for (let i = 0; i < 10; i++) { const px = -0.6 + i * 0.133; cone.add(px, 1.2, -0.3, 0, 0xffffff); scoop.add(px, 1.29, -0.3, 0, [0xff8fb8, 0x5a2e14, 0xfff3c0, 0x9ae070][i % 4]); }
  [pop, stick, cone, scoop].forEach((b) => b.build(g));
  const shield = new THREE.Mesh(new THREE.PlaneGeometry(1.42, 0.68), new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.1, roughness: 0.02, depthWrite: false }));
  shield.position.set(0, 1.42, -0.26); g.add(shield);
  return g;
}

const m4 = new THREE.Matrix4(), qq = new THREE.Quaternion(), pv = new THREE.Vector3(), sv = new THREE.Vector3(), eu = new THREE.Euler();
const BRANDS = [0xd8262b, 0xf2b81a, 0x2f7de1, 0x2ca24a, 0x8e3fb8, 0xf06a1d, 0x1d1d1d, 0xe94b8a, 0x19a8a0, 0xffffff, 0x7a1020, 0x3a62a8];

/** collects instances, then builds a single InstancedMesh (1 draw call) */
export class Batch {
  list: { x: number; y: number; z: number; ry: number; rx: number; rz: number; c: number; s: number }[] = [];
  constructor(public geo: THREE.BufferGeometry, public material: THREE.Material) {}
  add(x: number, y: number, z: number, ry: number, c: number, s = 1, rx = 0, rz = 0) { this.list.push({ x, y, z, ry, rx, rz, c, s }); }
  build(parent: THREE.Object3D, shadows = false) {
    if (!this.list.length) return null;
    const im = new THREE.InstancedMesh(this.geo, this.material, this.list.length);
    const col = new THREE.Color();
    this.list.forEach((it, i) => {
      qq.setFromEuler(eu.set(it.rx, it.ry, it.rz)); m4.compose(pv.set(it.x, it.y, it.z), qq, sv.set(it.s, it.s, it.s));
      im.setMatrixAt(i, m4); im.setColorAt(i, col.setHex(it.c));
    });
    im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
    im.castShadow = shadows; im.receiveShadow = false; im.frustumCulled = false;
    parent.add(im);
    return im;
  }
}

function pillow(w: number, h: number, d: number) {
  const g = new THREE.BoxGeometry(w, h, d, 4, 4, 1);
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i) / (w / 2), y = p.getY(i) / (h / 2);
    p.setZ(i, p.getZ(i) * Math.max(0.15, (1 - x * x * 0.7) * (1 - Math.pow(Math.abs(y), 3) * 0.85)));
  }
  g.computeVertexNormals();
  return g;
}
function bottleGeo(h = 0.24, r = 0.034) {
  const pts = [[0, 0], [r * 0.9, 0], [r, 0.01], [r, h * 0.55], [r * 0.92, h * 0.62], [r * 0.95, h * 0.68], [r * 0.5, h * 0.85], [r * 0.32, h * 0.9], [r * 0.34, h], [0, h]].map(([x, y]) => new THREE.Vector2(x, y));
  return new THREE.LatheGeometry(pts, 10);
}

export interface PropsCtx { parent: THREE.Object3D; shadows: boolean; lowQ: boolean; reg: (m: THREE.Material) => void }

// products: see products.ts (designed packaging, instanced)
export { ProductSet, fillRow, setProductDetail, type Kind } from './products';
void BRANDS; void pillow; void bottleGeo;

/** double-sided gondola shelf along X, stocked on both faces */
export function gondola(ctx: PropsCtx, ps: ProductSet, x: number, z: number, len: number, rows: Kind[][]) {
  const P = ctx.parent;
  const metal = mat({ color: 0xd9d9d6, metal: 0.5, rough: 0.45, key: 'gond' });
  const dark = mat({ color: 0x2a2a2c, metal: 0.4, rough: 0.6, key: 'gondd' });
  const strip = mat({ map: art.priceStrip(), rough: 0.6, key: 'pstrip' });
  const add = (w: number, h: number, d: number, px: number, py: number, pz: number, m: THREE.Material) => { const me = new THREE.Mesh(boxGeo(w, h, d, 1), m); me.position.set(px, py, pz); P.add(me); return me; };
  add(len, 0.12, 0.92, x, 0.06, z, dark); // kick plate
  add(len, 1.65, 0.05, x, 0.9, z, metal); // spine
  add(len + 0.04, 0.06, 0.94, x, 1.75, z, dark); // top cap
  for (const ex of [-1, 1]) add(0.04, 1.75, 0.94, x + ex * len / 2, 0.875, z, metal);
  const levels = [0.14, 0.52, 0.9, 1.28];
  for (const side of [-1, 1]) {
    levels.forEach((y, i) => {
      add(len, 0.025, 0.42, x, y, z + side * 0.23, metal);
      const s = add(len, 0.05, 0.012, x, y - 0.012, z + side * 0.445, strip); s.rotation.y = side > 0 ? 0 : Math.PI;
      const kinds = rows[i % rows.length];
      const k = kinds[side > 0 ? 0 : kinds.length - 1];
      fillRow(ps, k, 'x', x - len / 2 + 0.03, x + len / 2 - 0.03, y + 0.013, z + side * 0.44, side, k === 'box' ? 2 : 3);
    });
  }
}

/** glass-door drink fridge bank facing +x on wall at x */
export function fridgeBank(ctx: PropsCtx, ps: ProductSet, x: number, z0: number, n: number, w = 1.45) {
  const P = ctx.parent;
  const frame = mat({ color: 0x18191b, metal: 0.6, rough: 0.4, key: 'fframe' });
  const inner = new THREE.MeshStandardMaterial({ color: 0xe8f0ff, emissive: 0xdde8ff, emissiveIntensity: 0.9, roughness: 0.6 });
  ctx.reg(inner);
  const glass = new THREE.MeshStandardMaterial({ color: 0xb8d0e0, transparent: true, opacity: 0.14, roughness: 0.02, metalness: 0.7, depthWrite: false });
  const shelfM = mat({ color: 0x9aa4ac, metal: 0.6, rough: 0.4, key: 'fshelf' });
  const handle = mat({ color: 0xc0c0c0, metal: 1, rough: 0.2, key: 'fhandle' });
  for (let i = 0; i < n; i++) {
    const zc = z0 + i * w + w / 2;
    const back = new THREE.Mesh(boxGeo(0.04, 2.0, w - 0.06, 1), inner); back.position.set(x - 0.33, 1.12, zc); P.add(back);
    // LED strips on the door frames
    for (const sz of [-1, 1]) { const led = new THREE.Mesh(boxGeo(0.02, 1.95, 0.02, 1), inner); led.position.set(x + 0.36, 1.15, zc + sz * (w / 2 - 0.06)); P.add(led); }
    const top = new THREE.Mesh(boxGeo(0.82, 0.2, w, 1), frame); top.position.set(x, 2.2, zc); P.add(top);
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.8, 0.14), new THREE.MeshBasicMaterial({ map: art.sign(['COLD DRINKS', 'نوشیدنی خنک', 'ENERGY', 'آب معدنی', 'DAIRY'][i % 5], '#0a0a0a', '#7fd4ff', 256, 40, 22) }));
    sign.position.set(x + 0.415, 2.2, zc); sign.rotation.y = Math.PI / 2; P.add(sign); ctx.reg(sign.material as THREE.Material);
    const bot = new THREE.Mesh(boxGeo(0.82, 0.12, w, 1), frame); bot.position.set(x, 0.06, zc); P.add(bot);
    const side = new THREE.Mesh(boxGeo(0.82, 2.3, 0.05, 1), frame); side.position.set(x, 1.15, zc - w / 2 + 0.025); P.add(side);
    for (let s = 0; s < 5; s++) {
      const y = 0.18 + s * 0.38;
      const sh = new THREE.Mesh(boxGeo(0.7, 0.02, w - 0.1, 1), shelfM); sh.position.set(x - 0.02, y, zc); P.add(sh);
      const kind: Kind = s === 4 ? 'can' : s === 0 ? 'jug' : 'bottle';
      const c0 = zc - w / 2 + 0.06, c1 = zc + w / 2 - 0.06;
      if (kind === 'jug') fillRow(ps, 'jug', 'z', c0, c1, y + 0.01, x + 0.32, 1, 2);
      else fillRow(ps, kind, 'z', c0, c1, y + 0.01, x + 0.32, 1, 3);
    }
    const gl = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.1, 2.0), glass); gl.position.set(x + 0.41, 1.15, zc); gl.rotation.y = Math.PI / 2; P.add(gl);
    const h = new THREE.Mesh(boxGeo(0.03, 0.9, 0.03, 1), handle); h.position.set(x + 0.45, 1.15, zc + w / 2 - 0.12); P.add(h);
  }
  const lastSide = new THREE.Mesh(boxGeo(0.82, 2.3, 0.05, 1), frame); lastSide.position.set(x, 1.15, z0 + n * w - 0.025); P.add(lastSide);
}

// ---------------- Food machines ----------------
export function donutCase(ctx: PropsCtx, x: number, y: number, z: number) {
  const g = new THREE.Group(); g.position.set(x, y, z); ctx.parent.add(g);
  const steel = mat({ color: 0xc8c8c8, metal: 0.8, rough: 0.3, key: 'steel' });
  const glass = new THREE.MeshStandardMaterial({ color: 0xd0e4f0, transparent: true, opacity: 0.18, roughness: 0.02, metalness: 0.5, depthWrite: false });
  const base = new THREE.Mesh(boxGeo(0.9, 0.06, 0.55, 1), steel); base.position.y = 0.03; g.add(base);
  const gl = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.5, 0.55), glass); gl.position.y = 0.31; g.add(gl);
  const roof = new THREE.Mesh(boxGeo(0.92, 0.03, 0.57, 1), steel); roof.position.y = 0.57; g.add(roof);
  const tray = new THREE.Mesh(boxGeo(0.84, 0.01, 0.5, 1), mat({ color: 0xf0e8d8, rough: 0.8, key: 'tray' })); tray.position.y = 0.3; g.add(tray);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.12), new THREE.MeshBasicMaterial({ map: art.sign('DONUTS • دونات', '#e94b8a', '#ffffff', 256, 52, 26) }));
  sign.position.set(0, 0.66, 0); g.add(sign); ctx.reg(sign.material as THREE.Material);
  const dough = new Batch(new THREE.TorusGeometry(0.042, 0.022, 8, 16).rotateX(Math.PI / 2), mat({ color: 0xd99a4e, rough: 0.8, key: 'dough' }));
  const icing = new Batch(new THREE.TorusGeometry(0.041, 0.021, 6, 16, Math.PI * 2).rotateX(Math.PI / 2).scale(1.02, 0.55, 1.02), mat({ rough: 0.25, key: 'icing' }));
  const spr = new Batch(new THREE.BoxGeometry(0.012, 0.004, 0.004), mat({ rough: 0.5, key: 'sprinkle' }));
  const icingCols = [0xf48fb1, 0x5a2e1a, 0xfaf3e0, 0xffd54f, 0x8e5cc4, 0x5a2e1a];
  const sprCols = [0xff4d4d, 0x4dd2ff, 0xffe14d, 0x7dff6a, 0xffffff];
  for (const ty of [0.065, 0.315]) for (let i = 0; i < 6; i++) for (let j = 0; j < 3; j++) {
    const dx = -0.33 + i * 0.13, dz = -0.15 + j * 0.15;
    dough.add(dx, ty + 0.022, dz, Math.random() * 6, 0xffffff);
    const ic = icingCols[(i + j * 2) % icingCols.length];
    if ((i + j) % 4 !== 3) {
      icing.add(dx, ty + 0.034, dz, Math.random() * 6, ic);
      if (ic !== 0xfaf3e0 || i % 2) for (let k = 0; k < 9; k++) { const a = Math.random() * Math.PI * 2, r = 0.03 + Math.random() * 0.025; spr.add(dx + Math.cos(a) * r, ty + 0.046, dz + Math.sin(a) * r, Math.random() * 6, sprCols[k % sprCols.length]); }
    }
  }
  const meshes = [dough.build(g), icing.build(g), spr.build(g)].filter(Boolean) as THREE.Object3D[];
  return { group: g, setFilled(v: boolean) { meshes.forEach((m) => (m.visible = v)); } };
}

export function hotdogRoller(ctx: PropsCtx, x: number, y: number, z: number) {
  const g = new THREE.Group(); g.position.set(x, y, z); ctx.parent.add(g);
  const steel = mat({ color: 0xbfc2c4, metal: 0.85, rough: 0.28, key: 'steel2' });
  const base = new THREE.Mesh(boxGeo(0.62, 0.14, 0.46, 1), steel); base.position.y = 0.07; g.add(base);
  const rollerM = mat({ color: 0xe8e8e8, metal: 1, rough: 0.15, key: 'roller' });
  const rollers: THREE.Mesh[] = [];
  for (let i = 0; i < 9; i++) { const r = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.5, 8).rotateZ(Math.PI / 2), rollerM); r.position.set(0, 0.155, -0.18 + i * 0.045); g.add(r); rollers.push(r); }
  const sausMat = new THREE.MeshStandardMaterial({ color: 0xd88a7a, map: art.grill(), roughness: 0.35, metalness: 0.05 });
  const sausages: THREE.Mesh[] = [];
  for (let i = 0; i < 7; i++) { const s = new THREE.Mesh(new THREE.CapsuleGeometry(0.019, 0.17, 4, 10).rotateZ(Math.PI / 2), sausMat); s.position.set((Math.random() - 0.5) * 0.04, 0.188, -0.157 + i * 0.045 + 0.0225); g.add(s); sausages.push(s); }
  const guard = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.3), new THREE.MeshStandardMaterial({ color: 0xd0e4f0, transparent: true, opacity: 0.15, roughness: 0.02, depthWrite: false, side: THREE.DoubleSide }));
  guard.position.set(0, 0.32, 0.24); guard.rotation.x = -0.35; g.add(guard);
  const lampM = new THREE.MeshStandardMaterial({ color: 0x331100, emissive: 0xff6a20, emissiveIntensity: 0 });
  const lamp = new THREE.Mesh(boxGeo(0.6, 0.04, 0.3, 1), lampM); lamp.position.set(0, 0.5, 0); g.add(lamp);
  for (const sx of [-0.29, 0.29]) { const p = new THREE.Mesh(boxGeo(0.02, 0.36, 0.02, 1), steel); p.position.set(sx, 0.32, -0.12); g.add(p); }
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.1), new THREE.MeshBasicMaterial({ map: art.sign('HOT DOG • هات‌داگ', '#c41e1e', '#ffe14d', 256, 52, 24) }));
  sign.position.set(0, 0.6, 0.02); g.add(sign); ctx.reg(sign.material as THREE.Material);
  // buns tray
  const bunM = mat({ color: 0xe0a85a, rough: 0.9, key: 'bun' });
  for (let i = 0; i < 4; i++) { const b = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.12, 3, 8).rotateZ(Math.PI / 2), bunM); b.scale.set(1, 0.7, 1.1); b.position.set(-0.42, 0.04 + Math.floor(i / 2) * 0.045, -0.06 + (i % 2) * 0.075); g.add(b); }
  const raw = new THREE.Color(0xd88a7a), cooked = new THREE.Color(0x8a3a1e);
  const api = {
    group: g, on: false, cook: 0, sausages,
    setOn(v: boolean) { api.on = v; lampM.emissiveIntensity = v ? 1.4 : 0; },
    setCount(n: number) { sausages.forEach((s, i) => (s.visible = i < n)); },
    update(dt: number) {
      if (!api.on) return;
      api.cook = Math.min(1, api.cook + dt / 25);
      sausMat.color.copy(raw).lerp(cooked, api.cook);
      rollers.forEach((r) => (r.rotation.x += dt * 3));
      sausages.forEach((s) => (s.rotation.x -= dt * 2.4));
    },
  };
  return api;
}

export function makeHotdog() {
  const g = new THREE.Group();
  const bun = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.12, 3, 8).rotateZ(Math.PI / 2), mat({ color: 0xe0a85a, rough: 0.9, key: 'bun' }));
  bun.scale.set(1, 0.65, 1.25); g.add(bun);
  const s = new THREE.Mesh(new THREE.CapsuleGeometry(0.018, 0.16, 4, 8).rotateZ(Math.PI / 2), mat({ color: 0x8a3a1e, rough: 0.35, key: 'cookedsaus' }));
  s.position.y = 0.02; g.add(s);
  const mus = new THREE.Mesh(new THREE.CapsuleGeometry(0.005, 0.14, 2, 6).rotateZ(Math.PI / 2), mat({ color: 0xf5c800, rough: 0.4, key: 'mustard' }));
  mus.position.y = 0.04; mus.rotation.y = 0.15; g.add(mus);
  g.scale.setScalar(1.6);
  return g;
}

export function slushie(ctx: PropsCtx, x: number, y: number, z: number, rotY = 0) {
  const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = rotY; ctx.parent.add(g);
  const body = mat({ color: 0x1d1d22, metal: 0.4, rough: 0.4, key: 'slbody' });
  const b = new THREE.Mesh(boxGeo(0.62, 0.3, 0.45, 1), body); b.position.y = 0.15; g.add(b);
  const augers: THREE.Mesh[] = [];
  [[-0.15, 0x2a8cff], [0.15, 0xff2a4a]].forEach(([sx, col]) => {
    const liq = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.38, 14), new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.25, roughness: 0.2, transparent: true, opacity: 0.85 }));
    liq.position.set(sx, 0.5, 0); g.add(liq); ctx.reg(liq.material as THREE.Material);
    const shell = new THREE.Mesh(new THREE.CylinderGeometry(0.135, 0.135, 0.44, 14, 1, true), new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.15, roughness: 0.02, depthWrite: false }));
    shell.position.set(sx, 0.52, 0); g.add(shell);
    const au = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.3, 0.02), new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.5 })); au.position.set(sx, 0.5, 0); g.add(au); augers.push(au);
  });
  const top = new THREE.Mesh(boxGeo(0.62, 0.14, 0.45, 1), body); top.position.y = 0.81; g.add(top);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(0.58, 0.11), new THREE.MeshBasicMaterial({ map: art.sign('SLUSH • یخ‌در‌بهشت', '#101030', '#7fe3ff', 256, 48, 22) }));
  sign.position.set(0, 0.81, 0.226); g.add(sign); ctx.reg(sign.material as THREE.Material);
  // cups stack
  for (let i = 0; i < 6; i++) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.035, 0.12, 10, 1, true), mat({ color: 0xffffff, rough: 0.6, key: 'cup' })); c.position.set(0.4, 0.06 + i * 0.03, 0); g.add(c); }
  return { group: g, update: (dt: number) => augers.forEach((a) => (a.rotation.y += dt * 2.5)) };
}

export function freezerChestOld(ctx: PropsCtx, x: number, z: number, rotY = 0) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rotY; ctx.parent.add(g);
  const white = mat({ color: 0xf0f0f0, rough: 0.35, key: 'frzw' });
  const box = new THREE.Mesh(boxGeo(1.5, 0.85, 0.75, 1), white); box.position.y = 0.425; g.add(box);
  const inside = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.65), new THREE.MeshStandardMaterial({ color: 0xdff0ff, emissive: 0xa0c8ff, emissiveIntensity: 0.4 }));
  inside.rotation.x = -Math.PI / 2; inside.position.y = 0.851; g.add(inside); ctx.reg(inside.material as THREE.Material);
  const tubs = new Batch(new THREE.CylinderGeometry(0.06, 0.055, 0.08, 10), mat({ rough: 0.4, key: 'tub' }));
  const cols = [0xff6fa0, 0x6a3a20, 0xfff3c0, 0x7ad0ff, 0x9ae070];
  for (let i = 0; i < 10; i++) for (let j = 0; j < 4; j++) tubs.add(-0.62 + i * 0.137, 0.87, -0.24 + j * 0.16, 0, cols[(i * 3 + j) % cols.length]);
  tubs.build(g);
  const lid = new THREE.Mesh(new THREE.PlaneGeometry(1.48, 0.73), new THREE.MeshStandardMaterial({ color: 0xc8e0f0, transparent: true, opacity: 0.2, roughness: 0.02, metalness: 0.4, depthWrite: false }));
  lid.rotation.x = -Math.PI / 2; lid.position.y = 0.95; g.add(lid);
  const label = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.2), new THREE.MeshBasicMaterial({ map: art.sign('ICE CREAM • بستنی', '#2a8cff', '#ffffff', 256, 56, 26) }));
  label.position.set(0, 0.5, 0.376); g.add(label);
  return g;
}

export function atm(ctx: PropsCtx, x: number, z: number, rotY: number) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rotY; ctx.parent.add(g);
  const body = mat({ color: 0x2b3a4a, metal: 0.6, rough: 0.4, key: 'atmb' });
  const b = new THREE.Mesh(boxGeo(0.7, 1.6, 0.6, 1), body); b.position.y = 0.8; g.add(b);
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.24), new THREE.MeshBasicMaterial({ map: art.sign('خوش آمدید', '#0a3a8a', '#ffffff', 128, 96, 22) }));
  scr.position.set(0, 1.25, 0.301); scr.rotation.x = -0.2; g.add(scr); ctx.reg(scr.material as THREE.Material);
  const pad = new THREE.Mesh(boxGeo(0.3, 0.04, 0.2, 1), mat({ color: 0x777777, metal: 0.8, key: 'atmpad' })); pad.position.set(0, 0.98, 0.33); g.add(pad);
  const top = new THREE.Mesh(new THREE.PlaneGeometry(0.66, 0.2), new THREE.MeshBasicMaterial({ map: art.sign('ATM', '#c41e1e', '#ffffff', 128, 40, 30) }));
  top.position.set(0, 1.5, 0.301); g.add(top); ctx.reg(top.material as THREE.Material);
  return g;
}

/** pegboard tool wall facing -x on wall at x; returns the wrench object */
export function toolWall(ctx: PropsCtx, ps: ProductSet, x: number, z0: number, z1: number) {
  const P = ctx.parent; const len = z1 - z0; const zc = (z0 + z1) / 2;
  const board = new THREE.Mesh(new THREE.PlaneGeometry(len, 1.2), mat({ map: art.pegboard(), rough: 0.9, key: 'peg' }));
  board.position.set(x - 0.01, 1.55, zc); board.rotation.y = -Math.PI / 2; P.add(board);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(len * 0.7, 0.22), new THREE.MeshBasicMaterial({ map: art.sign('ابزار و لوازم خودرو', '#e0b000', '#111', 512, 64, 36) }));
  sign.position.set(x - 0.02, 2.3, zc); sign.rotation.y = -Math.PI / 2; P.add(sign);
  const shelfM = mat({ color: 0x3a3a3c, metal: 0.5, rough: 0.5, key: 'tshelf' });
  for (const y of [0.15, 0.55]) { const s = new THREE.Mesh(boxGeo(0.45, 0.03, len, 1), shelfM); s.position.set(x - 0.23, y, zc); P.add(s); }
  const cab = new THREE.Mesh(boxGeo(0.45, 0.9, len, 1), mat({ color: 0x2a2a2c, rough: 0.6, key: 'tcab' })); cab.position.set(x - 0.23, 0.08, zc); cab.scale.y = 0.15; P.add(cab);
  fillRow(ps, 'oil', 'z', z0 + 0.05, z1 - 0.05, 0.165, x - 0.4, -1, 2);
  fillRow(ps, 'jug', 'z', z0 + 0.05, z0 + len * 0.5, 0.565, x - 0.4, -1, 2);
  fillRow(ps, 'can', 'z', z0 + len * 0.5, z1 - 0.05, 0.565, x - 0.4, -1, 2);
  const metal = mat({ color: 0xb8bcc0, metal: 1, rough: 0.25, key: 'toolmetal' });
  const reds = [0xc41e1e, 0x1e5ac4, 0xf2b81a, 0x2ca24a];
  const tool = (kind: number, zz: number, yy: number) => {
    const g = new THREE.Group(); g.position.set(x - 0.05, yy, zz); g.rotation.y = -Math.PI / 2; P.add(g);
    const hm = mat({ color: reds[kind % 4], rough: 0.5, key: 'th' + kind });
    if (kind === 0) { // hammer
      const h = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.018, 0.3, 8), mat({ color: 0x8a5a2a, rough: 0.7, key: 'woodh' })); g.add(h);
      const hd = new THREE.Mesh(boxGeo(0.12, 0.035, 0.035, 1), metal); hd.position.y = 0.15; g.add(hd);
    } else if (kind === 1) { // screwdriver
      const h = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.1, 8), hm); h.position.y = 0.06; g.add(h);
      const s = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.14, 6), metal); s.position.y = -0.06; g.add(s);
    } else if (kind === 2) { // tape
      const t = new THREE.Mesh(new THREE.TorusGeometry(0.045, 0.02, 8, 16), mat({ color: 0x9a9a9a, metal: 0.6, rough: 0.4, key: 'tape' })); g.add(t);
    } else if (kind === 3) { // pliers
      for (const s of [-1, 1]) { const a = new THREE.Mesh(boxGeo(0.012, 0.18, 0.01, 1), metal); a.rotation.z = s * 0.15; g.add(a); const hh = new THREE.Mesh(boxGeo(0.018, 0.1, 0.014, 1), hm); hh.position.set(s * 0.018, -0.08, 0); hh.rotation.z = s * 0.15; g.add(hh); }
    } else { // flashlight
      const f = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.18, 10), mat({ color: 0xf2b81a, rough: 0.4, key: 'flashy' })); g.add(f);
      const hd = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.022, 0.04, 10), mat({ color: 0x222222, rough: 0.4, key: 'flashh' })); hd.position.y = 0.1; g.add(hd);
    }
  };
  let k = 0;
  for (let zz = z0 + 0.2; zz < z1 - 0.15; zz += 0.24) { tool(k % 5, zz, 1.25); tool((k + 2) % 5, zz + 0.1, 1.75); k++; }
  // the big wrench (pickable)
  const wrench = new THREE.Group(); wrench.position.set(x - 0.05, 1.5, z0 + 0.35); wrench.rotation.y = -Math.PI / 2; P.add(wrench);
  const wh = new THREE.Mesh(boxGeo(0.03, 0.32, 0.012, 1), metal); wrench.add(wh);
  const jaw = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.012, 6, 12, Math.PI * 1.4), metal); jaw.position.y = 0.18; jaw.rotation.z = -Math.PI * 0.2; wrench.add(jaw);
  const grip = new THREE.Mesh(boxGeo(0.036, 0.12, 0.018, 1), mat({ color: 0xc41e1e, rough: 0.5, key: 'wgrip' })); grip.position.y = -0.1; wrench.add(grip);
  return { wrench };
}

export function wetFloorSign(parent: THREE.Object3D, x: number, z: number) {
  const g = new THREE.Group(); g.position.set(x, 0, z); parent.add(g);
  const m = new THREE.MeshStandardMaterial({ map: art.wetFloor(), roughness: 0.5, side: THREE.DoubleSide });
  for (const s of [-1, 1]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 0.6), m); p.position.set(0, 0.29, s * 0.09); p.rotation.x = s * 0.3; p.rotation.y = s > 0 ? 0 : Math.PI; g.add(p); }
  return g;
}

export function posterMesh(parent: THREE.Object3D, map: THREE.Texture, x: number, y: number, z: number, rotY: number, w = 0.45, tilt = 0) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, w * 1.406), new THREE.MeshStandardMaterial({ map, roughness: 0.85, transparent: false }));
  m.position.set(x, y, z); m.rotation.set(0, rotY, tilt); parent.add(m);
  return m;
}

// ---------------- Detailed car ----------------
export interface CarModel { fuelCap: THREE.Object3D; group: THREE.Group; wheels: THREE.Object3D[]; headMat: THREE.MeshStandardMaterial; tailMat: THREE.MeshStandardMaterial; driverSeat: THREE.Vector3; flyer?: THREE.Mesh; setLights: (on: boolean) => void }

/** sedan facing +z, origin at ground center */
export function buildCar(color: number, shadows = false, opts: { plate?: boolean; dirt?: boolean; flyer?: boolean } = {}): CarModel {
  const group = new THREE.Group();
  const inner = new THREE.Group(); inner.rotation.y = -Math.PI / 2; group.add(inner); // build along +x
  const paint = new THREE.MeshStandardMaterial({ color, metalness: 0.75, roughness: 0.32, envMapIntensity: 1.2 });
  const s = new THREE.Shape();
  s.moveTo(-2.22, 0.32); s.lineTo(-1.78, 0.32); s.absarc(-1.35, 0.32, 0.43, Math.PI, 0, true); s.lineTo(0.92, 0.32); s.absarc(1.35, 0.32, 0.43, Math.PI, 0, true);
  s.lineTo(2.2, 0.32); s.quadraticCurveTo(2.32, 0.42, 2.28, 0.62); s.quadraticCurveTo(2.24, 0.8, 2.05, 0.84); s.lineTo(1.05, 0.96);
  s.lineTo(1.0, 0.98); s.quadraticCurveTo(0.6, 1.36, 0.35, 1.4); s.lineTo(-0.75, 1.4); s.quadraticCurveTo(-1.05, 1.36, -1.35, 0.98); s.lineTo(-2.15, 0.93); s.quadraticCurveTo(-2.32, 0.85, -2.3, 0.55); s.closePath();
  const geo = new THREE.ExtrudeGeometry(s, { depth: 1.62, bevelEnabled: true, bevelThickness: 0.07, bevelSize: 0.07, bevelSegments: 3, curveSegments: 10 });
  geo.translate(0, 0, -0.81);
  const body = new THREE.Mesh(geo, paint); body.castShadow = shadows; inner.add(body);
  const glassM = new THREE.MeshStandardMaterial({ color: 0x0a0e14, metalness: 0.9, roughness: 0.05, transparent: true, opacity: 0.82, side: THREE.DoubleSide });
  // side windows
  const ws = new THREE.Shape(); ws.moveTo(-1.22, 1.0); ws.lineTo(0.92, 1.0); ws.quadraticCurveTo(0.58, 1.3, 0.33, 1.33); ws.lineTo(-0.74, 1.33); ws.quadraticCurveTo(-1.0, 1.3, -1.22, 1.0);
  const wgeo = new THREE.ShapeGeometry(ws);
  for (const sz of [-1, 1]) { const w = new THREE.Mesh(wgeo, glassM); w.position.z = sz * 0.895; inner.add(w); }
  const pillarM = mat({ color: 0x0a0a0a, rough: 0.5, key: 'pillar-car' });
  for (const sz of [-1, 1]) { const b = new THREE.Mesh(boxGeo(0.07, 0.34, 0.02, 1), pillarM); b.position.set(-0.15, 1.16, sz * 0.9); inner.add(b); }
  // windshield & rear glass
  const wsGeo = new THREE.PlaneGeometry(1.5, 0.76);
  const front = new THREE.Mesh(wsGeo, glassM); front.position.set(0.675, 1.19, 0); front.rotation.set(0, Math.PI / 2, 0); front.rotateX(-1.0); front.translateZ(0.075); inner.add(front);
  const rear = new THREE.Mesh(wsGeo, glassM); rear.position.set(-1.05, 1.19, 0); rear.rotation.set(0, -Math.PI / 2, 0); rear.rotateX(-0.96); rear.translateZ(0.075); inner.add(rear);
  // wheels
  const tireM = mat({ color: 0x111111, rough: 0.9, key: 'tire' });
  const rimM = mat({ color: 0xb8bcc0, metal: 0.95, rough: 0.25, key: 'rim' });
  const wheels: THREE.Object3D[] = [];
  const tireG = new THREE.CylinderGeometry(0.33, 0.33, 0.24, 20).rotateX(Math.PI / 2);
  const rimG = new THREE.CylinderGeometry(0.2, 0.2, 0.25, 14).rotateX(Math.PI / 2);
  const spokeG = new THREE.BoxGeometry(0.36, 0.04, 0.02);
  for (const wx of [-1.35, 1.35]) for (const wz of [-0.8, 0.8]) {
    const w = new THREE.Group(); w.position.set(wx, 0.33, wz); inner.add(w);
    w.add(new THREE.Mesh(tireG, tireM)); w.add(new THREE.Mesh(rimG, rimM));
    for (let k = 0; k < 5; k++) { const sp = new THREE.Mesh(spokeG, rimM); sp.rotation.z = (k / 5) * Math.PI; sp.position.z = wz > 0 ? 0.13 : -0.13; w.add(sp); }
    wheels.push(w);
  }
  // lights
  const headMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2d8, emissiveIntensity: 0.05, roughness: 0.1, metalness: 0.3 });
  const tailMat = new THREE.MeshStandardMaterial({ color: 0x550000, emissive: 0xff1a0a, emissiveIntensity: 0.1, roughness: 0.2 });
  for (const sz of [-0.58, 0.58]) {
    const h = new THREE.Mesh(boxGeo(0.08, 0.12, 0.36, 1), headMat); h.position.set(2.27, 0.68, sz); h.rotation.z = -0.35; inner.add(h);
    const t = new THREE.Mesh(boxGeo(0.06, 0.1, 0.4, 1), tailMat); t.position.set(-2.33, 0.78, sz); inner.add(t);
  }
  const darkM = mat({ color: 0x151515, rough: 0.55, key: 'cardark' });
  const grille = new THREE.Mesh(boxGeo(0.05, 0.14, 0.7, 1), darkM); grille.position.set(2.31, 0.52, 0); inner.add(grille);
  for (const bx of [2.33, -2.36]) { const b = new THREE.Mesh(boxGeo(0.1, 0.16, 1.72, 1), darkM); b.position.set(bx, 0.36, 0); inner.add(b); }
  for (const sz of [-1, 1]) { const mr = new THREE.Mesh(boxGeo(0.12, 0.1, 0.14, 1), paint); mr.position.set(0.85, 1.04, sz * 0.97); inner.add(mr); }
  for (const sz of [-1, 1]) for (const hx of [0.3, -0.75]) { const dh = new THREE.Mesh(boxGeo(0.14, 0.025, 0.02, 1), rimM); dh.position.set(hx, 0.86, sz * 0.885); inner.add(dh); }
  for (const sz of [-1, 1]) { const line = new THREE.Mesh(boxGeo(0.01, 0.55, 0.005, 1), darkM); line.position.set(-0.2, 0.68, sz * 0.886); inner.add(line); }
  if (opts.plate !== false) {
    const plateM = new THREE.MeshStandardMaterial({ map: art.plate(), roughness: 0.4 });
    const pl = new THREE.Mesh(new THREE.PlaneGeometry(0.52, 0.115), plateM); pl.position.set(2.39, 0.42, 0); pl.rotation.y = Math.PI / 2; inner.add(pl);
    const pr = pl.clone(); pr.position.x = -2.42; pr.rotation.y = -Math.PI / 2; inner.add(pr);
  }
  // interior hint (seats, wheel)
  const seatM = mat({ color: 0x2a2420, rough: 0.9, key: 'seat' });
  for (const sz of [-0.38, 0.38]) { const st = new THREE.Mesh(boxGeo(0.5, 0.6, 0.48, 1), seatM); st.position.set(-0.15, 0.85, sz); inner.add(st); }
  const rs = new THREE.Mesh(boxGeo(0.5, 0.55, 1.4, 1), seatM); rs.position.set(-1.0, 0.82, 0); inner.add(rs);
  const sw = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.02, 6, 16), darkM); sw.position.set(0.45, 1.05, 0.38); sw.rotation.y = Math.PI / 2; sw.rotateX(0.5); inner.add(sw);
  // wipers
  for (const sz of [-0.35, 0.3]) { const wp = new THREE.Mesh(boxGeo(0.02, 0.015, 0.6, 1), darkM); wp.position.set(1.02, 0.99, sz); wp.rotation.y = 0.3; inner.add(wp); }
  if (opts.dirt) {
    const dirt = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 0.35), new THREE.MeshBasicMaterial({ color: 0x2a2015, transparent: true, opacity: 0.45, depthWrite: false }));
    for (const sz of [-1, 1]) { const d = dirt.clone(); d.position.set(0, 0.45, sz * 0.9); if (sz < 0) d.rotation.y = Math.PI; inner.add(d); }
  }
  // fuel filler door (rear, right side in car space)
  const fuelDoor = new THREE.Mesh(new THREE.CircleGeometry(0.075, 14), mat({ color: 0x0c0c0c, rough: 0.6, key: 'fueldoor' }));
  fuelDoor.position.set(-1.55, 0.84, -0.892); fuelDoor.rotation.y = Math.PI; inner.add(fuelDoor);
  const fuelCap = new THREE.Object3D(); fuelCap.position.set(-1.55, 0.84, -0.95); inner.add(fuelCap);
  let flyer: THREE.Mesh | undefined;
  if (opts.flyer) {
    flyer = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.42), new THREE.MeshStandardMaterial({ map: art.poster('flyer', 0, true), roughness: 0.9, side: THREE.DoubleSide }));
    flyer.position.set(0.82, 1.096, 0.28); flyer.rotation.set(0, Math.PI / 2, 0); flyer.rotateX(-1.0); flyer.translateZ(0.09); inner.add(flyer);
    flyer.visible = false;
  }
  return {
    group, wheels, headMat, tailMat, flyer, fuelCap, driverSeat: new THREE.Vector3(0.38, 1.25, 0.15),
    setLights(on: boolean) { headMat.emissiveIntensity = on ? 3 : 0.05; tailMat.emissiveIntensity = on ? 2 : 0.1; },
  };
}

export { tex };
