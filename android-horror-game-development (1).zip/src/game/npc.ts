// Customer NPCs: navigation, browsing, queueing, quirks and agitation for anomalous visitors
import * as THREE from 'three';
import { Humanoid, ARCHETYPES, STRANGE_LINES, type Archetype } from './characters';
import { buildFaceless } from './creatures';
import { audio } from './audio';
import type { Game } from './game';

export type Quirk = 'stare' | 'freeze' | 'turn' | 'leave' | 'reflection' | 'quick' | 'line';
export type Role = 'customer' | 'faceless' | 'shifter' | 'waiting';

export interface SpawnOpts { arch?: string; quirk?: Quirk | null; anomalous?: boolean; role?: Role; at?: THREE.Vector3; yaw?: number }

const BROWSE: [number, number, number][] = [
  [-8.5, -1.25, Math.PI], [-5, -1.25, Math.PI], [-4, 0.1, 0], [-8, 0.1, 0], [-11.6, -2, -Math.PI / 2], [-11.6, 0.5, -Math.PI / 2],
  [-6, 2.0, Math.PI], [12.4, 2.3, Math.PI / 2], [1.3, 2.1, Math.PI],
];

const tmp = new THREE.Vector3();

export class Customer {
  h: Humanoid;
  arch: Archetype;
  pos: THREE.Vector3;
  yaw = 0;
  state = 'arrive';
  path: THREE.Vector3[] = [];
  timer = 0;
  stops = 1;
  quirk: Quirk | null;
  anomalous: boolean;
  role: Role;
  agitation = 0;
  closeT = 0;
  served = false;
  removed = false;
  quirkDone = false;
  reflection: Humanoid | null = null;
  holding: THREE.Mesh | null = null;
  speed: number;
  faceYaw: number | null = null;
  talking = false;
  patience = 70;
  inStoreT = 0;
  onServed?: () => void;
  headLock = 0;

  constructor(public g: Game, o: SpawnOpts) {
    this.arch = ARCHETYPES.find((a) => a.id === o.arch) ?? ARCHETYPES[Math.floor(Math.random() * ARCHETYPES.length)];
    this.role = o.role ?? 'customer';
    this.anomalous = o.anomalous ?? false;
    this.quirk = o.quirk ?? null;
    this.h = this.role === 'faceless' ? buildFaceless(g.shadows) : new Humanoid(this.arch.style, g.shadows);
    if (this.role === 'faceless') this.anomalous = true;
    this.speed = this.arch.speed * (this.role === 'faceless' ? 0.75 : 1);
    const start = o.at ?? new THREE.Vector3(Math.random() < 0.5 ? -26 : 26, 0, 9 + Math.random() * 4);
    this.pos = start.clone();
    this.yaw = o.yaw ?? 0;
    this.h.root.position.copy(this.pos);
    g.scene.add(this.h.root);
    this.h.root.traverse((c) => c.layers.set(0));
    this.stops = this.quirk === 'quick' ? 0 : 1 + Math.floor(Math.random() * 2);
    if (this.role === 'waiting') { this.state = 'idle'; }
    else this.goTo(g.station!.a.frontOut);
    if (this.quirk === 'reflection') {
      this.reflection = new Humanoid(this.arch.style, false);
      this.reflection.root.visible = false;
      g.scene.add(this.reflection.root);
      this.reflection.root.traverse((c) => c.layers.set(1));
    }
  }

  get name() { return this.role === 'faceless' ? '؟' : this.arch.name; }

  goTo(target: THREE.Vector3) {
    const st = this.g.station!; const nav = st.nav;
    const from = nav.nearest(this.pos.x, this.pos.z, st.col);
    const to = nav.nearest(target.x, target.z, st.col);
    const ids = nav.path(from, to);
    this.path = [...ids.map((i) => new THREE.Vector3(nav.nodes[i].x, 0, nav.nodes[i].z)), target.clone()];
    if (ids.length === 0 && from !== to) this.path = [new THREE.Vector3(nav.nodes[from].x, 0, nav.nodes[from].z), new THREE.Vector3(nav.nodes[to].x, 0, nav.nodes[to].z), target.clone()];
  }

  private step(dt: number, speed: number): boolean {
    if (!this.path.length) return true;
    const t = this.path[0];
    const dx = t.x - this.pos.x, dz = t.z - this.pos.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.18) { this.path.shift(); return this.path.length === 0; }
    // doors
    const st = this.g.station!;
    for (const door of Object.values(st.doors)) {
      if (!door.open && !door.locked && door.pos.distanceTo(tmp.set(this.pos.x, 1.2, this.pos.z)) < 1.5) door.setOpen(true);
    }
    const mv = Math.min(d, speed * dt);
    this.pos.x += (dx / d) * mv; this.pos.z += (dz / d) * mv;
    const ty = Math.atan2(dx, dz);
    this.turnTo(ty, dt * 6);
    return false;
  }
  turnTo(ty: number, k: number) {
    let df = ty - this.yaw; df = Math.atan2(Math.sin(df), Math.cos(df));
    this.yaw += df * Math.min(1, k);
  }

  inStore() { return this.pos.z < 4 && this.pos.z > -5 && Math.abs(this.pos.x) < 14; }

  update(dt: number) {
    const g = this.g; const pl = g.player;
    let moving = 0; let still = false;
    const toPlayer = tmp.set(pl.pos.x - this.pos.x, 0, pl.pos.z - this.pos.z);
    const pd = toPlayer.length();
    const playerYaw = Math.atan2(toPlayer.x, toPlayer.z);
    if (this.inStore()) this.inStoreT += dt;
    this.timer -= dt;

    switch (this.state) {
      case 'idle': still = this.role !== 'waiting'; if (this.faceYaw !== null) this.turnTo(this.faceYaw, dt * 3); break;
      case 'arrive':
        moving = this.speed;
        if (this.step(dt, this.speed)) { this.state = 'enter'; this.goTo(g.station!.a.frontIn); }
        break;
      case 'enter':
        moving = this.speed;
        if (this.step(dt, this.speed)) {
          if (this.quirk === 'quick') { this.state = 'quickwait'; this.timer = 3 + Math.random() * 2; }
          else this.nextBrowse();
        }
        break;
      case 'quickwait':
        this.turnTo(playerYaw, dt * 2);
        if (this.timer <= 0) this.leave();
        break;
      case 'tobrowse':
        moving = this.speed;
        if (this.step(dt, this.speed)) { this.state = 'browse'; this.timer = 2.5 + Math.random() * 3; }
        break;
      case 'browse':
        if (this.faceYaw !== null) this.turnTo(this.faceYaw, dt * 4);
        this.h.rArm.rotation.x = -0.9 + Math.sin(performance.now() * 0.003) * 0.2; this.h.rArmOverride = true;
        if (this.quirk === 'freeze' && !this.quirkDone && this.timer < 1.5) { this.quirkDone = true; this.state = 'freeze'; this.timer = 7 + Math.random() * 4; this.h.rArmOverride = false; break; }
        if (this.quirk === 'leave' && !this.quirkDone && this.timer < 1) { this.quirkDone = true; this.h.rArmOverride = false; audio.whisper(this.pos.clone().setY(1.6), 0.08, 1); this.leave(2.2); break; }
        if (this.timer <= 0) {
          this.h.rArmOverride = false;
          if (!this.holding && Math.random() < 0.85) this.pickItem();
          this.stops--;
          if (this.stops > 0) this.nextBrowse(); else { this.state = 'toqueue'; this.goTo(g.station!.a.queue); }
        }
        break;
      case 'freeze':
        still = true;
        this.h.neck.rotation.x = pd < 2.5 ? Math.max(-0.1, this.h.neck.rotation.x - dt * 0.3) : Math.min(0.6, this.h.neck.rotation.x + dt);
        if (pd < 2.5) this.turnTo(playerYaw, dt * 0.4);
        if (this.timer <= 0) { this.h.neck.rotation.x = 0; this.nextBrowse(); }
        break;
      case 'turned':
        still = true;
        if (this.timer <= 0) { this.state = this.path.length ? 'tobrowse' : 'browse'; this.timer = Math.max(this.timer, 1); }
        break;
      case 'toqueue':
        moving = this.speed;
        if (this.step(dt, this.speed)) { this.state = 'queue'; this.timer = this.patience; this.faceYaw = Math.PI; if (this.role !== 'faceless' && !this.anomalous) this.idleLine(); }
        break;
      case 'queue':
        this.turnTo(this.faceYaw ?? Math.PI, dt * 4);
        if (this.timer <= 0) { g.say(this.name, 'بی‌خیال...', 2.5); this.leave(); }
        break;
      case 'leave':
        moving = this.speed;
        if (this.step(dt, this.speed)) {
          if (this.path.length === 0 && this.pos.distanceTo(g.station!.a.frontOut) < 0.6) {
            this.goTo(new THREE.Vector3(this.pos.x < 0 ? -30 : 30, 0, 11)); this.state = 'exit';
          }
        }
        break;
      case 'exit':
        moving = this.speed;
        if (this.step(dt, this.speed)) this.remove();
        break;
    }

    // quirk: sudden turn when watched
    if (this.quirk === 'turn' && !this.quirkDone && this.inStore() && pd < 9 && g.isLooking(this.pos.clone().setY(1.5), 0.94)) {
      this.quirkDone = true; this.yaw = playerYaw; this.state = 'turned'; this.timer = 2.2; audio.stinger(0.12);
    }

    // proximity agitation for anomalous visitors
    if (this.anomalous && this.inStore() && !g.dialogueOpen && this.state !== 'queue') {
      if (pd < 1.35) {
        this.closeT += dt;
        if (this.closeT > 2.5) { this.closeT = 0; this.agitate('close'); }
      } else this.closeT = Math.max(0, this.closeT - dt);
    }

    // head tracking
    let headTarget = 0;
    const rel = Math.atan2(Math.sin(playerYaw - this.yaw), Math.cos(playerYaw - this.yaw));
    if (this.quirk === 'stare' || (this.role === 'faceless' && this.headLock > 0)) headTarget = Math.max(-2.4, Math.min(2.4, rel));
    else if (pd < 4 && Math.abs(rel) < 1.4 && (this.state === 'queue' || this.talking)) headTarget = rel;
    else if (this.anomalous && pd < 6 && Math.abs(rel) < 1.2) headTarget = rel * 0.6;
    if (this.role === 'faceless' && g.isLooking(this.pos.clone().setY(1.6), 0.95) && pd < 14) this.headLock = Math.min(5, this.headLock + dt);
    else this.headLock = Math.max(0, this.headLock - dt * 0.5);
    const hk = this.role === 'faceless' ? dt * 0.35 : dt * 4;
    this.h.neck.rotation.y += (headTarget - this.h.neck.rotation.y) * Math.min(1, hk);

    this.h.root.position.copy(this.pos);
    this.h.root.rotation.y = this.yaw;
    if (!still) this.h.animate(dt, moving, { stiff: this.anomalous });

    if (this.reflection) {
      const r = this.reflection;
      const show = this.inStore() && this.pos.z > -1.5 && Math.abs(this.pos.x) < 13.5 && g.player.pos.z < 4;
      r.root.visible = show;
      if (show) {
        r.root.position.set(this.pos.x, 0, 8 - this.pos.z + 0.05);
        const ry = Math.atan2(pl.pos.x - r.root.position.x, pl.pos.z - r.root.position.z);
        r.root.rotation.y = ry; // mismatch: reflection stares at the player, never mirrors
      }
    }
  }

  nextBrowse() {
    const b = BROWSE[Math.floor(Math.random() * BROWSE.length)];
    this.goTo(new THREE.Vector3(b[0], 0, b[1]));
    this.faceYaw = b[2];
    this.state = 'tobrowse';
  }

  pickItem() {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.16, 0.06), new THREE.MeshLambertMaterial({ color: [0xc0392b, 0xf1c40f, 0x2980b9, 0x27ae60][Math.floor(Math.random() * 4)] }));
    m.position.set(0, -0.04, 0.02);
    this.h.hand.add(m); this.holding = m;
    audio.clink(this.pos.clone().setY(1));
  }

  idleLine() {
    const l = this.arch.lines[Math.floor(Math.random() * this.arch.lines.length)];
    this.speak(l);
  }

  speak(text: string, eerie = false) {
    const p = this.pos.clone().setY(1.6);
    audio.voice(p, this.arch.pitch * (eerie ? 0.7 : 1), Math.min(3, 0.5 + text.length * 0.05), 0.14, eerie);
    this.g.say(this.name, text, 2.5 + text.length * 0.06);
  }

  leave(speedMul = 1) {
    this.state = 'leave';
    this.speed = this.arch.speed * speedMul;
    this.goTo(this.g.station!.a.frontOut);
  }

  agitate(reason: string) {
    this.agitation++;
    this.g.violation(reason);
    audio.whisper(this.pos.clone().setY(1.6), 0.14, 1.4);
    this.h.neck.rotation.z = 0.5;
    setTimeout(() => { this.h.neck.rotation.z = 0; }, 600);
    if (this.agitation >= 2) this.g.anomalyReact(this);
  }

  /** dialogue at register; returns reply text and whether the dialogue ends */
  respond(opt: string): { text: string; end: boolean } {
    const strange = this.anomalous;
    if (opt === 'pay') {
      this.served = true;
      const thanks = strange ? STRANGE_LINES[Math.floor(Math.random() * STRANGE_LINES.length)] : ['مرسی.', 'ممنون، شب خوش.', 'دستت درد نکنه.'][Math.floor(Math.random() * 3)];
      return { text: thanks, end: true };
    }
    if (strange) {
      if (opt === 'greet') return { text: this.role === 'faceless' ? '...' : 'شب... بخیر...', end: false };
      this.agitate('question');
      if (this.agitation >= 2) return { text: '', end: true };
      const t = opt === 'ok' ? ['خوبم. حالا که تو اینجایی.', 'چرا می‌پرسی؟', '...'][Math.floor(Math.random() * 3)] : ['از همین‌جا. همیشه همین‌جا بودم.', 'از پایین.', 'تو چرا اینو می‌پرسی؟'][Math.floor(Math.random() * 3)];
      return { text: this.role === 'faceless' ? '' : t, end: false };
    }
    return { text: this.arch.answers[opt] ?? '...', end: false };
  }

  remove() {
    if (this.removed) return;
    this.removed = true;
    this.g.scene.remove(this.h.root);
    if (this.reflection) this.g.scene.remove(this.reflection.root);
  }
}

export class NPCManager {
  list: Customer[] = [];
  constructor(private g: Game) {}
  spawn(o: SpawnOpts = {}) { const c = new Customer(this.g, o); this.list.push(c); return c; }
  update(dt: number) {
    for (const c of this.list) if (!c.removed) c.update(dt);
    this.list = this.list.filter((c) => !c.removed);
  }
  waiting() { return this.list.find((c) => c.state === 'queue'); }
  active() { return this.list.filter((c) => c.role !== 'waiting').length; }
  clear() { this.list.forEach((c) => c.remove()); this.list = []; }
}
