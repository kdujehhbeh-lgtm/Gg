// High-detail store merchandise: designed packaging textures (chips, puffs, cans, PET bottles, cartons,
// chocolate, biscuits, motor oil) rendered with instancing (one draw call per design).
import * as THREE from 'three';
import { getQuality } from './textures';
import { rrect } from './docs';

const FONT = 'Vazirmatn, Tahoma, Arial, sans-serif';
const texCache = new Map<string, THREE.CanvasTexture>();
let seed = 1;
const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
function T(key: string, w: number, h: number, draw: (c: CanvasRenderingContext2D, w: number, h: number) => void) {
  const hit = texCache.get(key); if (hit) return hit;
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  seed = 3; for (let i = 0; i < key.length; i++) seed = (seed * 33 + key.charCodeAt(i)) % 2147483647;
  draw(cv.getContext('2d')!, w, h);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  texCache.set(key, t); return t;
}
function txt(c: CanvasRenderingContext2D, s: string, x: number, y: number, size: number, color: string, weight = '900', stroke?: string, maxW?: number) {
  c.font = `${weight} ${size}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.direction = /[\u0600-\u06FF]/.test(s) ? 'rtl' : 'ltr';
  if (stroke) { c.lineWidth = size * 0.16; c.strokeStyle = stroke; c.lineJoin = 'round'; c.strokeText(s, x, y, maxW); }
  c.fillStyle = color; c.fillText(s, x, y, maxW); c.direction = 'ltr';
}
function sheen(c: CanvasRenderingContext2D, w: number, h: number, a = 0.35) {
  const g = c.createLinearGradient(0, 0, w, 0);
  g.addColorStop(0, `rgba(0,0,0,${a * 0.6})`); g.addColorStop(0.18, `rgba(255,255,255,${a})`); g.addColorStop(0.32, 'rgba(255,255,255,0)');
  g.addColorStop(0.7, 'rgba(255,255,255,0)'); g.addColorStop(0.85, `rgba(255,255,255,${a * 0.5})`); g.addColorStop(1, `rgba(0,0,0,${a * 0.7})`);
  c.fillStyle = g; c.fillRect(0, 0, w, h);
}
function crisp(c: CanvasRenderingContext2D, x: number, y: number, r: number, base: string, spice?: string) {
  c.save(); c.translate(x, y); c.rotate(rnd() * 6);
  const g = c.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
  g.addColorStop(0, '#fff3c4'); g.addColorStop(0.6, base); g.addColorStop(1, '#a8701e');
  c.fillStyle = g; c.beginPath();
  for (let i = 0; i <= 12; i++) { const a = (i / 12) * Math.PI * 2; const rr = r * (0.85 + rnd() * 0.25); c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr * 0.8); }
  c.fill();
  c.strokeStyle = 'rgba(150,90,20,0.35)'; c.lineWidth = 1; for (let i = 0; i < 3; i++) { c.beginPath(); c.arc(0, 0, r * (0.3 + i * 0.2), 0.2, 2); c.stroke(); }
  if (spice) { c.fillStyle = spice; for (let i = 0; i < 14; i++) c.fillRect((rnd() - 0.5) * r * 1.4, (rnd() - 0.5) * r, 2, 2); }
  c.restore();
}
function puff(c: CanvasRenderingContext2D, x: number, y: number, len: number, col: string) {
  c.save(); c.translate(x, y); c.rotate(rnd() * 6);
  const g = c.createLinearGradient(0, -len * 0.25, 0, len * 0.25); g.addColorStop(0, '#ffd27a'); g.addColorStop(0.5, col); g.addColorStop(1, '#a8450a');
  c.fillStyle = g; c.beginPath();
  for (let i = 0; i <= 16; i++) { const t = i / 16; const px = (t - 0.5) * len; const py = Math.sin(t * Math.PI) * len * 0.22 * (0.8 + rnd() * 0.4); c.lineTo(px, -py); }
  for (let i = 16; i >= 0; i--) { const t = i / 16; const px = (t - 0.5) * len; const py = Math.sin(t * Math.PI) * len * 0.2 * (0.8 + rnd() * 0.4); c.lineTo(px, py); }
  c.fill();
  c.fillStyle = 'rgba(255,240,200,0.5)'; for (let i = 0; i < 6; i++) c.fillRect((rnd() - 0.5) * len * 0.7, (rnd() - 0.5) * len * 0.15, 2, 2);
  c.restore();
}
function nutrition(c: CanvasRenderingContext2D, x: number, y: number, w: number) {
  c.fillStyle = 'rgba(255,255,255,0.92)'; c.fillRect(x, y, w, 26);
  const cols = ['#3aa63a', '#f2b81a', '#e05a1a', '#c81e1e'];
  for (let i = 0; i < 4; i++) { c.fillStyle = cols[i]; c.fillRect(x + 3 + i * (w - 6) / 4, y + 3, (w - 10) / 4, 20); }
  c.fillStyle = '#111'; c.font = `bold 9px ${FONT}`; c.textAlign = 'center';
  ['قند', 'چربی', 'نمک', 'کالری'].forEach((s, i) => { c.direction = 'rtl'; c.fillText(s, x + 3 + i * (w - 6) / 4 + (w - 10) / 8, y + 16); });
  c.direction = 'ltr';
}

// ---------------- packaging designs ----------------
interface ChipD { brand: string; flavor: string; bg: [string, string]; accent: string; text: string; crisp: string; spice?: string; puff?: boolean }
const CHIPS: ChipD[] = [
  { brand: 'کریسپو', flavor: 'ساده نمکی', bg: ['#f7d417', '#e8a400'], accent: '#c41e1e', text: '#ffffff', crisp: '#f1c35a' },
  { brand: 'کریسپو', flavor: 'سرکه نمکی', bg: ['#2fbf56', '#137a32'], accent: '#ffffff', text: '#0f5a24', crisp: '#f0c560', spice: '#6aa84f' },
  { brand: 'آتیشی', flavor: 'فلفل تند', bg: ['#1a1a1a', '#3a0606'], accent: '#ff3b1a', text: '#ffcf33', crisp: '#e8902a', spice: '#c4200a' },
  { brand: 'کریسپو', flavor: 'پنیر و پیاز', bg: ['#6a2fb8', '#3b137a'], accent: '#f7d417', text: '#ffffff', crisp: '#f1c35a', spice: '#3a7a2a' },
  { brand: 'چیپسی', flavor: 'ماست و موسیر', bg: ['#2f7de1', '#123f8a'], accent: '#ffffff', text: '#ffffff', crisp: '#f3cf6c', spice: '#2a6a2a' },
];
const PUFFS: ChipD[] = [
  { brand: 'پفکو', flavor: 'پنیری', bg: ['#ff8a1a', '#e2520a'], accent: '#ffe14d', text: '#ffffff', crisp: '#ff9a2a', puff: true },
  { brand: 'پفکو', flavor: 'کچاپ', bg: ['#e51d2a', '#8a0a12'], accent: '#ffe14d', text: '#ffffff', crisp: '#ff8a2a', puff: true },
  { brand: 'توپولی', flavor: 'بادام‌زمینی', bg: ['#8a5a2a', '#4a2a10'], accent: '#ffd36a', text: '#ffffff', crisp: '#e0a04a', puff: true },
];
function bagTex(d: ChipD) {
  return T('bag-' + d.brand + d.flavor, 256, 320, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, w, h); g.addColorStop(0, d.bg[0]); g.addColorStop(1, d.bg[1]); c.fillStyle = g; c.fillRect(0, 0, w, h);
    // radial burst
    c.save(); c.translate(w / 2, h * 0.42); for (let i = 0; i < 24; i++) { c.rotate(Math.PI / 12); c.fillStyle = 'rgba(255,255,255,0.07)'; c.beginPath(); c.moveTo(0, 0); c.lineTo(200, -20); c.lineTo(200, 20); c.fill(); } c.restore();
    // crimp bands
    for (const y of [0, h - 22]) { c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(0, y, w, 22); for (let x = 0; x < w; x += 6) { c.fillStyle = 'rgba(255,255,255,0.18)'; c.fillRect(x, y, 2, 22); } }
    // brand ribbon
    c.save(); c.translate(w / 2, 62); c.rotate(-0.08);
    c.fillStyle = d.accent; c.beginPath(); c.ellipse(0, 0, 112, 36, 0, 0, Math.PI * 2); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.8)'; c.lineWidth = 3; c.stroke();
    txt(c, d.brand, 0, 2, 44, d.accent === '#ffffff' || d.accent === '#ffe14d' || d.accent === '#f7d417' || d.accent === '#ffd36a' ? '#b0101a' : '#ffffff', '900', 'rgba(0,0,0,0.25)');
    c.restore();
    // product "photo"
    const cy = h * 0.55;
    const pg = c.createRadialGradient(w / 2, cy, 10, w / 2, cy, 110); pg.addColorStop(0, 'rgba(255,255,255,0.45)'); pg.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = pg; c.fillRect(0, 0, w, h);
    for (let i = 0; i < (d.puff ? 16 : 11); i++) {
      const x = w / 2 + (rnd() - 0.5) * 170, y = cy + (rnd() - 0.5) * 90;
      if (d.puff) puff(c, x, y, 36 + rnd() * 18, d.crisp); else crisp(c, x, y, 22 + rnd() * 12, d.crisp, d.spice);
    }
    // flavor tag
    c.fillStyle = 'rgba(255,255,255,0.95)'; rrect(c, 28, h - 92, w - 56, 38, 19); c.fill();
    txt(c, d.flavor, w / 2, h - 72, 24, d.bg[1], '900');
    txt(c, d.puff ? '۹۰ گرم' : '۶۰ گرم', w - 40, h - 36, 14, d.text, 'bold');
    c.fillStyle = '#fff'; c.fillRect(18, h - 46, 46, 16); c.fillStyle = '#000'; for (let i = 0; i < 18; i++) c.fillRect(20 + i * 2.4, h - 44, rnd() < 0.5 ? 1 : 1.6, 12);
    sheen(c, w, h, 0.32);
  });
}
interface CanD { brand: string; sub: string; bg: string; band: string; text: string; liquid: number }
const CANS: CanD[] = [
  { brand: 'Nine Cola', sub: 'کولا', bg: '#d4141e', band: '#ffffff', text: '#ffffff', liquid: 0x2a0c06 },
  { brand: 'Nine Zero', sub: 'بدون قند', bg: '#141414', band: '#d4141e', text: '#ffffff', liquid: 0x2a0c06 },
  { brand: 'Limona', sub: 'لیمویی', bg: '#2fbf56', band: '#f7e417', text: '#ffffff', liquid: 0xd8f0a0 },
  { brand: 'Portaghal', sub: 'پرتقالی', bg: '#ff7a10', band: '#ffffff', text: '#ffffff', liquid: 0xff9a20 },
  { brand: 'VOLT', sub: 'انرژی‌زا', bg: '#1d3fa8', band: '#c0c4c8', text: '#7dff3a', liquid: 0xe8ff7a },
  { brand: 'Malt', sub: 'ماءالشعیر', bg: '#e8c230', band: '#4a2a10', text: '#3a1a08', liquid: 0x8a5a1a },
];
function canTex(d: CanD) {
  return T('can-' + d.brand, 512, 256, (c, w, h) => {
    c.fillStyle = d.bg; c.fillRect(0, 0, w, h);
    // dynamic wave band
    c.fillStyle = d.band; c.beginPath(); c.moveTo(0, h * 0.62);
    for (let x = 0; x <= w; x += 8) c.lineTo(x, h * 0.62 + Math.sin((x / w) * Math.PI * 4) * 16);
    c.lineTo(w, h * 0.74); for (let x = w; x >= 0; x -= 8) c.lineTo(x, h * 0.74 + Math.sin((x / w) * Math.PI * 4 + 0.6) * 14); c.fill();
    for (const cx of [w * 0.25, w * 0.75]) {
      c.save(); c.translate(cx, h * 0.38); c.rotate(-0.06);
      txt(c, d.brand, 0, 0, 52, d.text, '900', 'rgba(0,0,0,0.3)'); c.restore();
      txt(c, d.sub, cx, h * 0.52, 22, d.text, 'bold');
    }
    txt(c, '۳۳۰ میلی‌لیتر', w * 0.5, h * 0.86, 14, d.text, 'bold');
    nutrition(c, w * 0.42, h * 0.08, 90);
    // rims
    for (const y of [0, h - 12]) { const g = c.createLinearGradient(0, y, 0, y + 12); g.addColorStop(0, '#9aa0a6'); g.addColorStop(0.5, '#eef2f5'); g.addColorStop(1, '#8a9096'); c.fillStyle = g; c.fillRect(0, y, w, 12); }
    // condensation droplets
    for (let i = 0; i < 260; i++) { const x = rnd() * w, y = 14 + rnd() * (h - 28), r = 0.8 + rnd() * 2.4; c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill(); c.fillStyle = 'rgba(0,0,0,0.15)'; c.beginPath(); c.arc(x + r * 0.3, y + r * 0.4, r * 0.6, 0, Math.PI * 2); c.fill(); }
  });
}
function canTopTex() {
  return T('cantop', 128, 128, (c, w, h) => {
    const g = c.createRadialGradient(w / 2, h / 2, 5, w / 2, h / 2, 64); g.addColorStop(0, '#d8dde2'); g.addColorStop(0.8, '#a7adb3'); g.addColorStop(0.9, '#eef2f5'); g.addColorStop(1, '#8a9096');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    c.fillStyle = '#8a9096'; c.beginPath(); c.ellipse(w / 2, h * 0.36, 16, 26, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = '#c8cdd2'; c.beginPath(); c.ellipse(w / 2, h * 0.6, 10, 8, 0, 0, Math.PI * 2); c.fill();
  });
}
interface BottleD { brand: string; sub: string; label: string; text: string; liquid: number; opacity: number; cap: number; size: number }
const BOTTLES: BottleD[] = [
  { brand: 'آبشار', sub: 'آب معدنی', label: '#2f8ae1', text: '#ffffff', liquid: 0xcfe8ff, opacity: 0.32, cap: 0x2f8ae1, size: 1.0 },
  { brand: 'Nine Cola', sub: 'خانواده', label: '#d4141e', text: '#ffffff', liquid: 0x1a0804, opacity: 0.92, cap: 0xd4141e, size: 1.25 },
  { brand: 'Portaghal', sub: 'پرتقالی', label: '#ff7a10', text: '#ffffff', liquid: 0xff8a10, opacity: 0.85, cap: 0xff7a10, size: 1.1 },
  { brand: 'Limona', sub: 'لیمویی', label: '#2fbf56', text: '#ffffff', liquid: 0xd0f0a0, opacity: 0.55, cap: 0x2fbf56, size: 1.1 },
  { brand: 'دوغ گلپر', sub: 'گازدار', label: '#ffffff', text: '#1a6a2a', liquid: 0xf4f4ee, opacity: 0.95, cap: 0x1a8a2a, size: 1.15 },
];
function bottleLabelTex(d: BottleD) {
  return T('blab-' + d.brand, 512, 128, (c, w, h) => {
    c.fillStyle = d.label; c.fillRect(0, 0, w, h);
    const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(255,255,255,0.25)'); g.addColorStop(0.5, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,0.2)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    for (const cx of [w * 0.25, w * 0.75]) { txt(c, d.brand, cx, h * 0.42, 40, d.text, '900', d.label === '#ffffff' ? undefined : 'rgba(0,0,0,0.25)', 220); txt(c, d.sub, cx, h * 0.78, 18, d.text, 'bold'); }
    if (d.brand === 'آبشار') { c.strokeStyle = 'rgba(255,255,255,0.6)'; c.lineWidth = 3; for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(0, 20 + i * 8); c.bezierCurveTo(w * 0.3, 10 + i * 8, w * 0.6, 34 + i * 8, w, 18 + i * 8); c.stroke(); } }
  });
}
interface BoxD { brand: string; sub: string; bg: string; fg: string; art: 'biscuit' | 'cereal' | 'wafer' }
const BOXES: BoxD[] = [
  { brand: 'بیسکوییت', sub: 'ساقه طلایی', bg: '#1d4fa8', fg: '#ffd36a', art: 'biscuit' },
  { brand: 'کورن فلکس', sub: 'صبحانه', bg: '#e8a400', fg: '#b0101a', art: 'cereal' },
  { brand: 'ویفر', sub: 'شکلاتی', bg: '#5a2a14', fg: '#ffd36a', art: 'wafer' },
];
function boxTex(d: BoxD) {
  return T('box-' + d.brand, 256, 360, (c, w, h) => {
    c.fillStyle = d.bg; c.fillRect(0, 0, w, h);
    const g = c.createRadialGradient(w / 2, h * 0.6, 10, w / 2, h * 0.6, 150); g.addColorStop(0, 'rgba(255,255,255,0.35)'); g.addColorStop(1, 'rgba(255,255,255,0)'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    txt(c, d.brand, w / 2, 56, 44, d.fg, '900', 'rgba(0,0,0,0.35)', w - 20);
    txt(c, d.sub, w / 2, 100, 22, '#ffffff', 'bold');
    if (d.art === 'cereal') {
      c.fillStyle = '#f5f5f0'; c.beginPath(); c.ellipse(w / 2, h * 0.68, 90, 46, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#d8d8d0'; c.beginPath(); c.ellipse(w / 2, h * 0.66, 80, 36, 0, 0, Math.PI * 2); c.fill();
      for (let i = 0; i < 30; i++) { c.fillStyle = ['#f2b13a', '#e89a20', '#f7c860'][i % 3]; c.beginPath(); c.ellipse(w / 2 + (rnd() - 0.5) * 140, h * 0.64 + (rnd() - 0.5) * 50, 10, 7, rnd() * 3, 0, Math.PI * 2); c.fill(); }
    } else if (d.art === 'biscuit') {
      for (let i = 0; i < 5; i++) { c.save(); c.translate(w / 2 - 50 + i * 25, h * 0.66 - i * 6); c.rotate(-0.3); c.fillStyle = '#e0a85a'; c.fillRect(-40, -26, 80, 52); c.fillStyle = '#c88a3a'; for (let k = 0; k < 6; k++) c.fillRect(-32 + (k % 3) * 26, -16 + Math.floor(k / 3) * 22, 4, 4); c.restore(); }
    } else {
      for (let i = 0; i < 4; i++) { c.save(); c.translate(w / 2, h * 0.58 + i * 22); c.rotate(-0.15); c.fillStyle = '#d8b07a'; c.fillRect(-80, -10, 160, 18); c.strokeStyle = '#a07a40'; for (let k = -76; k < 80; k += 8) { c.beginPath(); c.moveTo(k, -10); c.lineTo(k, 8); c.stroke(); } c.fillStyle = '#4a2010'; c.fillRect(-80, 4, 160, 5); c.restore(); }
    }
    c.fillStyle = '#ffffff'; c.beginPath(); c.arc(w - 40, h - 46, 28, 0, Math.PI * 2); c.fill();
    txt(c, 'جدید', w - 40, h - 46, 16, '#c41e1e', '900');
    sheen(c, w, h, 0.15);
  });
}
const CHOCS = [{ b: 'شکلاتو', bg: '#4a2010', fg: '#ffd36a' }, { b: 'نوقا', bg: '#c41e1e', fg: '#ffffff' }, { b: 'کاکائو', bg: '#1d4fa8', fg: '#ffffff' }];
function chocTex(i: number) {
  const d = CHOCS[i];
  return T('choc-' + d.b, 256, 96, (c, w, h) => {
    c.fillStyle = d.bg; c.fillRect(0, 0, w, h);
    for (let x = 0; x < w; x += 4) { c.fillStyle = 'rgba(255,255,255,0.06)'; c.fillRect(x, 0, 1, h); }
    c.fillStyle = '#5a2e14'; rrect(c, w * 0.08, h * 0.25, 60, 48, 8); c.fill();
    c.fillStyle = '#7a4a24'; for (let k = 0; k < 4; k++) c.fillRect(w * 0.08 + 6 + (k % 2) * 28, h * 0.25 + 6 + Math.floor(k / 2) * 22, 22, 16);
    txt(c, d.b, w * 0.62, h / 2, 40, d.fg, '900', 'rgba(0,0,0,0.3)');
    sheen(c, w, h, 0.3);
  });
}
function oilTex() {
  return T('oil', 256, 360, (c, w, h) => {
    const g = c.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#111'); g.addColorStop(0.5, '#2a2a2a'); g.addColorStop(1, '#111'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    c.fillStyle = '#e8b400'; c.fillRect(0, h * 0.28, w, h * 0.42);
    txt(c, 'MOTOR', w / 2, h * 0.38, 40, '#111', '900'); txt(c, '10W-40', w / 2, h * 0.52, 46, '#c41e1e', '900'); txt(c, 'روغن موتور', w / 2, h * 0.64, 22, '#111', 'bold');
    txt(c, '۴ لیتر', w / 2, h * 0.85, 22, '#e8b400', 'bold');
    sheen(c, w, h, 0.25);
  });
}

// ---------------- geometry ----------------
function pillowGeo(w: number, h: number, d: number) {
  const g = new THREE.BoxGeometry(w, h, d, 6, 8, 1);
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i) / (w / 2), y = p.getY(i) / (h / 2);
    const bulge = Math.max(0.08, (1 - x * x * 0.55) * (1 - Math.pow(Math.abs(y), 4) * 0.92));
    p.setZ(i, p.getZ(i) * bulge);
    p.setX(i, p.getX(i) * (1 - Math.pow(Math.abs(y), 6) * 0.06));
  }
  g.computeVertexNormals();
  return g;
}
function bottleBody(h: number, r: number) {
  const pts = [[0.001, 0], [r * 0.82, 0], [r, h * 0.03], [r, h * 0.2], [r * 0.9, h * 0.25], [r, h * 0.3], [r, h * 0.6], [r * 0.85, h * 0.7], [r * 0.45, h * 0.86], [r * 0.32, h * 0.92], [r * 0.32, h * 0.96], [0.001, h * 0.96]];
  return new THREE.LatheGeometry(pts.map(([x, y]) => new THREE.Vector2(x, y)), 14);
}

// ---------------- batching ----------------
const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), pv = new THREE.Vector3(), sv = new THREE.Vector3();
class Batch {
  list: { x: number; y: number; z: number; ry: number; s: number }[] = [];
  constructor(public geo: THREE.BufferGeometry, public material: THREE.Material | THREE.Material[], public cast = false) {}
  add(x: number, y: number, z: number, ry: number, s = 1) { this.list.push({ x, y, z, ry, s }); }
  build(parent: THREE.Object3D, shadows: boolean) {
    if (!this.list.length) return;
    const im = new THREE.InstancedMesh(this.geo, this.material, this.list.length);
    this.list.forEach((it, i) => { q.setFromEuler(e.set(0, it.ry, 0)); m4.compose(pv.set(it.x, it.y, it.z), q, sv.set(it.s, it.s, it.s)); im.setMatrixAt(i, m4); });
    im.instanceMatrix.needsUpdate = true; im.castShadow = shadows && this.cast; im.computeBoundingSphere();
    im.frustumCulled = false; // spread across the whole store – never cull the batch
    parent.add(im);
  }
}

export type Kind = 'bag' | 'puff' | 'box' | 'can' | 'bottle' | 'candy' | 'oil' | 'jug';
const SIZE: Record<Kind, [number, number]> = { bag: [0.205, 0.14], puff: [0.215, 0.15], box: [0.2, 0.15], can: [0.072, 0.061], bottle: [0.078, 0], candy: [0.14, 0.012], oil: [0.15, 0.12], jug: [0.115, 0] };
let lowDetail = false;
export function setProductDetail(low: boolean) { lowDetail = low; }

export class ProductSet {
  private batches = new Map<string, Batch[]>();
  private geo: Record<string, THREE.BufferGeometry> = {};
  private std(o: THREE.MeshStandardMaterialParameters) { return getQuality() === 'low' ? new THREE.MeshLambertMaterial({ map: o.map ?? null, color: o.color ?? 0xffffff, transparent: o.transparent, opacity: o.opacity ?? 1, side: o.side }) : new THREE.MeshStandardMaterial(o); }
  private get(key: string, make: () => Batch[]) { let b = this.batches.get(key); if (!b) { b = make(); this.batches.set(key, b); } return b; }
  private g(k: string, f: () => THREE.BufferGeometry) { return (this.geo[k] ||= f()); }
  designs(kind: Kind) { return kind === 'bag' ? CHIPS.length : kind === 'puff' ? PUFFS.length : kind === 'can' ? CANS.length : kind === 'bottle' ? 4 : kind === 'jug' ? 2 : kind === 'box' ? BOXES.length : kind === 'candy' ? CHOCS.length : 1; }
  batch(kind: Kind, d: number): Batch[] {
    return this.get(kind + d, () => {
      switch (kind) {
        case 'bag': case 'puff': {
          const des = kind === 'bag' ? CHIPS[d] : PUFFS[d];
          const geo = this.g(kind, () => pillowGeo(kind === 'bag' ? 0.19 : 0.2, kind === 'bag' ? 0.28 : 0.3, 0.085));
          return [new Batch(geo, this.std({ map: bagTex(des), roughness: 0.28, metalness: 0.35 }), true)];
        }
        case 'can': {
          const geo = this.g('can', () => new THREE.CylinderGeometry(0.033, 0.033, 0.122, 18));
          const top = this.std({ map: canTopTex(), roughness: 0.25, metalness: 0.9 });
          return [new Batch(geo, [this.std({ map: canTex(CANS[d]), roughness: 0.22, metalness: 0.55 }), top, top])];
        }
        case 'bottle': case 'jug': {
          const des = kind === 'bottle' ? BOTTLES[[0, 1, 2, 3][d]] : BOTTLES[d === 0 ? 4 : 0];
          const s = kind === 'jug' ? 1.45 : des.size;
          const H = 0.24 * s, R = 0.032 * Math.sqrt(s);
          const body = this.g('bb' + s, () => bottleBody(H, R));
          const label = this.g('bl' + s, () => new THREE.CylinderGeometry(R * 1.01, R * 1.01, H * 0.26, 14, 1, true).translate(0, H * 0.45, 0));
          const cap = this.g('bc' + s, () => new THREE.CylinderGeometry(R * 0.36, R * 0.36, H * 0.07, 10).translate(0, H * 0.995, 0));
          return [
            new Batch(body, this.std({ color: des.liquid, roughness: 0.08, metalness: 0.1, transparent: true, opacity: des.opacity })),
            new Batch(label, this.std({ map: bottleLabelTex(des), roughness: 0.4 })),
            new Batch(cap, this.std({ color: des.cap, roughness: 0.5 })),
          ];
        }
        case 'box': return [new Batch(this.g('box', () => new THREE.BoxGeometry(0.19, 0.28, 0.065)), this.std({ map: boxTex(BOXES[d]), roughness: 0.65 }), true)];
        case 'candy': return [new Batch(this.g('candy', () => new THREE.BoxGeometry(0.13, 0.024, 0.048)), this.std({ map: chocTex(d), roughness: 0.35, metalness: 0.3 }))];
        case 'oil': return [new Batch(this.g('oil', () => new THREE.BoxGeometry(0.13, 0.24, 0.07)), this.std({ map: oilTex(), roughness: 0.45 }))];
      }
    });
  }
  add(kind: Kind, d: number, x: number, y: number, z: number, ry: number, s = 1) { this.batch(kind, d).forEach((b) => b.add(x, y, z, ry, s)); }
  build(parent: THREE.Object3D, shadows: boolean) { this.batches.forEach((bs) => bs.forEach((b) => b.build(parent, shadows))); }
}

/** fill one shelf row; facing +1 => fronts toward +z (axis 'x') or +x (axis 'z') */
export function fillRow(ps: ProductSet, kind: Kind, axis: 'x' | 'z', a0: number, a1: number, y: number, c: number, facing: number, depthRows = 2) {
  const [step, half] = SIZE[kind];
  const rows = lowDetail ? 1 : depthRows;
  let d = Math.floor(Math.random() * ps.designs(kind)); let run = 0;
  for (let a = a0 + step / 2; a <= a1 - step / 2 + 1e-6; a += step) {
    if (run-- <= 0) { d = Math.floor(Math.random() * ps.designs(kind)); run = 2 + Math.floor(Math.random() * 4); }
    for (let r = 0; r < rows; r++) {
      if (r === 0 && Math.random() < 0.04) continue; // a few sold-out facings
      const off = -facing * (0.07 + r * (kind === 'bag' || kind === 'puff' || kind === 'box' ? 0.1 : 0.075));
      const ry = (axis === 'x' ? (facing > 0 ? 0 : Math.PI) : (facing > 0 ? Math.PI / 2 : -Math.PI / 2)) + (Math.random() - 0.5) * (kind === 'can' || kind === 'bottle' || kind === 'jug' ? 3 : 0.1);
      const lean = kind === 'bag' || kind === 'puff' ? -facing * 0.0 : 0;
      const put = (yy: number) => { if (axis === 'x') ps.add(kind, d, a, yy, c + off + lean, ry); else ps.add(kind, d, c + off + lean, yy, a, ry); };
      put(y + half);
      if (kind === 'candy') for (let k = 1; k < 4; k++) put(y + half + k * 0.025);
      if (kind === 'can' && Math.random() < 0.75) put(y + half + 0.123);
    }
  }
}
