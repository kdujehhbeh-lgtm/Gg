// Random event director: weighted, cooldown-based, non-repeating scares with deliberate quiet periods
import * as THREE from 'three';
import { audio } from './audio';
import type { Game } from './game';
import { DogMonster, TallMonster, WatcherMonster, FacelessMonster } from './monsters';

interface EventDef { id: string; minCh: number; weight: number; cooldown: number; max: number; cond?: (g: Game) => boolean; run: (g: Game) => void }

const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);

const EVENTS: EventDef[] = [
  {
    id: 'bottleFall', minCh: 2, weight: 3, cooldown: 90, max: 3, cond: (g) => g.regionOf(g.player.pos) === 'sales',
    run: (g) => {
      const shelves = [V(-8, 1.7, -2.2), V(-5, 1.7, 1.0), V(-4, 1.7, -2.2), V(-9, 1.7, 1.0)];
      const s = shelves.reduce((a, b) => (b.distanceTo(g.player.pos) < a.distanceTo(g.player.pos) && b.distanceTo(g.player.pos) > 2.5 ? b : a));
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.045, 0.28, 8), new THREE.MeshLambertMaterial({ color: 0x2a6a3a }));
      b.position.copy(s).add(V(0, 0, s.z < 0 ? 0.5 : -0.5)); g.scene.add(b);
      let vy = 0;
      g.onFrame((dt) => { vy -= 9.8 * dt; b.position.y += vy * dt; b.rotation.z += dt * 8; if (b.position.y < 0.05) { audio.glass(b.position.clone(), 0.55); g.emitNoise(b.position, 15); b.rotation.z = Math.PI / 2; b.position.y = 0.05; return false; } return true; });
      g.after(25, () => g.scene.remove(b));
    },
  },
  { id: 'flicker', minCh: 2, weight: 3, cooldown: 40, max: 6, run: (g) => { g.flicker(g.regionOf(g.player.pos), 1.2 + Math.random()); audio.staticBurst(0.3, 0.04); } },
  {
    id: 'powerOut', minCh: 3, weight: 2, cooldown: 120, max: 2, cond: (g) => !!g.station?.lights.sales.on && !g.flags.powerOut,
    run: (g) => {
      const st = g.station!; st.lights.sales.set(false); audio.door(V(0, 3, -0.5), false, true);
      const ghost = Math.random() < 0.4 && !g.monsters.list.some((m) => m.root.visible && m.state !== 'gone');
      g.after(5 + Math.random() * 4, () => {
        if (g.flags.powerOut) return;
        st.lights.sales.set(true); st.lights.sales.flicker(0.6);
        if (ghost) {
          const fm = g.monsters.ensure('faceless', () => new FacelessMonster(g));
          fm.appear(V(-6, 0, -0.6), Math.atan2(g.player.pos.x + 6, g.player.pos.z + 0.6)); fm.t = 4;
        }
      });
    },
  },
  { id: 'doorOpen', minCh: 3, weight: 2, cooldown: 100, max: 3, run: (g) => { const st = g.station!; const d = Math.random() < 0.5 ? st.doors.front : st.doors.back; if (!d.locked && !d.open) { d.setOpen(true); if (d === st.doors.front) audio.bell(d.pos); } } },
  { id: 'customer', minCh: 2, weight: 3, cooldown: 60, max: 4, cond: (g) => !!g.flags.storeOpen && g.npcs.active() < 2 && g.story.allowRandomCustomers, run: (g) => { g.npcs.spawn({ quirk: g.story.chapter >= 3 && Math.random() < 0.5 ? (['stare', 'freeze', 'turn', 'quick', 'leave'] as const)[Math.floor(Math.random() * 5)] : null, anomalous: g.story.chapter >= 3 && Math.random() < 0.3 }); } },
  { id: 'phone', minCh: 3, weight: 2, cooldown: 150, max: 2, cond: (g) => !g.story.phoneBusy, run: (g) => g.story.randomPhone() },
  { id: 'knock', minCh: 3, weight: 2, cooldown: 70, max: 3, run: (g) => { audio.knock(V(-9, 1.5, -10), 3 + Math.floor(Math.random() * 3), 0.6, 0.45); g.emitNoise(V(-9, 0, -10), 2); } },
  {
    id: 'shadowGlass', minCh: 3, weight: 2, cooldown: 90, max: 3, cond: (g) => g.regionOf(g.player.pos) === 'sales',
    run: (g) => {
      const s = new THREE.Mesh(new THREE.CapsuleGeometry(0.3, 1.2, 3, 8), new THREE.MeshBasicMaterial({ color: 0x000000 }));
      const dir = Math.random() < 0.5 ? 1 : -1; s.position.set(-16 * dir, 1, 5.2); g.scene.add(s); s.layers.set(1);
      g.onFrame((dt) => { s.position.x += dir * 9 * dt; if (Math.abs(s.position.x) > 16 && Math.sign(s.position.x) === dir) { g.scene.remove(s); return false; } return true; });
      audio.footstep('concrete', 0.3, s.position.clone());
    },
  },
  {
    id: 'carStart', minCh: 3, weight: 1.5, cooldown: 200, max: 1,
    run: (g) => {
      const gc = g.station!.ghostCar; const snd = audio.engine(0.3, g.station!.a.ghostCar);
      gc.spot.intensity = 60; gc.car.setLights(true);
      g.after(7, () => { snd?.stop(0.4); gc.spot.intensity = 0; gc.car.setLights(false); });
    },
  },
  {
    id: 'creaturePass', minCh: 4, weight: 2, cooldown: 120, max: 2,
    run: (g) => {
      const d = g.monsters.ensure('dog', () => new DogMonster(g));
      if (d.chasing) return;
      const dir = Math.random() < 0.5 ? 1 : -1;
      d.place(V(-40 * dir, 0, 26), dir > 0 ? Math.PI / 2 : -Math.PI / 2); d.show(true); d.setState('hidden');
      g.onFrame((dt) => { d.pos.x += dir * 11 * dt; d.parts.lLeg.rotation.x = Math.sin(g.time * 18) * 0.7; d.parts.rLeg.rotation.x = -Math.sin(g.time * 18) * 0.7; d.sync(); if (Math.abs(d.pos.x) > 40 && Math.sign(d.pos.x) === dir) { d.show(false); d.setState('gone'); return false; } return true; });
    },
  },
  { id: 'cctvCut', minCh: 3, weight: 1.5, cooldown: 120, max: 2, run: (g) => { g.cctvGlitch = true; if (g.cctvIndex >= 0) { audio.staticBurst(1, 0.2); g.updateCCTVUI(); } g.after(30, () => { g.cctvGlitch = false; }); } },
  { id: 'bark', minCh: 2, weight: 2, cooldown: 80, max: 4, run: (g) => { audio.bark(V((Math.random() - 0.5) * 50, 1.5, -28), 0.5); g.emitNoise(V(0, 0, -28), 1); } },
  {
    id: 'tall', minCh: 3, weight: 2, cooldown: 140, max: 3,
    run: (g) => {
      const t = g.monsters.ensure('tall', () => new TallMonster(g));
      if (t.root.visible && t.state !== 'gone') return;
      const inside = g.inBuilding(g.player.pos);
      const spots = inside ? [V(0, 0, -11.4), V(-11, 0, -3.8), V(12, 0, 2.6)] : [V(-30 + Math.random() * 60, 0, 42), V(-34, 0, -20), V(30, 0, -26)];
      const s = spots.filter((p) => !g.isLooking(p.clone().setY(1.5), 0.5) && p.distanceTo(g.player.pos) > 12);
      if (s.length) t.appear(s[Math.floor(Math.random() * s.length)], false, 20 + Math.random() * 15);
    },
  },
  { id: 'watcher', minCh: 3, weight: 2, cooldown: 150, max: 2, cond: (g) => g.regionOf(g.player.pos) === 'sales' && g.player.pos.z < 0, run: (g) => { const w = g.monsters.ensure('watcher', () => new WatcherMonster(g)); if (w.state !== 'observe') w.appear(); } },
  { id: 'whisper', minCh: 3, weight: 1.5, cooldown: 80, max: 3, run: (g) => { const f = g.player.forward(); audio.whisper(g.player.pos.clone().add(V(-f.x * 1.2, 1.6, -f.z * 1.2)), 0.16, 2); } },
  { id: 'storageVoice', minCh: 3, weight: 1, cooldown: 160, max: 2, run: () => { audio.voice(V(-8, 1.5, -9), 80, 2, 0.08, true); } },
  { id: 'dogWatch', minCh: 3, weight: 1.5, cooldown: 160, max: 2, cond: (g) => !g.inBuilding(g.player.pos) || g.regionOf(g.player.pos) === 'storage', run: (g) => { const d = g.monsters.ensure('dog', () => new DogMonster(g)); if (d.chasing || (d.root.visible && d.state !== 'gone')) return; const spots = [V(0, 0, -26), V(-24, 0, -22), V(28, 0, 10), V(-30, 0, 20)]; d.observeAt(spots[Math.floor(Math.random() * spots.length)]); } },
];

export class Director {
  next = 45;
  uses: Record<string, number> = {};
  lastUsed: Record<string, number> = {};
  enabled = false;
  intensity = 1;
  constructor(private g: Game) {}
  reset(enabled: boolean, firstDelay = 40) { this.enabled = enabled; this.next = firstDelay; this.uses = {}; this.lastUsed = {}; }
  update(dt: number) {
    const g = this.g;
    if (!this.enabled || g.dying || g.dialogueOpen) return;
    this.next -= dt;
    if (this.next > 0) return;
    const ch = g.story.chapter;
    // tension curve: longer silences early, shorter later. Sometimes, nothing happens at all.
    const base = ch <= 2 ? 55 : ch === 3 ? 38 : 30;
    this.next = (base + Math.random() * base) / this.intensity;
    if (g.monsters.anyChasing()) return;
    if (Math.random() < 0.22) return; // deliberate quiet
    const pool = EVENTS.filter((e) => ch >= e.minCh && (this.uses[e.id] ?? 0) < e.max && g.time - (this.lastUsed[e.id] ?? -999) > e.cooldown && (!e.cond || e.cond(g)));
    if (!pool.length) return;
    const tot = pool.reduce((a, e) => a + e.weight, 0);
    let r = Math.random() * tot;
    const ev = pool.find((e) => (r -= e.weight) <= 0) ?? pool[0];
    this.uses[ev.id] = (this.uses[ev.id] ?? 0) + 1; this.lastUsed[ev.id] = g.time;
    ev.run(g);
  }
  trigger(id: string) { const ev = EVENTS.find((e) => e.id === id); if (ev) { this.lastUsed[id] = this.g.time; ev.run(this.g); } }
}
