// Realistic fuel dispensers: stainless body, lit brand header, LCD totalizers, card reader/keypad,
// grade labels, real nozzles (spout, trigger, guard, grip) in boots, hanging rubber hoses (tube curves).
import * as THREE from 'three';
import { mat, tex } from './textures';

const FONT = 'Vazirmatn, Tahoma, Arial, sans-serif';
function cTex(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  draw(cv.getContext('2d')!);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return t;
}
const shared: Record<string, THREE.Texture> = {};
function once(k: string, f: () => THREE.Texture) { return (shared[k] ||= f()); }

function headerTex() {
  return once('hdr', () => cTex(512, 128, (c) => {
    const g = c.createLinearGradient(0, 0, 0, 128); g.addColorStop(0, '#1456a8'); g.addColorStop(1, '#0a2f63'); c.fillStyle = g; c.fillRect(0, 0, 512, 128);
    c.fillStyle = '#e11d2a'; c.fillRect(0, 100, 512, 14);
    c.fillStyle = '#fff'; c.font = `900 64px Arial`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('PETRO 24', 256, 50);
  }));
}
function louverTex() {
  return once('louver', () => {
    const t = cTex(128, 256, (c) => {
      const g = c.createLinearGradient(0, 0, 128, 0); g.addColorStop(0, '#8d9296'); g.addColorStop(0.5, '#c9ced2'); g.addColorStop(1, '#8d9296'); c.fillStyle = g; c.fillRect(0, 0, 128, 256);
      for (let y = 0; y < 256; y++) { c.fillStyle = `rgba(255,255,255,${Math.random() * 0.06})`; c.fillRect(0, y, 128, 1); }
      for (let y = 150; y < 240; y += 9) { c.fillStyle = 'rgba(0,0,0,0.55)'; c.fillRect(16, y, 96, 4); c.fillStyle = 'rgba(255,255,255,0.3)'; c.fillRect(16, y + 4, 96, 1); }
      c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2; c.strokeRect(6, 6, 116, 244);
      c.fillStyle = '#e11d2a'; c.font = `900 18px ${FONT}`; c.textAlign = 'center'; c.direction = 'rtl'; c.fillText('سیگار ممنوع', 64, 40); c.fillText('موتور خاموش', 64, 66);
      c.strokeStyle = '#e11d2a'; c.lineWidth = 4; c.beginPath(); c.arc(64, 110, 18, 0, Math.PI * 2); c.moveTo(51, 97); c.lineTo(77, 123); c.stroke();
    });
    return t;
  });
}
function keypadTex() {
  return once('keypad', () => cTex(128, 160, (c) => {
    c.fillStyle = '#1a1c1e'; c.fillRect(0, 0, 128, 160);
    c.fillStyle = '#0a0a0a'; c.fillRect(14, 10, 100, 22); c.fillStyle = '#40ff8a'; c.font = 'bold 12px monospace'; c.fillText('INSERT CARD', 22, 25);
    c.fillStyle = '#333'; c.fillRect(30, 38, 68, 8); c.fillStyle = '#000'; c.fillRect(34, 40, 60, 3);
    for (let r = 0; r < 4; r++) for (let k = 0; k < 3; k++) { c.fillStyle = '#c8ccd0'; c.fillRect(22 + k * 30, 56 + r * 24, 24, 18); c.fillStyle = '#222'; c.font = 'bold 12px Arial'; c.fillText('123456789*0#'[r * 3 + k], 30 + k * 30, 70 + r * 24); }
  }));
}
const GRADES = [
  { name: 'معمولی', oct: '۹۱', col: 0x1f9a3a, css: '#1f9a3a', price: '15,000' },
  { name: 'سوپر', oct: '۹۵', col: 0xf2b81a, css: '#f2b81a', price: '35,000' },
  { name: 'گازوئیل', oct: 'D', col: 0x1a1a1a, css: '#222', price: '3,000' },
];
function gradeTex(i: number) {
  return once('grade' + i, () => cTex(96, 64, (c) => {
    const g = GRADES[i]; c.fillStyle = g.css; c.fillRect(0, 0, 96, 64);
    c.fillStyle = i === 1 ? '#111' : '#fff'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.font = `900 26px ${FONT}`; c.fillText(g.oct, 48, 22); c.font = `bold 16px ${FONT}`; c.direction = 'rtl'; c.fillText(g.name, 48, 48);
  }));
}

export interface Nozzle { obj: THREE.Group; home: THREE.Vector3; homeQ: THREE.Quaternion; hose: THREE.Mesh; anchor: THREE.Vector3; side: number }
export interface Dispenser {
  group: THREE.Group;
  nozzles: Nozzle[];
  setDisplay: (side: number, liters: number, grade?: number) => void;
  moveNozzle: (n: Nozzle, worldPos: THREE.Vector3 | null, lookAtWorld?: THREE.Vector3) => void;
}

const hoseMat = () => mat({ color: 0x141414, rough: 0.55, key: 'hose' });
const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();

function buildNozzle(gradeCol: number) {
  const g = new THREE.Group();
  const metal = mat({ color: 0xb9bdc1, metal: 0.9, rough: 0.28, key: 'nzmetal' });
  const grip = mat({ color: gradeCol, rough: 0.6, key: 'nzgrip' + gradeCol });
  const dark = mat({ color: 0x1a1a1a, rough: 0.5, key: 'nzdark' });
  // body (forward = +z)
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.06, 0.1), metal); g.add(body);
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.05, 10).rotateX(Math.PI / 2), metal); cap.position.z = 0.055; g.add(cap);
  // spout: bent tube
  const spoutCurve = new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0, 0.07), new THREE.Vector3(0, -0.005, 0.15), new THREE.Vector3(0, -0.035, 0.22), new THREE.Vector3(0, -0.08, 0.27)]);
  g.add(new THREE.Mesh(new THREE.TubeGeometry(spoutCurve, 10, 0.0105, 8), metal));
  // grip handle (angled back/down)
  const handle = new THREE.Mesh(new THREE.CapsuleGeometry(0.02, 0.12, 3, 8), grip); handle.position.set(0, -0.07, -0.06); handle.rotation.x = 0.55; g.add(handle);
  const cover = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 0.08), grip); cover.position.set(0, 0.02, -0.01); g.add(cover);
  // trigger lever + guard
  const lever = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.012, 0.11), dark); lever.position.set(0, -0.06, 0.0); lever.rotation.x = 0.35; g.add(lever);
  const guard = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.006, 5, 12, Math.PI * 0.9), metal); guard.position.set(0, -0.045, 0.0); guard.rotation.set(0, Math.PI / 2, Math.PI * 0.55); g.add(guard);
  // swivel connector where the hose enters
  const sw = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.06, 10), metal); sw.position.set(0, -0.13, -0.1); sw.rotation.x = 0.55; g.add(sw);
  g.userData.connector = new THREE.Vector3(0, -0.16, -0.115);
  return g;
}

export function buildDispenser(parent: THREE.Object3D, x: number, z: number, reg: (m: THREE.Material) => void, shadows = false): Dispenser {
  const group = new THREE.Group(); group.position.set(x, 0.2, z); parent.add(group);
  const steel = mat({ map: tex.metal(), color: 0xd0d4d8, metal: 0.75, rough: 0.32, key: 'dsteel' });
  const louver = mat({ map: louverTex(), metal: 0.5, rough: 0.4, key: 'dlouver' });
  const white = mat({ color: 0xeef0f2, rough: 0.35, key: 'dwhite' });
  const red = mat({ color: 0xc8141f, rough: 0.4, metal: 0.2, key: 'dred' });
  const dark = mat({ color: 0x1b1d20, rough: 0.5, key: 'ddark' });
  const box = (w: number, h: number, d: number, m: THREE.Material | THREE.Material[], px: number, py: number, pz: number) => {
    const me = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m as THREE.Material); me.position.set(px, py, pz); me.castShadow = shadows; group.add(me); return me;
  };
  box(0.62, 0.12, 1.08, dark, 0, 0.06, 0); // plinth
  // lower hydraulic cabinet: louvered steel doors on both sides
  box(0.5, 0.95, 0.96, [louver, louver, steel, steel, steel, steel], 0, 0.6, 0);
  // electronics head
  box(0.56, 0.72, 1.04, white, 0, 1.43, 0);
  // red columns (hose towers)
  for (const zc of [-0.56, 0.56]) { box(0.6, 2.05, 0.1, red, 0, 1.05, zc); box(0.64, 0.06, 0.14, dark, 0, 2.09, zc); }
  // lit header
  const hm = new THREE.MeshStandardMaterial({ map: headerTex(), emissive: 0xffffff, emissiveMap: headerTex(), emissiveIntensity: 0.85, roughness: 0.3 });
  reg(hm);
  box(0.6, 0.32, 1.24, [dark, dark, white, dark, hm, hm], 0, 1.98, 0).rotation.y = Math.PI / 2;
  const nozzles: Nozzle[] = [];
  const displays: { side: number; c: CanvasRenderingContext2D; t: THREE.CanvasTexture }[] = [];
  const kp = mat({ map: keypadTex(), rough: 0.5, key: 'kpad' });
  for (const side of [-1, 1]) {
    const fx = side * 0.281;
    // LCD totalizer
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 160;
    const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace;
    const lcd = new THREE.MeshStandardMaterial({ map: t, emissive: 0xffffff, emissiveMap: t, emissiveIntensity: 0.75, roughness: 0.2 });
    reg(lcd);
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.29), lcd); scr.position.set(fx + side * 0.002, 1.58, 0); scr.rotation.y = side * Math.PI / 2; group.add(scr);
    const bezel = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.33, 0.5), dark); bezel.position.set(fx - side * 0.004, 1.58, 0); group.add(bezel);
    displays.push({ side, c: cv.getContext('2d')!, t });
    // keypad / card reader
    const kpm = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.2), kp); kpm.position.set(fx + side * 0.003, 1.25, -0.3 * side); kpm.rotation.y = side * Math.PI / 2; group.add(kpm);
    // three nozzles in boots with grade labels
    [-0.3, 0, 0.3].forEach((dz, gi) => {
      const zc = dz * side;
      const lab = new THREE.Mesh(new THREE.PlaneGeometry(0.11, 0.073), mat({ map: gradeTex(gi), rough: 0.5, key: 'glab' + gi }));
      lab.position.set(fx + side * 0.003, 1.2, zc + (gi === 0 ? 0.0 : 0)); lab.rotation.y = side * Math.PI / 2;
      if (gi !== 0) group.add(lab); else { lab.position.z = zc; group.add(lab); }
      const boot = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.13, 0.085), dark); boot.position.set(fx + side * 0.035, 0.98, zc); group.add(boot);
      const nz = buildNozzle(GRADES[gi].col);
      const home = new THREE.Vector3(fx + side * 0.12, 1.06, zc);
      const dir = new THREE.Vector3(-side, -1.1, 0).normalize();
      const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir);
      nz.position.copy(home); nz.quaternion.copy(q); group.add(nz);
      nz.traverse((o) => { (o as THREE.Mesh).castShadow = shadows; });
      const anchor = new THREE.Vector3(side * 0.2, 1.92, side * 0.56 * (gi === 1 ? 1 : gi === 0 ? 0.92 : 1.0) * (dz >= 0 ? 1 : -1));
      anchor.z = (gi === 0 ? -0.5 : gi === 1 ? 0.5 : 0.5) * side; if (gi === 2) anchor.x = side * 0.27;
      const hose = new THREE.Mesh(new THREE.BufferGeometry(), hoseMat()); hose.castShadow = shadows; group.add(hose);
      const n: Nozzle = { obj: nz, home, homeQ: q.clone(), hose, anchor, side };
      nozzles.push(n);
    });
  }
  const rebuildHose = (n: Nozzle) => {
    n.obj.updateMatrix();
    const end = (n.obj.userData.connector as THREE.Vector3).clone().applyMatrix4(n.obj.matrix);
    const a = n.anchor;
    const out = tmp.set(a.x + n.side * 0.12, a.y - 0.25, a.z);
    const span = tmp2.copy(end).sub(a).length();
    const sagY = Math.max(0.12, Math.min(a.y, end.y) - 0.55 - span * 0.12);
    const mid = new THREE.Vector3((a.x + end.x) / 2 + n.side * 0.18, sagY, (a.z + end.z) / 2);
    const below = end.clone().add(new THREE.Vector3(0, -0.12, 0));
    const curve = new THREE.CatmullRomCurve3([a.clone(), out.clone(), mid, below, end], false, 'centripetal');
    n.hose.geometry.dispose();
    n.hose.geometry = new THREE.TubeGeometry(curve, 28, 0.013, 6);
  };
  nozzles.forEach(rebuildHose);
  const setDisplay = (side: number, liters: number, grade = 0) => {
    const d = displays.find((x) => x.side === side); if (!d) return;
    const c = d.c; c.fillStyle = '#060a08'; c.fillRect(0, 0, 256, 160);
    c.fillStyle = '#0c1a10'; c.fillRect(8, 8, 240, 144);
    const amount = Math.round(liters * parseInt(GRADES[grade].price.replace(',', ''), 10));
    c.textAlign = 'right'; c.textBaseline = 'middle';
    c.fillStyle = '#7dffb0'; c.font = 'bold 44px monospace'; c.fillText(amount.toLocaleString('en-US'), 236, 42);
    c.font = 'bold 34px monospace'; c.fillText(liters.toFixed(2), 236, 96);
    c.fillStyle = '#ffd36a'; c.font = 'bold 22px monospace'; c.fillText(GRADES[grade].price, 236, 136);
    c.textAlign = 'left'; c.fillStyle = '#6fa88a'; c.font = `bold 14px ${FONT}`; c.direction = 'rtl';
    c.fillText('ریال', 50, 42); c.fillText('لیتر', 50, 96); c.fillText('فی', 50, 136); c.direction = 'ltr';
    d.t.needsUpdate = true;
  };
  setDisplay(-1, 0); setDisplay(1, 0);
  const moveNozzle = (n: Nozzle, worldPos: THREE.Vector3 | null, lookAtWorld?: THREE.Vector3) => {
    if (!worldPos) { n.obj.position.copy(n.home); n.obj.quaternion.copy(n.homeQ); }
    else {
      group.updateMatrixWorld(true);
      n.obj.position.copy(group.worldToLocal(worldPos.clone()));
      if (lookAtWorld) { n.obj.lookAt(lookAtWorld); }
    }
    rebuildHose(n);
  };
  return { group, nozzles, setDisplay, moveNozzle };
}

/** island furniture: crash bollards, bin with squeegee, extinguisher, signs */
export function islandExtras(parent: THREE.Object3D, x: number, z: number, len: number, reg: (m: THREE.Material) => void) {
  const stripe = once('stripe', () => {
    const t = cTex(64, 128, (c) => { for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? '#111' : '#f5c400'; c.fillRect(0, i * 16, 64, 16); } });
    return t;
  });
  const bm = mat({ map: stripe, rough: 0.5, key: 'bollard' });
  for (const s of [-1, 1]) {
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.0, 12), bm); b.position.set(x, 0.7, z + s * (len / 2 - 0.12)); parent.add(b);
    const top = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), bm); top.position.set(x, 1.2, z + s * (len / 2 - 0.12)); parent.add(top);
  }
  // bin + squeegee bucket
  const binM = mat({ color: 0x2a5a2a, rough: 0.5, key: 'ibin' });
  const bin = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.15, 0.7, 14), binM); bin.position.set(x + 0.42, 0.55, z); parent.add(bin);
  const bucket = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.11, 0.2, 12), mat({ color: 0x1a4aa8, rough: 0.5, key: 'ibucket' })); bucket.position.set(x + 0.42, 1.0, z); parent.add(bucket);
  const sq = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.5, 6), mat({ color: 0x777777, metal: 0.8, key: 'squeegee' })); sq.position.set(x + 0.45, 1.12, z + 0.04); sq.rotation.z = -0.25; parent.add(sq);
  // extinguisher on a stand
  const ext = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.35, 4, 10), mat({ color: 0xc8141f, rough: 0.35, metal: 0.2, key: 'ext' })); ext.position.set(x - 0.42, 0.65, z); parent.add(ext);
  const exth = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.08, 0.1), mat({ color: 0x222222, key: 'exth' })); exth.position.set(x - 0.42, 0.92, z); parent.add(exth);
  void reg;
}
