// Unified input state: touch controls (React) + keyboard/mouse (desktop testing)
export const input = {
  move: { x: 0, y: 0 }, // x: strafe (+right), y: forward (+)
  lookDX: 0,
  lookDY: 0,
  run: false,
  crouch: false,
  interact: false,
  use: false,
  flash: false,
  keys: new Set<string>(),
};

export function consumeLook() {
  const r = { x: input.lookDX, y: input.lookDY };
  input.lookDX = 0; input.lookDY = 0;
  return r;
}
export function consume(k: 'interact' | 'use' | 'flash') {
  const v = input[k];
  input[k] = false;
  return v;
}

let installed = false;
export function installDesktopInput(canvas: HTMLElement) {
  if (installed) return;
  installed = true;
  const upd = () => {
    const k = input.keys;
    const f = (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) - (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0);
    const s = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0);
    if (k.size > 0 || keyDriven) { input.move.x = s; input.move.y = f; keyDriven = f !== 0 || s !== 0; }
    input.run = k.has('ShiftLeft') || k.has('ShiftRight') || touchRun;
  };
  let keyDriven = false;
  window.addEventListener('keydown', (e) => {
    if (e.repeat) return;
    input.keys.add(e.code);
    if (e.code === 'KeyE') input.interact = true;
    if (e.code === 'KeyF') input.flash = true;
    if (e.code === 'KeyQ') input.use = true;
    if (e.code === 'KeyC' || e.code === 'ControlLeft') input.crouch = !input.crouch;
    upd();
  });
  window.addEventListener('keyup', (e) => { input.keys.delete(e.code); upd(); });
  canvas.addEventListener('click', () => {
    if (!('ontouchstart' in window) && document.pointerLockElement !== canvas) {
      canvas.requestPointerLock?.();
    }
  });
  window.addEventListener('mousemove', (e) => {
    if (document.pointerLockElement === canvas) {
      input.lookDX += e.movementX * 0.6;
      input.lookDY += e.movementY * 0.6;
    }
  });
}
let touchRun = false;
export function setTouchRun(v: boolean) { touchRun = v; input.run = v || input.keys.has('ShiftLeft'); }
