// The gas station: store, storage, staff room, toilet, office, basement, forecourt, road, back lot
import * as THREE from 'three';
import { Collision, NavGraph } from '../physics';
import { Builder, Door, LightGroup, boxGeo, setLayer, freezeStatic } from '../world';
import { mat, tex } from '../textures';
import type { Quality } from '../store';
import { art, type PosterKind } from '../art';
import { Humanoid } from '../characters';
import { ProductSet, gondola, fillRow, setProductDetail, fridgeBank, freezerChest, atm, toolWall, hotdogRoller, donutCase, slushie, wetFloorSign, posterMesh, buildCar, type PropsCtx, type CarModel } from '../props';
import type { Box } from '../physics';
import { buildDispenser, islandExtras, type Dispenser } from '../pumps';
import { docs } from '../docs';
import { coffeeMachine } from '../props';

export interface HideSpot { id: string; name: string; pos: THREE.Vector3; yaw: number; exit: THREE.Vector3; open: boolean }

export interface StationLevel {
  group: THREE.Group; dyn: THREE.Group; col: Collision; nav: NavGraph;
  doors: Record<string, Door>;
  lights: Record<string, LightGroup>;
  a: Record<string, THREE.Vector3>;
  items: Record<string, THREE.Object3D>;
  hide: HideSpot[];
  cams: { name: string; cam: THREE.PerspectiveCamera }[];
  messy: THREE.Mesh[];
  ghostCar: { group: THREE.Group; car: CarModel; spot: THREE.SpotLight };
  roller: ReturnType<typeof hotdogRoller>;
  donuts: ReturnType<typeof donutCase>;
  custCar: CarModel; custBox: Box; driver: Humanoid; playerCar: CarModel;
  setHorror: (level: number) => void;
  pumps: Dispenser[];
  decals: THREE.Mesh[];
  heart: THREE.Mesh;
  mists: THREE.Mesh[];
  fireGroup: THREE.Group;
  update: (dt: number, t: number) => void;
}

export function buildStation(scene: THREE.Scene, q: Quality): StationLevel {
  const group = new THREE.Group(); const dyn = new THREE.Group();
  scene.add(group); scene.add(dyn);
  const col = new Collision();
  const shadows = q === 'high';
  const B = new Builder(group, col, shadows);
  const lights: Record<string, LightGroup> = {};
  const lg = (n: string) => (lights[n] = lights[n] || new LightGroup(n));
  const prio = (p: number) => (q === 'low' ? p <= 1 : true);
  const a: Record<string, THREE.Vector3> = {};
  const items: Record<string, THREE.Object3D> = {};
  const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);

  // ---------- materials ----------
  const mAsphalt = mat({ map: tex.asphalt(), rough: 0.55, color: 0x9a9a9a, bump: true, key: 'asphalt' });
  const mConcrete = mat({ map: tex.concrete(), rough: 0.7, color: 0x9a9890, bump: true, key: 'concrete' });
  const mTiles = mat({ map: tex.tiles(), rough: 0.25, color: 0xcfcac0, key: 'tiles' });
  const mWall = mat({ map: tex.plaster('#c3bfae', 'w'), rough: 0.9, key: 'wall' });
  const mWallStaff = mat({ map: tex.plaster('#8f9a8a', 's'), rough: 0.9, key: 'wallstaff' });
  const mWallStorage = mat({ map: tex.plaster('#7a756a', 'st'), rough: 0.95, key: 'wallstor' });
  const mExterior = mat({ map: tex.plaster('#9c9486', 'e'), rough: 0.95, color: 0xb0aaa0, key: 'ext' });
  const mCeil = mat({ map: tex.ceiling(), rough: 1, key: 'ceil' });
  const mMetal = mat({ map: tex.metal(), metal: 0.7, rough: 0.45, key: 'metal' });
  const mDark = mat({ color: 0x1c1c1e, rough: 0.6, key: 'dark' });

  const mWood = mat({ map: tex.wood(), rough: 0.7, key: 'woodm' });
  const mCard = mat({ color: 0x9c7a4c, rough: 1, key: 'card' });
  const mGlass = new THREE.MeshStandardMaterial({ color: 0x8fa6b5, transparent: true, opacity: 0.16, roughness: 0.05, metalness: 0.6, depthWrite: false });
  const mDoor = mat({ color: 0x6a6f74, metal: 0.4, rough: 0.5, key: 'doorm' });
  const mDoorWood = mat({ map: tex.wood(), color: 0x8a6a50, rough: 0.7, key: 'doorwood' });
  const mGrass = mat({ map: tex.grass(), rough: 1, key: 'grass' });
  const mWhite = mat({ color: 0xdddddd, rough: 0.3, key: 'whiteporc' });

  // ---------- ground ----------
  const gTex = tex.asphalt();
  B.plane(0, 0, 0, 120, 100, mAsphalt).position.z = 4;
  void gTex;
  B.plane(0, 0.005, 15, 26, 14, mConcrete);
  B.plane(0, 0.004, -40, 160, 30, mGrass);
  const road = B.plane(0, 0.006, 32, 400, 8, mat({ map: tex.asphalt(), color: 0x6a6a6a, rough: 0.35, key: 'road' }));
  road.renderOrder = 0;
  for (let x = -190; x < 190; x += 8) B.box(x, 0.007, 32, 3.5, 0.005, 0.18, mat({ color: 0xcfc9a0, rough: 0.6, key: 'lane' }));
  B.box(0, 0.007, 28.2, 400, 0.005, 0.15, mat({ color: 0xbbbbbb, rough: 0.6, key: 'edge' }));
  // interior floors
  B.plane(0, 0.012, -0.5, 28, 9, mTiles);
  B.plane(-8, 0.012, -8.5, 12, 7, mConcrete);
  B.plane(0, 0.012, -8.5, 4, 7, mTiles);
  B.plane(8, 0.012, -6.75, 12, 3.5, mTiles);
  B.plane(8, 0.012, -10.25, 12, 3.5, mat({ map: tex.wood(), rough: 0.8, color: 0x7a6a5a, key: 'stafffloor' }));

  // ---------- building shell ----------
  const H = 3.2;
  // front wall with glass: base, top and pillars
  B.box(0, 0, 4, 28, 0.6, 0.25, mExterior, { collide: false });
  B.box(0, 2.6, 4, 28, 0.6, 0.25, mExterior);
  col.add(-14, -0.9, 3.88, 4.12, { sight: false }); col.add(0.9, 14, 3.88, 4.12, { sight: false });
  for (const x of [-14, -9.5, -5, -0.95, 0.95, 5, 9.5, 14]) B.box(x, 0, 4, 0.18, 2.6, 0.26, mDark);
  const glassL = new THREE.Mesh(new THREE.PlaneGeometry(13.1, 2.0), mGlass); glassL.position.set(-7.45, 1.6, 4.0); group.add(glassL);
  const glassR = glassL.clone(); glassR.position.x = 7.45; group.add(glassR);
  // front base box collisions (low wall below glass) handled by glass collider
  B.wallX(-12, -14, 14, H, mExterior, [[-10, 1.2]]);
  B.wallZ(-14, -12, 4, H, mExterior);
  B.wallZ(14, -12, 4, H, mExterior);
  // interior walls
  B.wallX(-5, -14, 14, H, mWall, [[-8, 1.2], [0, 1.6], [11, 1.2]]);
  B.wallZ(-2, -12, -5, H, mWallStorage);
  B.wallZ(2, -12, -5, H, mWallStaff, [[-6.8, 1.0], [-10.3, 1.0]]);
  B.wallX(-8.5, 2, 14, H, mWallStaff);
  B.wallZ(8, -8.5, -5, H, mWall);
  // ceilings & roof
  B.plane(0, H, -4, 28, 16, mCeil, Math.PI / 2);
  B.box(0, H, -4, 28.6, 0.4, 16.6, mExterior);
  // fascia sign above door
  const fascia = new THREE.Mesh(new THREE.BoxGeometry(10, 0.8, 0.1), new THREE.MeshStandardMaterial({ map: tex.sign('PETRO 24  •  MARKET', '#0d2a52', '#f4f4f4', 1024, 128, 'bold 64px Arial'), emissive: 0xffffff, emissiveMap: tex.sign('PETRO 24  •  MARKET', '#0d2a52', '#f4f4f4', 1024, 128, 'bold 64px Arial'), emissiveIntensity: 0.6 }));
  fascia.position.set(0, 3.3, 4.2); group.add(fascia); lg('sign').addMat(fascia.material as THREE.Material);

  // ---------- doors ----------
  const doors: Record<string, Door> = {};
  doors.front = new Door(dyn, col, { x: 0, z: 4, width: 1.8, axis: 'x', material: mGlass, glass: true, name: 'front', dir: -1, autoClose: true, locked: true });
  doors.storage = new Door(dyn, col, { x: -8, z: -5, width: 1.2, axis: 'x', material: mDoor, name: 'storage', dir: 1 });
  doors.toilet = new Door(dyn, col, { x: 2, z: -6.8, width: 1.0, axis: 'z', material: mDoorWood, name: 'toilet', dir: -1 });
  doors.staff = new Door(dyn, col, { x: 2, z: -10.3, width: 1.0, axis: 'z', material: mDoorWood, name: 'staff', dir: -1 });
  doors.office = new Door(dyn, col, { x: 11, z: -5, width: 1.2, axis: 'x', material: mDoorWood, name: 'office', dir: 1, locked: true });
  doors.back = new Door(dyn, col, { x: -10, z: -12, width: 1.2, axis: 'x', material: mDoor, name: 'back', dir: -1 });
  // signs on doors
  const signM = (t: string, bg: string) => mat({ map: tex.sign(t, bg, '#fff', 256, 96, 'bold 44px Arial'), key: 'sign' + t });
  void signM;
  // proper bilingual door plates (plane = full texture, the old box UVs cropped the text)
  const plate = (map: THREE.Texture, x: number, y: number, z: number, ry: number, w = 0.75) => {
    const p = new THREE.Mesh(new THREE.PlaneGeometry(w, w * 0.3125), new THREE.MeshStandardMaterial({ map, roughness: 0.35, metalness: 0.1 }));
    p.position.set(x, y, z); p.rotation.y = ry; group.add(p); return p;
  };
  plate(docs.plate('فقط کارکنان', 'STAFF ONLY', 'staff'), -8, 2.5, -4.885, 0);
  plate(docs.plate('سرویس بهداشتی', 'WC  •  STAFF', 'wc'), 0, 2.5, -4.885, 0);
  plate(docs.plate('مدیریت', 'MANAGER', 'manager'), 11, 2.5, -4.885, 0);
  plate(docs.plate('خروج اضطراری', 'EMERGENCY EXIT', 'exit'), -10, 2.5, -11.885, Math.PI, 0.7);
  plate(docs.plate('اتاق کارکنان', 'STAFF ROOM', 'staff'), 2.12, 2.4, -10.3, Math.PI / 2, 0.6);

  // ---------- SALES FLOOR (real 3D merchandise, instanced = few draw calls) ----------
  const pctx: PropsCtx = { parent: group, shadows, lowQ: q === 'low', reg: (m) => { lg('sales').addMat(m); } };
  setProductDetail(q === 'low');
  const ps = new ProductSet();
  // aisle 1: snacks (chips / puffs / chocolate / biscuits) – aisle 2: drinks & snacks mix
  gondola(pctx, ps, -6.5, -2.2, 7, [['bag', 'puff'], ['puff', 'bag'], ['bag', 'box'], ['candy', 'can']]);
  col.addCentered(-6.5, -2.2, 7, 0.94, { sight: true, maxY: 1.75 });
  gondola(pctx, ps, -6.5, 1.0, 7, [['can', 'bag'], ['box', 'puff'], ['puff', 'bag'], ['bottle', 'candy']]);
  col.addCentered(-6.5, 1.0, 7, 0.94, { sight: true, maxY: 1.75 });
  // endcaps facing the counter (the upper one on aisle 2 is the "restock" mission spot)
  const restock = new ProductSet();
  for (const ez of [-2.2, 1.0]) {
    B.box(-2.76, 0, ez, 0.45, 0.12, 0.9, mDark);
    B.box(-2.95, 0.12, ez, 0.06, 1.5, 0.9, mMetal);
    const hdr = new THREE.Mesh(new THREE.PlaneGeometry(0.86, 0.22), new THREE.MeshBasicMaterial({ map: art.sign(ez < 0 ? 'تخفیف ویژه' : 'چیپس و پفک', '#c41e1e', '#ffffff', 256, 64, 34) }));
    hdr.position.set(-2.52, 1.75, ez); hdr.rotation.y = Math.PI / 2; group.add(hdr); lg('sales').addMat(hdr.material as THREE.Material);
    [0.12, 0.55, 0.98].forEach((y, i) => {
      B.box(-2.76, y, ez, 0.45, 0.025, 0.9, mMetal);
      const kind = i === 0 ? 'jug' : i === 1 ? (ez < 0 ? 'bag' : 'puff') : (ez < 0 ? 'can' : 'bag');
      fillRow(ez > 0 && i >= 1 ? restock : ps, kind, 'z', ez - 0.43, ez + 0.43, y + 0.013, -2.55, 1, 2);
    });
    col.addCentered(-2.76, ez, 0.45, 0.9, { sight: false, maxY: 1.6 });
  }
  const restockGroup = new THREE.Group(); restock.build(restockGroup, shadows); dyn.add(restockGroup); items.restock = restockGroup;
  a.restock = new THREE.Vector3(-2.5, 1.0, 1.0);
  // chips carton in storage (restock mission)
  const carton = new THREE.Mesh(boxGeo(0.6, 0.42, 0.45, 1), new THREE.MeshStandardMaterial({ map: art.sign('چیپس و پفک • ۲۴ عدد', '#9c7a4c', '#3a2410', 256, 128, 24), roughness: 0.9 }));
  carton.position.set(-10.6, 0.21, -10.3); dyn.add(carton); items.chipsCarton = carton;
  // candy & gum rack near the counter
  B.box(1.3, 0, 1.2, 1.0, 0.75, 0.6, mDark, { collide: true, sight: false });
  [0.75, 0.9, 1.05].forEach((y, i) => { B.box(1.3, y - 0.01, 1.2 - 0.18 + i * 0.12, 1.0, 0.02, 0.2, mMetal); fillRow(ps, 'candy', 'x', 0.82, 1.78, y, 1.2 - 0.1 + i * 0.12, 1, 1); });
  // glass-door drink fridges along the left wall (bottles & cans are real meshes)
  fridgeBank(pctx, ps, -13.55, -4.05, 5);
  col.add(-14, -13.12, -4.1, 3.4);
  // ice cream freezer, ATM, tools & auto parts wall
  freezerChest(pctx, 11.4, -1.3); col.addCentered(11.4, -1.3, 1.5, 0.75, { sight: false, maxY: 2.1 });
  // a cool light inside the drink fridge bank so bottles & cans read clearly (medium/high)
  if (q !== 'low') { const fl = new THREE.PointLight(0xe8f4ff, 5, 4.5, 2); fl.position.set(-12.9, 1.7, -0.4); group.add(fl); lg('sales').add(fl); }
  atm(pctx, -11.6, 3.5, Math.PI); col.addCentered(-11.6, 3.5, 0.7, 0.6);
  const tw = toolWall(pctx, ps, 13.9, -4.6, -0.7); col.add(13.42, 14, -4.6, -0.7, { sight: false, maxY: 0.7 });
  items.wrench = tw.wrench; a.wrench = tw.wrench.position.clone();
  // >>> put every product batch into the scene (this call was missing = empty shelves/fridges)
  ps.build(group, shadows);
  // food machines on the counter
  const dctx: PropsCtx = { ...pctx, parent: dyn }; // animated props must not be frozen
  const roller = hotdogRoller(dctx, 3.75, 1.05, 0.85);
  const donuts = donutCase(dctx, 7.3, 1.05, 0.85);
  const slush = slushie(dctx, 13.3, 0.95, 1.75, -Math.PI / 2);
  a.roller = new THREE.Vector3(3.75, 1.35, 0.85); a.donuts = new THREE.Vector3(7.3, 1.3, 0.85);
  // security dome mirror + exit sign
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.35, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 1, roughness: 0.05 }));
  dome.position.set(-13.5, 2.8, -4.5); dome.rotation.set(Math.PI / 2 + 0.6, 0, -0.6); group.add(dome);
  const exitM = new THREE.MeshBasicMaterial({ map: art.sign('EXIT  خروج', '#0a5a2a', '#ffffff', 256, 64, 32) });
  const exitS = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.18), exitM); exitS.position.set(0, 2.45, 3.86); exitS.rotation.y = Math.PI; group.add(exitS);
  const wetSign = wetFloorSign(dyn, -11.0, 1.2); items.wetSign = wetSign;
  // counter
  B.box(5.5, 0, 0.8, 5, 1.0, 0.8, mWood, { collide: true, sight: false, cast: true });
  B.box(5.5, 1.0, 0.8, 5.1, 0.05, 0.9, mat({ color: 0x2b2b2b, rough: 0.3, key: 'countertop' }));
  const reg = B.box(5.5, 1.05, 0.75, 0.45, 0.25, 0.35, mDark); a.register = reg.position.clone();
  const regScreen = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.12), new THREE.MeshBasicMaterial({ color: 0x2a9a66 }));
  regScreen.position.set(5.5, 1.28, 0.56); regScreen.rotation.set(-0.5, Math.PI, 0, 'YXZ'); group.add(regScreen); lg('sales').addMat(regScreen.material as THREE.Material);
  B.box(5.5, 0, -1.6, 4, 2.0, 0.4, mat({ map: tex.products(4), rough: 0.6, key: 'cigs' }), { collide: true });
  // coffee machine
  B.box(13.3, 0, 2.2, 1.2, 0.95, 1.6, mWood, { collide: true, sight: false });
  coffeeMachine({ parent: group, shadows, lowQ: q === 'low', reg: (m) => { lg('sales').addMat(m); } }, 13.45, 0.95, 2.55, -Math.PI / 2);
  // trash can, mats
  B.cyl(1.2, 0, 3.2, 0.25, 0.8, mDark, 10, true);
  B.box(0, 0.013, 3.2, 1.6, 0.01, 1.0, mat({ color: 0x1a2a1a, rough: 1, key: 'doormat' }));
  // posters
  plate(art.sign('حراج ویژه  SALE', '#c41e1e', '#ffffff', 512, 160, 52), 12.6, 2.05, -4.885, 0, 1.1);
  plate(art.sign('بخت‌آزمایی  LOTTO', '#e0b000', '#222222', 512, 160, 50), 12.6, 1.55, -4.885, 0, 1.1);
  const openSign = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.4), new THREE.MeshBasicMaterial({ map: tex.sign('OPEN 24', '#000', '#ff2a3a', 256, 96, 'bold 60px Arial'), color: 0xffffff }));
  openSign.position.set(-3, 2.2, 3.9); openSign.rotation.y = Math.PI; group.add(openSign);
  const openSign2 = openSign.clone(); openSign2.rotation.y = 0; openSign2.position.z = 3.92; group.add(openSign2);
  lg('sign').addMat(openSign.material as THREE.Material);
  // ceiling panels + lights
  const panelM = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xeef4ff, emissiveIntensity: 1.6 });
  lg('sales').addMat(panelM);
  for (const x of [-10, -6, -2, 2, 6, 10]) for (const z of [-3, 1]) {
    const p = new THREE.Mesh(boxGeo(1.2, 0.05, 0.5, 1), panelM); p.position.set(x, H - 0.03, z); group.add(p);
  }
  const addPoint = (g: string, x: number, y: number, z: number, color: number, intensity: number, dist: number, p = 1) => {
    if (!prio(p)) return null;
    const l = new THREE.PointLight(color, intensity, dist, 2); l.position.set(x, y, z); group.add(l); lg(g).add(l); return l;
  };
  const sI = q === 'low' ? 16 : 11;
  if (q === 'low') { addPoint('sales', -6, 2.9, -0.5, 0xe8f0ff, sI, 14); addPoint('sales', 6, 2.9, -0.5, 0xe8f0ff, sI, 14); }
  else { addPoint('sales', -8, 2.9, -0.5, 0xe8f0ff, sI, 11); addPoint('sales', 0, 2.9, -0.5, 0xe8f0ff, sI, 11); addPoint('sales', 8, 2.9, -0.5, 0xe8f0ff, sI, 11); }

  // ---------- STORAGE ----------
  const rack = (x: number, z: number, len: number, along: 'x' | 'z') => {
    const w = along === 'x' ? len : 0.6, d = along === 'x' ? 0.6 : len;
    for (const y of [0.1, 0.8, 1.5, 2.2]) B.box(x, y, z, w, 0.05, d, mMetal);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) B.box(x + sx * (w / 2 - 0.03), 0, z + sz * (d / 2 - 0.03), 0.05, 2.3, 0.05, mMetal);
    col.addCentered(x, z, w, d, { sight: false, maxY: 2.3 });
    for (let i = 0; i < Math.floor(len / 0.7); i++) for (const y of [0.15, 0.85, 1.55]) {
      if (Math.random() < 0.3) continue;
      const bw = 0.4 + Math.random() * 0.2;
      const o = along === 'x' ? [x - len / 2 + 0.4 + i * 0.7, z] : [x, z - len / 2 + 0.4 + i * 0.7];
      B.box(o[0], y, o[1], bw, 0.35 + Math.random() * 0.25, 0.45, mCard);
    }
  };
  rack(-13.6, -8.5, 4.5, 'z'); rack(-8, -11.6, 5, 'x'); rack(-6.5, -8, 4, 'x');
  B.box(-4, 0, -11.3, 0.9, 0.85, 0.9, mCard, { collide: true, sight: false }); // crate with note
  B.box(-3.2, 0, -9, 0.8, 0.5, 0.6, mCard, { collide: true, sight: false });
  // storage cabinet (hide spot)
  B.box(-13.55, 0, -5.9, 0.8, 2.1, 1.0, mat({ color: 0x4a5560, metal: 0.5, rough: 0.5, key: 'cab' }), { collide: true });
  addPoint('storage', -8, 2.9, -8.5, 0xffe2b0, 7, 10);
  const bulbM = new THREE.MeshBasicMaterial({ color: 0xfff0c0 });
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), bulbM); bulb.position.set(-8, 2.95, -8.5); group.add(bulb); lg('storage').addMat(bulbM);

  // ---------- CORRIDOR / TOILET ----------
  addPoint('corridor', 0, 2.9, -8.5, 0xd8e8ff, 4, 7, 2);
  const cpM = new THREE.MeshBasicMaterial({ color: 0xe8f0ff }); lg('corridor').addMat(cpM);
  const cp = new THREE.Mesh(boxGeo(0.4, 0.04, 1.2, 1), cpM); cp.position.set(0, H - 0.03, -8.5); group.add(cp);
  B.box(7.5, 0.8, -5.4, 0.8, 0.15, 0.5, mWhite, { collide: true }); // sink
  B.box(7.5, 0, -5.4, 0.15, 0.8, 0.15, mWhite);
  const mirror = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.9), new THREE.MeshStandardMaterial({ color: 0x9aa4a8, metalness: 1, roughness: 0.05 }));
  mirror.position.set(7.5, 1.6, -5.12); mirror.rotation.y = Math.PI; group.add(mirror);
  // stall
  B.box(5.4, 0, -7.6, 0.06, 2.0, 1.8, mWallStaff, { collide: true });
  B.box(6.7, 0, -6.68, 1.3, 2.0, 0.06, mWallStaff, { collide: true });
  B.cyl(7.0, 0, -7.9, 0.22, 0.42, mWhite, 12, true);
  addPoint('toilet', 5, 2.9, -6.8, 0xeaffea, 4, 7, 2);
  const tbM = new THREE.MeshBasicMaterial({ color: 0xe0ffe0 }); lg('toilet').addMat(tbM);
  const tb = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), tbM); tb.position.set(5, 3.0, -6.8); group.add(tb);

  // ---------- STAFF ROOM ----------
  const lockerM = mat({ color: 0x3d5566, metal: 0.6, rough: 0.45, key: 'locker' });
  for (const x of [2.7, 3.5, 4.3]) {
    B.box(x, 0, -11.62, 0.75, 2.0, 0.65, lockerM, { collide: true });
    for (let k = 0; k < 4; k++) B.box(x, 1.55 + k * 0.06, -11.29, 0.4, 0.02, 0.01, mDark);
  }
  B.box(7, 0.75, -10.2, 1.8, 0.05, 1.0, mWood, { collide: false }); B.box(7, 0, -10.2, 1.6, 0.75, 0.8, mDark, { collide: true, sight: false });
  B.box(11.5, 0, -11.55, 3.5, 0.8, 0.8, mWood, { collide: true, sight: false });
  // monitors (CCTV)
  const monM = new THREE.MeshBasicMaterial({ color: 0x6f8f80 }); lg('staff').addMat(monM);
  for (const [x, y] of [[10.6, 1.0], [11.4, 1.0], [10.6, 1.45], [11.4, 1.45]]) {
    B.box(x, y - 0.02, -11.75, 0.72, 0.46, 0.3, mDark);
    const s = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.38), monM); s.position.set(x, y + 0.21, -11.59); group.add(s);
  }
  a.cctv = V(11, 1.2, -11.3);
  // breaker panel
  B.box(13.85, 1.0, -10, 0.12, 0.9, 0.6, mat({ color: 0x777b70, metal: 0.5, rough: 0.5, key: 'breaker' }));
  a.breaker = V(13.7, 1.4, -10);
  // bulletin board + note1
  B.box(6, 1.2, -8.66, 1.4, 0.9, 0.04, mat({ color: 0x8a6a40, rough: 1, key: 'cork' }));
  const paperM = mat({ color: 0xeeead8, rough: 1, key: 'paper' });
  // notice board: rules note (interactive), shift schedule, safety notice, staff photo, pins
  const docPlane = (map: THREE.Texture, x: number, y: number, z: number, w: number, h: number, ry = Math.PI, rz = 0, parent: THREE.Object3D = group) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({ map, roughness: 0.85 }));
    m.position.set(x, y, z); m.rotation.set(0, ry, rz); parent.add(m); return m;
  };
  const note1 = docPlane(docs.rules(), 6.35, 1.42, -8.69, 0.3, 0.4, Math.PI, 0.04, group); items.note1 = note1;
  docPlane(docs.schedule(), 5.75, 1.5, -8.69, 0.42, 0.3, Math.PI, -0.02);
  docPlane(docs.safety(), 6.0, 1.04, -8.69, 0.24, 0.32, Math.PI, 0.03);
  docPlane(docs.staffPhoto(), 5.55, 1.08, -8.69, 0.26, 0.2, Math.PI, -0.06);
  for (const [px, py] of [[6.35, 1.6], [5.75, 1.64], [6.0, 1.19], [5.55, 1.17]]) { const pin = new THREE.Mesh(new THREE.SphereGeometry(0.012, 6, 4), mat({ color: 0xd0141e, rough: 0.3, key: 'pin' })); pin.position.set(px, py, -8.7); group.add(pin); }
  void paperM;
  // phone
  const phone = B.box(12.6, 0.8, -11.5, 0.25, 0.1, 0.2, mat({ color: 0x8a1a1a, rough: 0.4, key: 'phone' })); items.phone = phone; a.phone = phone.position.clone();
  // lighter + key
  const lighter = B.box(7.2, 0.8, -10.1, 0.05, 0.08, 0.03, mat({ color: 0xd04020, metal: 0.5, rough: 0.3, key: 'lighter' }), { parent: dyn }); items.lighter = lighter;
  const key = B.box(12.2, 0.8, -11.3, 0.1, 0.02, 0.04, mat({ color: 0xd4b84a, metal: 1, rough: 0.3, key: 'keym' }), { parent: dyn }); items.key = key;
  addPoint('staff', 8, 2.9, -10.2, 0xf8f0d8, 6, 10);
  const sbM = new THREE.MeshBasicMaterial({ color: 0xfff6e0 }); lg('staff').addMat(sbM);
  const sb = new THREE.Mesh(boxGeo(1.2, 0.04, 0.4, 1), sbM); sb.position.set(8, H - 0.03, -10.2); group.add(sb);

  // ---------- OFFICE ----------
  B.box(12, 0, -6.3, 2.0, 0.78, 0.9, mWood, { collide: true, sight: false });
  // leather logbook: cover texture on top, page block on the sides
  const pageM = mat({ color: 0xeee6d0, rough: 0.9, key: 'pages' });
  const coverM = new THREE.MeshStandardMaterial({ map: docs.logbookCover(), roughness: 0.6 });
  const spineM = mat({ color: 0x2a0e08, rough: 0.7, key: 'spine' });
  const logbook = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.06, 0.25), [pageM, spineM, coverM, spineM, pageM, pageM]);
  logbook.position.set(12, 0.81, -6.3); logbook.rotation.y = 0.15; group.add(logbook); items.note3 = logbook;
  const pen = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.14, 6).rotateZ(Math.PI / 2), mat({ color: 0x111111, metal: 0.5, key: 'pen' })); pen.position.set(12.25, 0.79, -6.15); pen.rotation.y = 0.6; group.add(pen);
  docPlane(docs.envelope(), 11.65, 0.785, -6.45, 0.26, 0.16, 0, 0).rotation.set(-Math.PI / 2, 0, 0.3);
  B.box(13.6, 0, -8.0, 0.6, 1.4, 0.6, mat({ color: 0x555a50, metal: 0.4, key: 'filing' }), { collide: true });
  const hatch = B.box(9.8, 0.0, -7.2, 1.0, 0.03, 1.0, mat({ color: 0x3a3a35, metal: 0.6, rough: 0.6, key: 'hatch' })); items.hatch = hatch; a.hatch = V(9.8, 0.5, -7.2);
  addPoint('office', 12, 1.6, -6.3, 0xffb060, 3, 6, 2);
  const lampM = new THREE.MeshBasicMaterial({ color: 0xffc070 }); lg('office').addMat(lampM);
  const lamp = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.2, 10, 1, true), lampM); lamp.position.set(12.6, 1.15, -6.4); group.add(lamp);

  // ---------- BASEMENT (y = -6) ----------
  const BY = -6;
  const mBase = mat({ map: tex.concrete(), color: 0x5a524a, rough: 0.9, key: 'basewall' });
  B.plane(11.5, BY + 0.01, -8.5, 8, 9, mBase);
  B.plane(11.5, BY + 3.2, -8.5, 8, 9, mBase, Math.PI / 2);
  B.wallX(-13, 7.5, 15.5, 3.2, mBase, [], 0.3, BY); B.wallX(-4, 7.5, 15.5, 3.2, mBase, [], 0.3, BY);
  B.wallZ(7.5, -13, -4, 3.2, mBase, [], 0.3, BY); B.wallZ(15.5, -13, -4, 3.2, mBase, [], 0.3, BY);
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(1.7, 1.7, 2.6, 20, 1, true), new THREE.MeshStandardMaterial({ map: tex.metal(), color: 0x6a4a3a, metalness: 0.7, roughness: 0.6, side: THREE.DoubleSide }));
  tank.position.set(12.5, BY + 1.3, -10); group.add(tank);
  col.addCentered(12.5, -10, 3.2, 3.2, { minY: BY - 0.5, maxY: BY + 3 });
  const heart = new THREE.Mesh(new THREE.SphereGeometry(1.3, 24, 16), new THREE.MeshStandardMaterial({ color: 0x5a0d10, emissive: 0x400000, emissiveIntensity: 0.6, roughness: 0.3 }));
  heart.position.set(12.5, BY + 1.6, -10); group.add(heart);
  for (let i = 0; i < 8; i++) {
    const v = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 4, 5), mat({ color: 0x3a0606, rough: 0.4, key: 'vein' }));
    const ang = (i / 8) * Math.PI * 2; v.position.set(12.5 + Math.cos(ang) * 2, BY + 1.6, -10 + Math.sin(ang) * 2);
    v.rotation.z = Math.cos(ang) * 1.2; v.rotation.x = Math.sin(ang) * 1.2; group.add(v);
  }
  B.box(9.3, BY, -5.2, 1.4, 0.8, 0.7, mWood, { collide: true, minY: BY - 0.5, maxY: BY + 0.8 });
  const contract = docPlane(docs.contract(), 9.3, BY + 0.806, -5.2, 0.3, 0.41, 0, 0); contract.rotation.set(-Math.PI / 2, 0, Math.PI - 0.1); items.contract = contract;
  B.box(9.8, BY, -7.2, 0.5, 6, 0.06, mMetal); // ladder
  for (let i = 0; i < 12; i++) B.box(9.8, BY + 0.3 + i * 0.5, -7.15, 0.5, 0.04, 0.08, mMetal);
  a.ladder = V(9.8, BY + 0.5, -6.6); a.basementSpawn = V(10.3, BY, -6.4); a.officeSpawn = V(10.6, 0, -6.3);
  addPoint('basement', 11.5, BY + 2.6, -7, 0xff2a10, 6, 10);

  // ---------- FORECOURT ----------
  B.box(0, 5.0, 15, 22, 0.5, 9, mat({ color: 0xe8e8e8, rough: 0.6, key: 'canopy' }));
  B.box(0, 5.5, 15, 22.2, 0.6, 9.2, mat({ color: 0x0d3a6a, rough: 0.5, key: 'canopystripe' }));
  for (const x of [-9, 9]) for (const z of [12, 18]) B.box(x, 0, z, 0.4, 5, 0.4, mat({ color: 0xcfcfcf, rough: 0.5, key: 'pillar' }), { collide: true });
  const canM = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff4e0, emissiveIntensity: 2 }); lg('canopy').addMat(canM);
  for (const x of [-7, -2.5, 2.5, 7]) for (const z of [12.5, 17.5]) { const p = new THREE.Mesh(boxGeo(1.0, 0.04, 1.0, 1), canM); p.position.set(x, 4.73, z); group.add(p); }
  addPoint('canopy', 0, 4.4, 15, 0xfff0d8, 30, 20);
  // realistic dispensers (in the dynamic group so nozzles/hoses can move)
  const pumps: Dispenser[] = [];
  const regCanopy = (m: THREE.Material) => { lg('canopy').addMat(m); };
  const curbM = mat({ color: 0xf2c400, rough: 0.6, key: 'curbpaint' });
  [[-5, 15], [5, 15]].forEach(([x, z], i) => {
    B.box(x, 0, z, 1.3, 0.2, 5, mConcrete, { collide: true, sight: false });
    for (const sd of [-1, 1]) B.box(x + sd * 0.64, 0.0, z, 0.04, 0.205, 5.02, curbM); // painted curb edges
    for (const dz of [-1.2, 1.2]) pumps.push(buildDispenser(dyn, x, z + dz, regCanopy, shadows));
    islandExtras(dyn, x, z, 5, regCanopy);
    a['pump' + (i + 1)] = V(x + (i ? -1.2 : 1.2), 1, z);
  });
  // canopy pillar cladding + base guards
  for (const x of [-9, 9]) for (const z of [12, 18]) {
    B.box(x, 0, z, 0.5, 0.9, 0.5, mat({ color: 0xf2c400, rough: 0.6, key: 'pguard' }));
    B.box(x, 4.2, z, 0.46, 0.8, 0.46, mat({ color: 0x0d3a6a, rough: 0.5, key: 'pband' }));
  }
  // forecourt markings (parking/lane arrows)
  for (const [x, z] of [[-2.6, 15], [2.6, 15], [-7.4, 15], [7.4, 15]]) B.box(x, 0.008, z, 0.12, 0.004, 5.5, mat({ color: 0xe8e8e0, rough: 0.6, key: 'mark' }));
  B.box(-1.8, 0, 13, 0.5, 0.9, 0.5, mat({ color: 0x205a20, key: 'bin' }), { collide: true });
  // price sign pole
  B.cyl(18, 0, 25, 0.25, 8, mMetal, 10, true);
  const priceT = tex.sign('PETRO 24', '#0d3a6a', '#fff', 512, 256, 'bold 100px Arial');
  const priceM = new THREE.MeshStandardMaterial({ map: priceT, emissive: 0xffffff, emissiveMap: priceT, emissiveIntensity: 0.9 });
  const psign = new THREE.Mesh(new THREE.BoxGeometry(4, 2, 0.4), priceM); psign.position.set(18, 8.5, 25); group.add(psign); lg('sign').addMat(priceM);
  const pr2T = tex.sign('۲۴ ساعته   ۱۵۰۰۰', '#111', '#ff3030', 512, 128, 'bold 56px Tahoma');
  const pr2 = new THREE.MeshStandardMaterial({ map: pr2T, emissive: 0xffffff, emissiveMap: pr2T, emissiveIntensity: 1 });
  const pp = new THREE.Mesh(new THREE.BoxGeometry(4, 0.9, 0.35), pr2); pp.position.set(18, 7, 25); group.add(pp); lg('sign').addMat(pr2);

  // ---------- STREET LIGHTS ----------
  const coneM = new THREE.MeshBasicMaterial({ map: tex.cone(), color: 0xffc890, transparent: true, opacity: q === 'low' ? 0.05 : 0.09, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
  const bulbStreet = new THREE.MeshBasicMaterial({ color: 0xffd8a0 });
  for (const x of [-75, -45, -15, 15, 45, 75]) {
    B.cyl(x, 0, 26.6, 0.12, 7, mMetal, 8, true);
    B.box(x, 6.9, 27.4, 0.2, 0.15, 1.6, mMetal);
    const bl = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 6), bulbStreet); bl.position.set(x, 6.8, 28.1); group.add(bl);
    const cone = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 3.2, 6.8, 16, 1, true), coneM); cone.position.set(x, 3.4, 28.1); group.add(cone);
  }
  addPoint('street', -15, 6.5, 28.5, 0xffc080, 26, 22, 2);
  addPoint('street', 15, 6.5, 28.5, 0xffc080, 26, 22, 2);
  const canopyCone = new THREE.Mesh(new THREE.CylinderGeometry(4, 6, 4.6, 16, 1, true), coneM.clone());
  (canopyCone.material as THREE.MeshBasicMaterial).opacity = 0.04; canopyCone.position.set(0, 2.4, 15); group.add(canopyCone); lg('canopy').addObj(canopyCone);

  // ---------- BACK LOT ----------
  B.box(-7, 0, -17, 2.4, 1.3, 1.4, mat({ color: 0x1f4a2a, metal: 0.5, rough: 0.6, key: 'dumpster' }), { collide: true, cast: true });
  B.box(-7, 1.3, -17, 2.5, 0.08, 1.5, mDark);
  a.dumpster = V(-7, 1, -15.9);
  B.box(8, 0, -16, 1.6, 1.1, 1.0, mat({ color: 0xa08a20, metal: 0.4, rough: 0.6, key: 'gen' }), { collide: true, cast: true });
  B.box(8, 1.1, -16, 0.3, 0.6, 0.3, mDark);
  a.generator = V(8, 1, -15.1);
  const backLampM = new THREE.MeshBasicMaterial({ color: 0xffd090 });
  const bl = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), backLampM); bl.position.set(-10, 2.7, -12.3); group.add(bl);
  lg('back').addMat(backLampM); addPoint('back', -10, 2.6, -12.8, 0xffb070, 5, 12);
  lights.back.unstable = 0.06;
  // pallets, barrels
  for (let i = 0; i < 3; i++) B.cyl(-12 + i * 0.7, 0, -14, 0.3, 0.9, mat({ color: 0x5a2a1a, metal: 0.4, rough: 0.7, key: 'barrel' }), 10, true);
  B.box(3, 0, -15, 1.2, 0.15, 1.0, mWood, { collide: false });
  // fence
  const fenceM = mat({ color: 0x3a3a3a, metal: 0.6, rough: 0.6, key: 'fence' });
  for (let x = -40; x <= 40; x += 4) B.box(x, 0, -30, 0.08, 2.2, 0.08, fenceM);
  B.box(0, 2.1, -30, 80, 0.05, 0.05, fenceM); B.box(0, 1.0, -30, 80, 0.05, 0.05, fenceM);
  col.add(-60, 60, -30.2, -29.8); col.add(-40.2, -39.8, -30, 40); col.add(39.8, 40.2, -30, 40); col.add(-60, 60, 39.8, 40.2, { sight: false });
  // trees
  const trunkM = mat({ color: 0x1a120c, rough: 1, key: 'trunk' }), leafM = mat({ color: 0x0c140c, rough: 1, key: 'leaf' });
  const treeG = new THREE.ConeGeometry(2.2, 6, 7); const trunkG = new THREE.CylinderGeometry(0.2, 0.3, 3, 6);
  const addTree = (x: number, z: number, s: number) => {
    const t = new THREE.Mesh(trunkG, trunkM); t.position.set(x, 1.5 * s, z); t.scale.setScalar(s); group.add(t);
    const l = new THREE.Mesh(treeG, leafM); l.position.set(x, 5 * s, z); l.scale.setScalar(s); group.add(l);
  };
  for (let i = 0; i < 40; i++) addTree(-70 + Math.random() * 140, -33 - Math.random() * 25, 0.8 + Math.random() * 0.8);
  for (let i = 0; i < 26; i++) addTree(-80 + Math.random() * 160, 44 + Math.random() * 30, 0.8 + Math.random() * 0.8);
  for (let i = 0; i < 8; i++) addTree(-44 - Math.random() * 10, -25 + Math.random() * 50, 1 + Math.random() * 0.5);
  // distant buildings with one lit window
  for (let i = 0; i < 5; i++) {
    const x = -90 + i * 45 + Math.random() * 10;
    B.box(x, 0, 70 + Math.random() * 10, 10, 6 + Math.random() * 8, 8, mat({ color: 0x15161a, key: 'farbld' }));
    if (Math.random() < 0.6) { const w = new THREE.Mesh(new THREE.PlaneGeometry(1, 1.2), new THREE.MeshBasicMaterial({ color: 0xffc070 })); w.position.set(x + 2, 3, 65.9); w.rotation.y = 0; group.add(w); }
  }
  // building outer walls - side sidewalks
  B.box(0, 0, 5.2, 30, 0.12, 2.2, mConcrete);

  // ---------- CARS ----------
  const car = (x: number, z: number, color: number, rotY: number, parent: THREE.Object3D, flyer = false) => {
    const cm = buildCar(color, shadows, { dirt: true, flyer });
    cm.group.position.set(x, 0, z); cm.group.rotation.y = rotY; parent.add(cm.group);
    const c = Math.cos(rotY), s = Math.sin(rotY);
    const hw = Math.abs(c) * 0.95 + Math.abs(s) * 2.3, hd = Math.abs(s) * 0.95 + Math.abs(c) * 2.3;
    col.add(x - hw, x + hw, z - hd, z + hd, { sight: false, maxY: 1.5 });
    return cm;
  };
  const playerCar = car(-20, 8, 0x4a5a6a, 0, dyn, true); a.playerCar = V(-18.7, 1, 8);
  items.flyer = playerCar.flyer!; a.flyer = V(-20.3, 1.15, 8.9);
  const gc = car(22, 2, 0x1e1e20, Math.PI, dyn);
  // customer car (drives in for the fueling job) – no static collider, a dynamic one is toggled by the story
  const custCar = buildCar(0x7a1414, shadows, { dirt: true }); custCar.group.visible = false; dyn.add(custCar.group);
  const custBox = col.add(-3.55, -1.65, 12.7, 17.3, { sight: false, maxY: 1.5, enabled: false });
  const driver = new Humanoid({ skin: 0xc49a7c, shirt: 0x2a2a2a, pants: 0x222233, hairStyle: 'short' });
  driver.lLeg.rotation.x = -1.4; driver.rLeg.rotation.x = -1.4; driver.lKnee.rotation.x = 1.45; driver.rKnee.rotation.x = 1.45; driver.lArm.rotation.x = -1.1; driver.rArm.rotation.x = -1.1; driver.lArmOverride = driver.rArmOverride = true;
  driver.root.position.set(-0.38, -0.2, -0.15); custCar.group.add(driver.root);

  // ---------- HORROR POSTERS ----------
  const posters: { mesh: THREE.Mesh; kind: PosterKind; v: number; min: number }[] = [];
  const P = (kind: PosterKind, v: number, x: number, y: number, z: number, ry: number, w = 0.42, min = 0) => {
    const m = posterMesh(dyn, art.poster(kind, v), x, y, z, ry, w, (Math.random() - 0.5) * 0.08);
    posters.push({ mesh: m, kind, v, min }); return m;
  };
  // inside front windows (missing people), outside face (job ad)
  P('missing', 0, -12, 1.55, 3.92, Math.PI); P('missing', 1, -7.9, 1.5, 3.92, Math.PI); P('missing', 2, 3.3, 1.55, 3.92, Math.PI); P('missing', 3, 10.6, 1.5, 3.92, Math.PI);
  P('hiring', 0, 5.9, 1.55, 4.15, 0, 0.5); P('missing', 4, -4.1, 1.5, 4.15, 0); P('dog', 0, -9.4, 1.55, 4.15, 0);
  // interior walls
  P('rules', 0, -4.4, 1.65, -4.88, 0, 0.5); P('dontlook', 0, 3.0, 1.65, -4.88, 0, 0.45, 1); P('missing', 5, 8.6, 1.6, -4.88, 0); P('smile', 0, -13.85, 1.3, -4.6 + 8.2, Math.PI / 2, 0.5, 2);
  // storage / corridor / staff
  P('dog', 1, -11.2, 1.6, -5.12, Math.PI); P('missing', 1, -4.5, 1.6, -5.12, Math.PI, 0.42, 1); P('smile', 0, -1.88, 1.6, -9.2, Math.PI / 2, 0.45, 1);
  P('missing', 2, 4.6, 1.55, -8.62, Math.PI); P('missing', 0, 7.4, 1.55, -8.62, Math.PI, 0.42, 1); P('tall', 0, 9.2, 1.55, -8.62, Math.PI, 0.45);
  // back of the building
  P('missing', 3, -6, 1.6, -12.12, Math.PI); P('tall', 0, -0.5, 1.6, -12.12, Math.PI, 0.5); P('missing', 4, 3, 1.55, -12.12, Math.PI); P('dontlook', 0, -12.2, 1.55, -12.12, Math.PI, 0.45);
  P('missing', 5, 5.5, 1.6, -12.12, Math.PI, 0.42, 2); P('missing', 2, -3.2, 1.5, -12.12, Math.PI, 0.42, 2);
  // canopy pillars & street poles
  P('missing', 0, 9, 1.6, 12.21, 0); P('missing', 1, -9, 1.6, 17.79, Math.PI); P('dog', 0, -9, 1.6, 12.21, 0); P('missing', 3, 15, 1.7, 26.47, Math.PI); P('tall', 0, -15, 1.7, 26.47, Math.PI, 0.45);
  // the newest one... the player
  P('missingMe', 0, 2.2, 1.5, 3.92, Math.PI, 0.42, 3); P('missingMe', 0, 9, 1.6, 17.79, Math.PI, 0.42, 3);
  // blood handprints & mirror scrawl (late chapters)
  const decals: THREE.Mesh[] = [];
  for (const hx of [-6.2, 7.4]) { const d = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.2), new THREE.MeshBasicMaterial({ map: art.handprints(), transparent: true, depthWrite: false })); d.position.set(hx, 1.5, 3.96); d.rotation.y = Math.PI; dyn.add(d); decals.push(d); }
  const scrawl = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.4), new THREE.MeshBasicMaterial({ map: art.scrawl('پشت سرت'), transparent: true, depthWrite: false }));
  scrawl.position.set(7.5, 1.6, -5.11); scrawl.rotation.y = Math.PI; dyn.add(scrawl); decals.push(scrawl);
  const setHorror = (level: number) => {
    posters.forEach((p) => {
      p.mesh.visible = level >= p.min;
      (p.mesh.material as THREE.MeshStandardMaterial).map = art.poster(p.kind, p.v, level >= 2 && (p.kind === 'missing' || p.kind === 'dog'));
    });
    decals.forEach((d) => (d.visible = level >= 2));
  };
  const spot = new THREE.SpotLight(0xfff2d8, 0, 30, 0.5, 0.5, 1.5); spot.position.set(22, 0.8, 0); spot.target.position.set(22, 0, -10);
  dyn.add(spot); dyn.add(spot.target);
  a.ghostCar = V(22, 1, 2);

  // ---------- pickups ----------
  const sodaBox = B.box(-5.5, 0, -9.6, 0.5, 0.35, 0.4, mat({ color: 0xb02020, rough: 0.8, key: 'sodabox' }), { parent: dyn }); items.soda = sodaBox;
  const mop = new THREE.Group(); mop.position.set(-2.4, 0, -5.6); dyn.add(mop);
  const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.5, 6), mat({ color: 0xc0c0c0, metal: 0.8, key: 'mopstick' })); stick.position.y = 0.8; stick.rotation.z = 0.2; mop.add(stick);
  const mh = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.08, 0.2, 8), mat({ color: 0xd8d0b0, key: 'mophead' })); mh.position.set(0.15, 0.1, 0); mop.add(mh);
  const bucket = B.cyl(-2.8, 0, -5.8, 0.2, 0.35, mat({ color: 0xe0b020, key: 'bucket' })); void bucket;
  items.mop = mop;
  const fuel = B.box(-12.6, 0, -7.0, 0.35, 0.45, 0.2, mat({ color: 0xc81e1e, rough: 0.4, key: 'fuel' }), { parent: dyn }); items.fuel = fuel;
  const note2 = docPlane(docs.crumpled(), -4, 0.857, -11.3, 0.25, 0.32, 0, 0, dyn); note2.rotation.set(-Math.PI / 2, 0, 0.4); items.note2 = note2;
  const trash = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 6), mat({ color: 0x111111, rough: 0.3, key: 'trashbag' }));
  trash.scale.set(1, 1.3, 1); trash.position.set(8.8, 0.36, -0.6); dyn.add(trash); items.trash = trash;
  const order = B.box(4.2, 1.05, 0.8, 0.35, 0.3, 0.2, mat({ color: 0xc8b090, rough: 1, key: 'orderbag' }), { parent: dyn }); items.order = order;
  const spill = new THREE.Mesh(new THREE.CircleGeometry(0.8, 16), new THREE.MeshStandardMaterial({ color: 0x3a2a10, roughness: 0.05, metalness: 0.2, transparent: true, opacity: 0.85 }));
  spill.rotation.x = -Math.PI / 2; spill.position.set(-11.6, 0.02, 2.0); spill.scale.set(1, 0.7, 1); dyn.add(spill); items.spill = spill;
  // messy items on shelves
  const messy: THREE.Mesh[] = [];
  const messM = mat({ color: 0xe8a020, rough: 0.6, key: 'messy' });
  [[-8.5, 0.0, -1.62], [-4.5, 0.0, 1.58], [-10.4, 0.0, 0.2]].forEach(([x, , z]) => {
    const m = new THREE.Mesh(boxGeo(0.3, 0.2, 0.15, 1), messM); m.position.set(x, 0.12, z); m.rotation.set(0, Math.random(), Math.PI / 2); dyn.add(m); messy.push(m);
  });
  const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.045, 0.28, 8), new THREE.MeshStandardMaterial({ color: 0x2a7a3a, transparent: true, opacity: 0.8, roughness: 0.1 }));
  bottle.position.set(1.62, 1.2, 1.26); dyn.add(bottle); items.bottle = bottle;

  // ---------- CCTV ----------
  const camModelM = mat({ color: 0xdddddd, rough: 0.5, key: 'cammodel' });
  const mkCam = (name: string, p: THREE.Vector3, t: THREE.Vector3) => {
    const c = new THREE.PerspectiveCamera(75, 16 / 9, 0.1, 80); c.position.copy(p); c.lookAt(t);
    c.layers.enable(0); c.layers.enable(2); c.layers.disable(1);
    const m = new THREE.Mesh(boxGeo(0.15, 0.15, 0.3, 1), camModelM); m.position.copy(p); m.lookAt(t); group.add(m);
    return { name, cam: c };
  };
  const cams = [
    mkCam('CAM 01  فروشگاه', V(-13.6, 3.0, 3.6), V(2, 0.5, -3)),
    mkCam('CAM 02  صندوق', V(13.6, 3.0, -4.6), V(4, 0.8, 2)),
    mkCam('CAM 03  انبار', V(-2.3, 3.0, -5.3), V(-12, 0.3, -11)),
    mkCam('CAM 04  جایگاه سوخت', V(13.8, 4.6, 4.4), V(-4, 0, 17)),
    mkCam('CAM 05  پشت ساختمان', V(-13.8, 3.1, -12.4), V(4, 0, -24)),
  ];

  // ---------- hide spots ----------
  const hide: HideSpot[] = [
    { id: 'locker1', name: 'کمد', pos: V(2.7, 1.55, -11.6), yaw: Math.PI, exit: V(2.7, 0, -10.7), open: false },
    { id: 'locker2', name: 'کمد', pos: V(3.5, 1.55, -11.6), yaw: Math.PI, exit: V(3.5, 0, -10.7), open: false },
    { id: 'stall', name: 'توالت', pos: V(6.9, 1.4, -7.7), yaw: Math.PI, exit: V(6.4, 0, -6.1), open: false },
    { id: 'cabinet', name: 'کابینت انبار', pos: V(-13.55, 1.5, -5.9), yaw: -Math.PI / 2, exit: V(-12.6, 0, -6.1), open: false },
    { id: 'counter', name: 'زیر پیشخوان', pos: V(6.8, 0.55, 0.0), yaw: Math.PI, exit: V(6.8, 0, -0.5), open: true },
  ];
  a.frontOut = V(0, 0, 6); a.frontIn = V(0, 0, 2.6); a.queue = V(5.5, 0, 2.0); a.cashier = V(5.5, 0, -0.75);
  a.spawnPlayer = V(-17.5, 0, 9.5); a.fridge = V(-12.8, 1.2, -1); a.coffee = V(12.6, 1, 2.4);
  a.roadL = V(-120, 0, 30); a.roadR = V(120, 0, 34);

  // ---------- nav graph ----------
  const nav = new NavGraph();
  const pts: [number, number, string?][] = [
    // outside
    [0, 6, 'doorOut'], [-6, 7], [6, 7], [-16, 7], [16, 7], [-18, 0], [18, 0], [-18, -8], [18, -8], [-17, -16], [17, -16], [0, -18], [-10, -14, 'backOut'], [8, -14],
    [-7, 15], [7, 15, 'pump2side'], [0, 15], [0, 24, 'roadside'], [-22, 24], [22, 24], [-22, -24], [22, -24], [0, -25, 'backFar'], [-14, 12], [14, 12], [-25, 10], [25, 8],
    // store
    [0, 2.6, 'doorIn'], [-11, 2.7], [-6, 2.7], [-2, 2.7], [2.5, 2.6], [9.5, 2.6], [12, 2.6], [-11, -0.6], [-6, -0.6, 'aisle'], [-2, -0.6], [-11, -3.8], [-6, -3.8], [-3.5, -4.2], [0.5, -4.2],
    [5.5, 2.1, 'queue'], [9.5, -0.5], [9.5, -3.4], [11, -4.2], [5.5, -0.4, 'cashier'], [2.4, -0.4],
    [-8, -4.3], [-8, -5.8], [-12, -7], [-4.5, -7], [-4.5, -10.3], [-10, -10.6], [-10, -11.3, 'backIn'], [-10, -12.9],
    [0, -5.8], [0, -8.5], [0, -10.3], [0, -11.4], [1.3, -6.8], [2.7, -6.8], [4.6, -6.8, 'toilet'], [1.3, -10.3], [2.8, -10.3], [6, -9.5, 'staff'], [11, -10.0], [4, -10.5],
    [11, -5.8], [11, -7, 'office'],
  ];
  pts.forEach(([x, z, t]) => nav.add(x, z, 0, t));
  nav.build(col);

  // ---------- mist (volumetric fake) ----------
  const mists: THREE.Mesh[] = [];
  if (q !== 'low') {
    const mm = new THREE.MeshBasicMaterial({ map: tex.mist(), transparent: true, opacity: 0.55, depthWrite: false, color: 0x8090a0 });
    // ground mist strips placed strictly OUTSIDE the building footprint (x -14.3..14.3, z -12.3..4.3)
    const strips: [number, number, number, number, number][] = [
      // cx, cz, w, d, y
      [0, 24, 90, 36, 0.35], [0, 26, 90, 30, 0.8], // front lot + road
      [0, -32, 90, 36, 0.4], [0, -30, 90, 30, 0.85], // back lot
      [-30, -4, 30, 17, 0.45], [30, -4, 30, 17, 0.5], // sides
    ];
    strips.forEach(([cx, cz, w, d, y], i) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), mm.clone());
      const mp = tex.mist().clone(); mp.repeat.set(w / 30, d / 30); mp.needsUpdate = true;
      (m.material as THREE.MeshBasicMaterial).map = mp;
      if (i % 2) (m.material as THREE.MeshBasicMaterial).opacity = 0.35;
      m.rotation.x = -Math.PI / 2; m.position.set(cx, y, cz);
      group.add(m); mists.push(m);
    });
  }

  const fireGroup = new THREE.Group(); scene.add(fireGroup);

  // layers: static -> layer 0 (visible to both)
  setLayer(group, 0);
  freezeStatic(group);

  let ht = 0;
  const update = (dt: number, t: number) => {
    Object.values(doors).forEach((d) => d.update(dt));
    Object.values(lights).forEach((l) => l.update(dt, t));
    ht += dt;
    const beat = 1 + Math.max(0, Math.sin(ht * 4)) * 0.06 + Math.sin(ht * 1.3) * 0.02;
    heart.scale.setScalar(beat); heart.updateMatrix();
    mists.forEach((m, i) => { const mp = (m.material as THREE.MeshBasicMaterial).map!; mp.offset.x = t * 0.004 * (i % 2 ? 1 : -1); mp.offset.y = t * 0.002; });
  };

  return {
    group, dyn, col, nav, doors, lights, a, items, hide, cams, messy, ghostCar: { group: gc.group, car: gc, spot }, heart, mists, fireGroup,
    roller, donuts, custCar, custBox, driver, playerCar, setHorror, pumps, decals,
    update: (dt: number, t: number) => { update(dt, t); roller.update(dt); slush.update(dt); },
  };
}
