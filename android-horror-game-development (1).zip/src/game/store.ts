// Shared UI state store + settings + save system (bridge between engine and React)
export type Quality = 'low' | 'medium' | 'high';

export interface Settings {
  quality: Quality;
  sensitivity: number; // 0.2 .. 2
  master: number; // 0..1
  music: number;
  sfx: number;
  fov: number; // 55..100
  btnScale: number; // 0.7..1.4
  btnOpacity: number; // 0.2..1
  leftHanded: boolean;
  invertY: boolean;
  showFps: boolean;
}

export const defaultSettings: Settings = {
  quality: 'medium',
  sensitivity: 1,
  master: 0.9,
  music: 0.7,
  sfx: 0.9,
  fov: 72,
  btnScale: 1,
  btnOpacity: 0.65,
  leftHanded: false,
  invertY: false,
  showFps: false,
};

export interface DialogueOption { id: string; text: string }

export interface SaveData {
  chapter: number;
  task: number;
  flags: Record<string, boolean>;
  item: string | null;
  violations: number;
  notes: number[];
  deaths: number;
  hasLighter: boolean;
  savedAt: number;
}

export interface UIState {
  screen: 'menu' | 'loading' | 'game' | 'ending';
  paused: boolean;
  prompt: string | null;
  objective: string | null;
  objectiveFlash: number;
  subtitle: { speaker?: string; text: string } | null;
  message: string | null;
  chapterCard: { title: string; sub: string } | null;
  title: boolean;
  fade: number;
  loading: { text: string; progress: number; tip: string } | null;
  dialogue: { speaker: string; text: string; options: DialogueOption[] } | null;
  cctv: { cam: number; name: string; glitch: boolean } | null;
  note: { title: string; body: string } | null;
  clock: string;
  stamina: number;
  item: string | null;
  flashlight: boolean;
  hiding: boolean;
  chase: boolean;
  dead: boolean;
  ending: { id: string; title: string; text: string; stats: string } | null;
  cutscene: boolean;
  skippable: boolean;
  jumpscare: number; // 0 none, else variant id
  fps: number;
  toast: string | null;
  saving: boolean;
  driving: boolean;
}

const initial: UIState = {
  screen: 'menu', paused: false, prompt: null, objective: null, objectiveFlash: 0, subtitle: null,
  message: null, chapterCard: null, title: false, fade: 0, loading: null, dialogue: null, cctv: null,
  note: null, clock: '02:00', stamina: 1, item: null, flashlight: false, hiding: false, chase: false,
  dead: false, ending: null, cutscene: false, skippable: false, jumpscare: 0, fps: 0, toast: null,
  saving: false, driving: false,
};

let state: UIState = { ...initial };
const listeners = new Set<() => void>();

export const ui = {
  get: () => state,
  set(p: Partial<UIState>) {
    let changed = false;
    for (const k in p) {
      if ((state as any)[k] !== (p as any)[k]) { changed = true; break; }
    }
    if (!changed) return;
    state = { ...state, ...p };
    listeners.forEach((l) => l());
  },
  reset() { state = { ...initial }; listeners.forEach((l) => l()); },
  subscribe(l: () => void) { listeners.add(l); return () => { listeners.delete(l); }; },
};

// ---------------- Settings ----------------
const SETTINGS_KEY = 'nightshift_settings_v1';
const SAVE_KEY = 'nightshift_save_v1';
const ENDINGS_KEY = 'nightshift_endings_v1';

let settings: Settings = loadSettings();
const settingsListeners = new Set<() => void>();

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...defaultSettings, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  // pick sensible default quality for device
  const s = { ...defaultSettings };
  const mem = (navigator as any).deviceMemory as number | undefined;
  if (mem && mem <= 3) s.quality = 'low';
  return s;
}

export const settingsStore = {
  get: () => settings,
  set(p: Partial<Settings>) {
    settings = { ...settings, ...p };
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch { /* ignore */ }
    settingsListeners.forEach((l) => l());
  },
  subscribe(l: () => void) { settingsListeners.add(l); return () => { settingsListeners.delete(l); }; },
};

// ---------------- Save ----------------
export function newSave(): SaveData {
  return { chapter: 1, task: 0, flags: {}, item: null, violations: 0, notes: [], deaths: 0, hasLighter: false, savedAt: Date.now() };
}
export function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    return { ...newSave(), ...JSON.parse(raw) };
  } catch { return null; }
}
export function writeSave(d: SaveData) {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify({ ...d, savedAt: Date.now() })); } catch { /* ignore */ }
}
export function clearSave() { try { localStorage.removeItem(SAVE_KEY); } catch { /* ignore */ } }

export function getEndings(): string[] {
  try { return JSON.parse(localStorage.getItem(ENDINGS_KEY) || '[]'); } catch { return []; }
}
export function unlockEnding(id: string) {
  const e = getEndings();
  if (!e.includes(id)) { e.push(id); try { localStorage.setItem(ENDINGS_KEY, JSON.stringify(e)); } catch { /* ignore */ } }
}
