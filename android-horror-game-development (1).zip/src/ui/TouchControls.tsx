import { useRef, useState, useSyncExternalStore } from 'react';
import { input, setTouchRun } from '../game/input';
import { settingsStore, ui } from '../game/store';
import { ITEM_NAMES } from '../game/story';

const isTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);

export function TouchControls({ onPause }: { onPause: () => void }) {
  const s = useSyncExternalStore(settingsStore.subscribe, settingsStore.get);
  const st = useSyncExternalStore(ui.subscribe, ui.get);
  const [joy, setJoy] = useState<{ x: number; y: number; kx: number; ky: number } | null>(null);
  const joyId = useRef<number | null>(null);
  const lookId = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });
  const [crouch, setCrouch] = useState(input.crouch);
  const [running, setRunning] = useState(false);
  const R = 60 * s.btnScale;
  const left = !s.leftHanded;

  const onDown = (e: React.PointerEvent) => {
    const w = window.innerWidth;
    const isMoveSide = left ? e.clientX < w * 0.42 : e.clientX > w * 0.58;
    if (isMoveSide && joyId.current === null) {
      joyId.current = e.pointerId;
      setJoy({ x: e.clientX, y: e.clientY, kx: 0, ky: 0 });
    } else if (lookId.current === null) {
      lookId.current = e.pointerId; lookLast.current = { x: e.clientX, y: e.clientY };
    }
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };
  const onMove = (e: React.PointerEvent) => {
    if (e.pointerId === joyId.current && joy) {
      let dx = e.clientX - joy.x, dy = e.clientY - joy.y;
      const d = Math.hypot(dx, dy);
      if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
      setJoy({ ...joy, kx: dx, ky: dy });
      input.move.x = dx / R; input.move.y = -dy / R;
    } else if (e.pointerId === lookId.current) {
      input.lookDX += (e.clientX - lookLast.current.x) * 1.25;
      input.lookDY += (e.clientY - lookLast.current.y) * 1.25;
      lookLast.current = { x: e.clientX, y: e.clientY };
    }
  };
  const onUp = (e: React.PointerEvent) => {
    if (e.pointerId === joyId.current) { joyId.current = null; setJoy(null); input.move.x = 0; input.move.y = 0; }
    if (e.pointerId === lookId.current) lookId.current = null;
  };

  const hidden = st.cutscene || !!st.dialogue || !!st.note || !!st.cctv || st.dead;
  const size = (n: number) => n * s.btnScale;
  const btn = 'absolute rounded-full flex flex-col items-center justify-center text-white border border-white/25 backdrop-blur-sm active:scale-95 transition-transform select-none';
  const stop = (e: React.PointerEvent) => e.stopPropagation();
  const side = left ? { right: 0 } : { left: 0 };
  const pos = (r: number, b: number) => (left ? { right: r, bottom: b } : { left: r, bottom: b });

  return (
    <div className="fixed inset-0 z-10" style={{ touchAction: 'none' }} onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
      {/* pause */}
      <button onPointerDown={(e) => { e.stopPropagation(); onPause(); }} className="absolute top-3 left-3 w-11 h-11 rounded-full bg-black/40 border border-white/20 text-white/80 text-lg z-20" aria-label="pause">II</button>

      {isTouch && !hidden && joy && (
        <div className="absolute pointer-events-none" style={{ left: joy.x - R, top: joy.y - R, width: R * 2, height: R * 2, opacity: s.btnOpacity }}>
          <div className="w-full h-full rounded-full border-2 border-white/30 bg-white/5" />
          <div className="absolute rounded-full bg-white/50" style={{ width: R * 0.8, height: R * 0.8, left: R - R * 0.4 + joy.kx, top: R - R * 0.4 + joy.ky }} />
        </div>
      )}
      {isTouch && !hidden && !joy && (
        <div className="absolute pointer-events-none text-white/30 text-xs" style={{ [left ? 'left' : 'right']: 40, bottom: 40, opacity: s.btnOpacity } as React.CSSProperties}>
          <div className="rounded-full border-2 border-dashed border-white/20 flex items-center justify-center text-center leading-5" style={{ width: R * 2, height: R * 2 }}>{st.driving ? 'فرمان\nگاز / ترمز' : 'حرکت'}</div>
        </div>
      )}

      {!hidden && st.driving && (
        <div className="absolute bottom-6 pointer-events-none text-white/40 text-xs text-center" style={{ ...(left ? { right: 30 } : { left: 30 }), opacity: s.btnOpacity }} dir="rtl">
          <div className="text-2xl">👀</div>برای نگاه به اطراف بکشید
        </div>
      )}
      {!hidden && !st.driving && (
        <div className="absolute bottom-0 h-full pointer-events-none" style={{ ...side, width: '50%', opacity: s.btnOpacity }}>
          {/* interact */}
          <button onPointerDown={(e) => { stop(e); input.interact = true; }}
            className={`${btn} pointer-events-auto ${st.prompt ? 'bg-amber-500/50 border-amber-200/70 shadow-[0_0_25px_rgba(255,190,80,0.5)]' : 'bg-black/35'}`}
            style={{ ...pos(size(120), size(110)), width: size(84), height: size(84) }}>
            <span className="text-2xl">✋</span><span className="text-[10px] opacity-80">تعامل</span>
          </button>
          {/* run */}
          <button onPointerDown={(e) => { stop(e); setTouchRun(true); setRunning(true); }} onPointerUp={(e) => { stop(e); setTouchRun(false); setRunning(false); }} onPointerLeave={() => { setTouchRun(false); setRunning(false); }} onPointerCancel={() => { setTouchRun(false); setRunning(false); }}
            className={`${btn} pointer-events-auto ${running ? 'bg-red-600/50' : 'bg-black/35'}`}
            style={{ ...pos(size(28), size(36)), width: size(78), height: size(78) }}>
            <span className="text-xl">🏃</span><span className="text-[10px] opacity-80">دویدن</span>
          </button>
          {/* crouch */}
          <button onPointerDown={(e) => { stop(e); input.crouch = !input.crouch; setCrouch(input.crouch); }}
            className={`${btn} pointer-events-auto ${crouch ? 'bg-sky-600/50' : 'bg-black/35'}`}
            style={{ ...pos(size(28), size(130)), width: size(64), height: size(64) }}>
            <span className="text-lg">⬇</span><span className="text-[10px] opacity-80">خم شدن</span>
          </button>
          {/* use item */}
          <button onPointerDown={(e) => { stop(e); input.use = true; }}
            className={`${btn} pointer-events-auto ${st.item === 'bottle' ? 'bg-emerald-600/45' : 'bg-black/35'}`}
            style={{ ...pos(size(118), size(16)), width: size(64), height: size(64) }}>
            <span className="text-lg">{st.item === 'bottle' ? '🍾' : '🔦'}</span><span className="text-[10px] opacity-80">{st.item === 'bottle' ? 'پرتاب' : 'وسیله'}</span>
          </button>
          {/* flashlight */}
          <button onPointerDown={(e) => { stop(e); input.flash = true; }}
            className={`${btn} pointer-events-auto ${st.flashlight ? 'bg-yellow-200/40' : 'bg-black/35'}`}
            style={{ ...pos(size(36), size(212)), width: size(52), height: size(52) }}>
            <span className="text-base">🔦</span>
          </button>
        </div>
      )}
      {!isTouch && !hidden && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-[11px] text-white/35 pointer-events-none whitespace-nowrap" dir="rtl">
          کلیک برای قفل موس • WASD حرکت • Shift دویدن • C خم شدن • E تعامل • F چراغ‌قوه • Q استفاده/پرتاب • Esc توقف
        </div>
      )}
      {st.item && !hidden && (
        <div className="absolute top-16 left-3 text-xs bg-black/50 border border-white/15 rounded px-2 py-1 text-white/80 pointer-events-none" dir="rtl">در دست: {ITEM_NAMES[st.item] ?? st.item}</div>
      )}
    </div>
  );
}
