import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { Game } from './game/game';
import { ui, loadSave } from './game/store';
import { audio } from './game/audio';
import { input } from './game/input';
import { HUD, Overlays } from './ui/HUD';
import { TouchControls } from './ui/TouchControls';
import { MainMenu, PauseMenu, LoadingScreen, EndingScreen } from './ui/Menus';

async function goImmersive() {
  try {
    const el = document.documentElement as any;
    if (!document.fullscreenElement && el.requestFullscreen) await el.requestFullscreen({ navigationUI: 'hide' });
  } catch { /* not allowed */ }
  try { await (screen.orientation as any)?.lock?.('landscape'); } catch { /* unsupported */ }
}

function usePortrait() {
  const [p, setP] = useState(false);
  useEffect(() => {
    const touch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    const upd = () => setP(touch && window.innerHeight > window.innerWidth);
    upd(); window.addEventListener('resize', upd); window.addEventListener('orientationchange', upd);
    return () => { window.removeEventListener('resize', upd); window.removeEventListener('orientationchange', upd); };
  }, []);
  return p;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [ready, setReady] = useState(false);
  const st = useSyncExternalStore(ui.subscribe, ui.get);
  const portrait = usePortrait();

  useEffect(() => {
    if (!canvasRef.current || gameRef.current) return;
    gameRef.current = new Game(canvasRef.current);
    (window as any).__game = gameRef.current; // debug handle (dev console)
    setReady(true);
    const onKey = (e: KeyboardEvent) => { if (e.code === 'Escape' && ui.get().screen === 'game') ui.set({ paused: !ui.get().paused }); };
    const onVis = () => { if (document.hidden && ui.get().screen === 'game') ui.set({ paused: true }); };
    window.addEventListener('keydown', onKey);
    document.addEventListener('visibilitychange', onVis);
    return () => { window.removeEventListener('keydown', onKey); document.removeEventListener('visibilitychange', onVis); };
  }, []);

  useEffect(() => { if (st.paused) audio.ctx?.suspend(); else audio.ctx?.resume(); }, [st.paused]);

  const g = gameRef.current;
  const start = async (cont: boolean) => {
    audio.init();
    await goImmersive();
    input.move.x = 0; input.move.y = 0;
    if (!g) return;
    if (cont) g.continueGame(); else g.startNew();
  };

  return (
    <div className="fixed inset-0 bg-black">
      <canvas ref={canvasRef} className="game-canvas" />
      {st.screen === 'game' && <Overlays />}
      {ready && g && st.screen === 'game' && (
        <>
          <HUD game={g} />
          {!st.paused && <TouchControls onPause={() => ui.set({ paused: true })} />}
          {st.paused && (
            <PauseMenu
              onResume={() => ui.set({ paused: false })}
              onQuit={() => { ui.set({ paused: false }); g.quitToMenu(); }}
              onRestart={() => { ui.set({ paused: false }); const s = loadSave(); if (s) { g.save = s; g.loadChapter(s.chapter, s.task); } }}
            />
          )}
        </>
      )}
      {st.screen === 'menu' && <MainMenu onNew={() => start(false)} onContinue={() => start(true)} />}
      {st.screen === 'loading' && <LoadingScreen />}
      {st.screen === 'ending' && g && <EndingScreen onMenu={() => g.quitToMenu()} />}
      {portrait && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center text-white" dir="rtl">
          <div className="text-6xl mb-4 animate-pulse">📱↻</div>
          <div className="text-lg">لطفاً گوشی را افقی بچرخانید</div>
          <div className="text-xs text-white/40 mt-2">NIGHT SHIFT فقط در حالت افقی اجرا می‌شود</div>
        </div>
      )}
    </div>
  );
}
